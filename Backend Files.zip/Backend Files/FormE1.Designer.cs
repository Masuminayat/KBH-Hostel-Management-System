﻿
namespace form_2
{
    partial class FormE1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormE1));
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            label2 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label8 = new Label();
            button7 = new Button();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            label3 = new Label();
            txtBillStatus = new TextBox();
            txtAllocationDate = new TextBox();
            txtJoinDate = new TextBox();
            txtFullName = new TextBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // button2
            // 
            button2.BackgroundImage = (Image)resources.GetObject("button2.BackgroundImage");
            button2.BackgroundImageLayout = ImageLayout.Stretch;
            button2.Cursor = Cursors.Hand;
            button2.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.Location = new Point(177, 122);
            button2.Name = "button2";
            button2.Size = new Size(187, 89);
            button2.TabIndex = 1;
            button2.Text = "Hostel Details";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.BackgroundImage = (Image)resources.GetObject("button3.BackgroundImage");
            button3.BackgroundImageLayout = ImageLayout.Stretch;
            button3.Cursor = Cursors.Hand;
            button3.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button3.Location = new Point(177, 230);
            button3.Name = "button3";
            button3.Size = new Size(187, 93);
            button3.TabIndex = 2;
            button3.Text = "Monthly Bills";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.BackgroundImage = (Image)resources.GetObject("button4.BackgroundImage");
            button4.BackgroundImageLayout = ImageLayout.Stretch;
            button4.Cursor = Cursors.Hand;
            button4.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button4.Location = new Point(177, 344);
            button4.Name = "button4";
            button4.Size = new Size(187, 86);
            button4.TabIndex = 3;
            button4.Text = "Maintenance/Complaints";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // button5
            // 
            button5.BackgroundImage = (Image)resources.GetObject("button5.BackgroundImage");
            button5.BackgroundImageLayout = ImageLayout.Stretch;
            button5.Cursor = Cursors.Hand;
            button5.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button5.Location = new Point(177, 455);
            button5.Name = "button5";
            button5.Size = new Size(187, 106);
            button5.TabIndex = 4;
            button5.Text = "Living Certificate";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // button6
            // 
            button6.BackgroundImage = (Image)resources.GetObject("button6.BackgroundImage");
            button6.BackgroundImageLayout = ImageLayout.Stretch;
            button6.Cursor = Cursors.Hand;
            button6.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button6.Location = new Point(177, 583);
            button6.Name = "button6";
            button6.Size = new Size(187, 94);
            button6.TabIndex = 5;
            button6.Text = "View Announcements";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(414, 12);
            label2.Name = "label2";
            label2.Size = new Size(453, 31);
            label2.TabIndex = 8;
            label2.Text = "Kamran Boys Hostel-Resident Dashboard";
            label2.Click += label2_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.BorderStyle = BorderStyle.Fixed3D;
            label4.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold);
            label4.ForeColor = Color.White;
            label4.Location = new Point(537, 344);
            label4.Name = "label4";
            label4.Size = new Size(193, 40);
            label4.TabIndex = 10;
            label4.Text = "Joining Date:";
            label4.Click += label4_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.BorderStyle = BorderStyle.Fixed3D;
            label5.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold);
            label5.ForeColor = Color.White;
            label5.Location = new Point(537, 407);
            label5.Name = "label5";
            label5.Size = new Size(151, 40);
            label5.TabIndex = 11;
            label5.Text = "Room No:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.BorderStyle = BorderStyle.Fixed3D;
            label6.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold);
            label6.ForeColor = Color.White;
            label6.Location = new Point(537, 467);
            label6.Name = "label6";
            label6.Size = new Size(296, 40);
            label6.TabIndex = 12;
            label6.Text = "Monthly Rent Status:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.Transparent;
            label8.BorderStyle = BorderStyle.Fixed3D;
            label8.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold);
            label8.ForeColor = Color.White;
            label8.Location = new Point(537, 283);
            label8.Name = "label8";
            label8.Size = new Size(105, 40);
            label8.TabIndex = 14;
            label8.Text = "Name:";
            label8.Click += label8_Click;
            // 
            // button7
            // 
            button7.BackColor = Color.FromArgb(0, 0, 192);
            button7.Cursor = Cursors.Hand;
            button7.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold);
            button7.ForeColor = SystemColors.ButtonHighlight;
            button7.Location = new Point(86, 34);
            button7.Name = "button7";
            button7.Size = new Size(119, 44);
            button7.TabIndex = 24;
            button7.Text = "Logout";
            button7.UseVisualStyleBackColor = false;
            button7.Click += button7_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Cursor = Cursors.Hand;
            label1.Font = new Font("Bahnschrift", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.ButtonFace;
            label1.Location = new Point(88, 5);
            label1.Name = "label1";
            label1.Size = new Size(110, 22);
            label1.TabIndex = 23;
            label1.Text = "View Profile";
            label1.Click += label1_Click_1;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Transparent;
            pictureBox1.Cursor = Cursors.Hand;
            pictureBox1.Image = KBH_MS.Properties.Resources.computer_icons_avatar_male_user_profile_png_favpng_ycgruUsQBHhtGyGKfw7fWCtgN_removebg_preview;
            pictureBox1.Location = new Point(2, 2);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(78, 78);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 22;
            pictureBox1.TabStop = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Segoe UI", 22.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.White;
            label3.Location = new Point(675, 192);
            label3.Name = "label3";
            label3.Size = new Size(276, 50);
            label3.TabIndex = 57;
            label3.Text = "Quick Overview";
            // 
            // txtBillStatus
            // 
            txtBillStatus.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtBillStatus.Location = new Point(910, 476);
            txtBillStatus.Name = "txtBillStatus";
            txtBillStatus.ReadOnly = true;
            txtBillStatus.Size = new Size(224, 31);
            txtBillStatus.TabIndex = 61;
            // 
            // txtAllocationDate
            // 
            txtAllocationDate.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtAllocationDate.Location = new Point(910, 408);
            txtAllocationDate.Name = "txtAllocationDate";
            txtAllocationDate.ReadOnly = true;
            txtAllocationDate.Size = new Size(224, 31);
            txtAllocationDate.TabIndex = 60;
            // 
            // txtJoinDate
            // 
            txtJoinDate.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtJoinDate.Location = new Point(910, 341);
            txtJoinDate.Name = "txtJoinDate";
            txtJoinDate.ReadOnly = true;
            txtJoinDate.Size = new Size(224, 31);
            txtJoinDate.TabIndex = 59;
            // 
            // txtFullName
            // 
            txtFullName.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtFullName.Location = new Point(910, 283);
            txtFullName.Name = "txtFullName";
            txtFullName.ReadOnly = true;
            txtFullName.Size = new Size(224, 31);
            txtFullName.TabIndex = 58;
            txtFullName.TextChanged += textBox1_TextChanged;
            // 
            // FormE1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = KBH_MS.Properties.Resources.blurred_blue_gradient_wallpaper_preview;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1250, 750);
            Controls.Add(txtBillStatus);
            Controls.Add(txtAllocationDate);
            Controls.Add(txtJoinDate);
            Controls.Add(txtFullName);
            Controls.Add(label3);
            Controls.Add(button7);
            Controls.Add(label1);
            Controls.Add(pictureBox1);
            Controls.Add(label8);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label2);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            MaximizeBox = false;
            Name = "FormE1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Resident Dashboard";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Label label2;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label8;
        private Button button7;
        private Label label1;
        private PictureBox pictureBox1;
        private Label label3;
        private TextBox textBox4;
        private TextBox textBox3;
        private TextBox textBox2;
        private TextBox textBox1;
        private EventHandler label1_Click;
        private EventHandler pictureBox1_Click;
        private TextBox txtBillStatus;
        private TextBox txtAllocationDate;
        private TextBox txtJoinDate;
        private TextBox txtFullName;
    }
}
