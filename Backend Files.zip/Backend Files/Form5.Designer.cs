﻿namespace Kamran_Boys_Hostel
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            dateTimePicker1 = new DateTimePicker();
            dateTimePicker2 = new DateTimePicker();
            button3 = new Button();
            dataGridView1 = new DataGridView();
            button2 = new Button();
            button1 = new Button();
            label2 = new Label();
            label1 = new Label();
            label3 = new Label();
            label4 = new Label();
            button4 = new Button();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            button5 = new Button();
            button6 = new Button();
            bindingSource1 = new BindingSource(components);
            comboBox1 = new ComboBox();
            label5 = new Label();
            button7 = new Button();
            button8 = new Button();
            errorProvider1 = new ErrorProvider(components);
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)bindingSource1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)errorProvider1).BeginInit();
            SuspendLayout();
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.CalendarFont = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dateTimePicker1.Location = new Point(234, 122);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(405, 27);
            dateTimePicker1.TabIndex = 3;
            // 
            // dateTimePicker2
            // 
            dateTimePicker2.Location = new Point(645, 122);
            dateTimePicker2.Name = "dateTimePicker2";
            dateTimePicker2.Size = new Size(365, 27);
            dateTimePicker2.TabIndex = 4;
            // 
            // button3
            // 
            button3.BackColor = Color.FromArgb(255, 255, 192);
            button3.Cursor = Cursors.Hand;
            button3.Location = new Point(1016, 120);
            button3.Name = "button3";
            button3.Size = new Size(94, 29);
            button3.TabIndex = 5;
            button3.Text = "List";
            button3.UseVisualStyleBackColor = false;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(234, 199);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(879, 481);
            dataGridView1.TabIndex = 6;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(192, 255, 255);
            button2.Cursor = Cursors.Hand;
            button2.Font = new Font("Corbel", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.Location = new Point(10, 389);
            button2.Name = "button2";
            button2.Size = new Size(201, 90);
            button2.TabIndex = 8;
            button2.Text = "Visitors This Month";
            button2.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(192, 255, 255);
            button1.Cursor = Cursors.Hand;
            button1.Font = new Font("Corbel", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(10, 280);
            button1.Name = "button1";
            button1.Size = new Size(201, 87);
            button1.TabIndex = 7;
            button1.Text = "Visitors This Week";
            button1.UseVisualStyleBackColor = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.White;
            label2.Location = new Point(37, 115);
            label2.Name = "label2";
            label2.Size = new Size(139, 31);
            label2.TabIndex = 9;
            label2.Text = "Quick Filters";
            label2.Click += label2_Click;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI Symbol", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Black;
            label1.Location = new Point(372, -1);
            label1.Name = "label1";
            label1.Size = new Size(539, 41);
            label1.TabIndex = 10;
            label1.Text = "Kamraan Boys Hostel Visitors Record";
            label1.TextAlign = ContentAlignment.TopCenter;
            label1.Click += label1_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Segoe UI", 7.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.White;
            label3.Location = new Point(234, 102);
            label3.Name = "label3";
            label3.Size = new Size(84, 17);
            label3.TabIndex = 11;
            label3.Text = "Starting Date";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Segoe UI", 7.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.White;
            label4.Location = new Point(645, 102);
            label4.Name = "label4";
            label4.Size = new Size(79, 17);
            label4.TabIndex = 12;
            label4.Text = "Ending Date";
            // 
            // button4
            // 
            button4.BackColor = Color.FromArgb(192, 255, 255);
            button4.Cursor = Cursors.Hand;
            button4.Font = new Font("Corbel", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button4.Location = new Point(10, 162);
            button4.Name = "button4";
            button4.Size = new Size(201, 87);
            button4.TabIndex = 13;
            button4.Text = "Visitors Today";
            button4.UseVisualStyleBackColor = false;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(234, 166);
            textBox1.MaxLength = 13;
            textBox1.Name = "textBox1";
            textBox1.PlaceholderText = "Search by CNIC";
            textBox1.Size = new Size(305, 27);
            textBox1.TabIndex = 14;
            textBox1.TextAlign = HorizontalAlignment.Center;
            textBox1.TextChanged += textBox1_TextChanged;
            textBox1.KeyPress += textBox1_KeyPress;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(645, 166);
            textBox2.MaxLength = 50;
            textBox2.Name = "textBox2";
            textBox2.PlaceholderText = "Search by Name";
            textBox2.Size = new Size(264, 27);
            textBox2.TabIndex = 15;
            textBox2.TextAlign = HorizontalAlignment.Center;
            textBox2.TextChanged += textBox2_TextChanged;
            // 
            // button5
            // 
            button5.BackColor = Color.FromArgb(255, 255, 192);
            button5.Cursor = Cursors.Hand;
            button5.Location = new Point(915, 164);
            button5.Name = "button5";
            button5.Size = new Size(94, 29);
            button5.TabIndex = 16;
            button5.Text = "Search";
            button5.UseVisualStyleBackColor = false;
            // 
            // button6
            // 
            button6.BackColor = Color.FromArgb(255, 255, 192);
            button6.Cursor = Cursors.Hand;
            button6.Location = new Point(545, 166);
            button6.Name = "button6";
            button6.Size = new Size(94, 29);
            button6.TabIndex = 17;
            button6.Text = "Search";
            button6.UseVisualStyleBackColor = false;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Ascending", "Descending" });
            comboBox1.Location = new Point(1016, 164);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(97, 28);
            comboBox1.TabIndex = 18;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Segoe UI", 7.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.White;
            label5.Location = new Point(1016, 147);
            label5.Name = "label5";
            label5.Size = new Size(80, 17);
            label5.TabIndex = 19;
            label5.Text = "Sort by date";
            // 
            // button7
            // 
            button7.BackColor = Color.LightSalmon;
            button7.Cursor = Cursors.Hand;
            button7.Location = new Point(10, 601);
            button7.Margin = new Padding(3, 4, 3, 4);
            button7.Name = "button7";
            button7.Size = new Size(201, 79);
            button7.TabIndex = 20;
            button7.Text = "Go to Dashboard";
            button7.UseVisualStyleBackColor = false;
            button7.Click += button7_Click;
            // 
            // button8
            // 
            button8.BackColor = Color.FromArgb(0, 0, 192);
            button8.Cursor = Cursors.Hand;
            button8.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold);
            button8.ForeColor = SystemColors.ButtonHighlight;
            button8.Location = new Point(1123, 6);
            button8.Name = "button8";
            button8.Size = new Size(111, 36);
            button8.TabIndex = 21;
            button8.Text = "Logout";
            button8.UseVisualStyleBackColor = false;
            button8.Click += button8_Click;
            // 
            // errorProvider1
            // 
            errorProvider1.ContainerControl = this;
            // 
            // Form5
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = KBH_MS.Properties.Resources.blurred_blue_gradient_wallpaper_preview;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1236, 702);
            Controls.Add(button8);
            Controls.Add(button7);
            Controls.Add(label5);
            Controls.Add(comboBox1);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(button4);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label1);
            Controls.Add(label2);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(dataGridView1);
            Controls.Add(button3);
            Controls.Add(dateTimePicker2);
            Controls.Add(dateTimePicker1);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            MaximizeBox = false;
            Name = "Form5";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form5";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)bindingSource1).EndInit();
            ((System.ComponentModel.ISupportInitialize)errorProvider1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private DateTimePicker dateTimePicker1;
        private DateTimePicker dateTimePicker2;
        private Button button3;
        private DataGridView dataGridView1;
        private Button button2;
        private Button button1;
        private Label label2;
        private Label label1;
        private Label label3;
        private Label label4;
        private Button button4;
        private TextBox textBox1;
        private TextBox textBox2;
        private Button button5;
        private Button button6;
        private BindingSource bindingSource1;
        private ComboBox comboBox1;
        private Label label5;
        private Button button7;
        private Button button8;
        private ErrorProvider errorProvider1;
    }
}