using form_2;
using hostelsystem;
using MySql.Data.MySqlClient;
using Org.BouncyCastle.Asn1.Cmp;
using System.Data;

namespace announcements
{
    public partial class FormE6 : Form
    {
        public FormE6()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FormE1 formE1 = new FormE1();
            this.Hide();
            formE1.ShowDialog();
            this.Show(); // Show Form2 again when Form3 closes
        }

        private void LoadAnnouncements()
        {
            string connStr = "server=localhost;user=root;password=root;database=kbh_ms;";
            using (MySqlConnection conn = new MySqlConnection(connStr))
            {
                try
                {
                    conn.Open();
                    string query = @"SELECT annID AS 'ID', annBy AS 'Announced By', annHead AS 'Title', annDate AS 'Date' 
                             FROM announcements ORDER BY annID DESC";

                    using (MySqlDataAdapter adapter = new MySqlDataAdapter(query, conn))
                    {
                        DataTable table = new DataTable();
                        adapter.Fill(table);
                        dgvAnnouncements.DataSource = table;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading announcements: " + ex.Message);
                }
            }
        }

        private void dgvAnnouncements_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                string annId = dgvAnnouncements.Rows[e.RowIndex].Cells["ID"].Value.ToString();
                LoadAnnouncementDetails(annId);
            }
        }

        private void LoadAnnouncementDetails(string annId)
        {
            string connStr = "server=localhost;user=root;password=root;database=kbh_ms;";
            using (MySqlConnection conn = new MySqlConnection(connStr))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT annBy, annHead, annDate, annDesc FROM announcements WHERE annID = @id";
                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@id", annId);
                        using (MySqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                txtAnnouncer.Text = reader["annBy"].ToString();
                                txtTitle.Text = reader["annHead"].ToString();
                                txtAnnDate.Text = reader["annDate"].ToString();
                                rtbDetails.Text = reader["annDesc"].ToString();
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading details: " + ex.Message);
                }
            }
        }

        private void FormE6_Load(object sender, EventArgs e)
        {
            LoadAnnouncements();
        }

        private void dgvAnnouncements_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
      
            if (e.RowIndex >= 0)
            {
                string annId = dgvAnnouncements.Rows[e.RowIndex].Cells["ID"].Value.ToString();
                LoadAnnouncementDetails(annId);
            }
        

    }
}

}

