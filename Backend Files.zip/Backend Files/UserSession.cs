﻿public static class UserSession
{
    public static string CNIC { get; set; }
    public static string Name { get; set; }
    public static string Role { get; set; }

    public static void Clear()
    {
        CNIC = null;
        Name = null;
        Role = null;
    }
}
