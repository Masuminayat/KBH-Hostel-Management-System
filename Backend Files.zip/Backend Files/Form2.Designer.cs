﻿namespace Kamran_Boys_Hostel
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBox1 = new PictureBox();
            button1 = new Button();
            button2 = new Button();
            label1 = new Label();
            button3 = new Button();
            button4 = new Button();
            dataGridView1 = new DataGridView();
            button5 = new Button();
            button6 = new Button();
            lblMonthlyVisits = new Label();
            lblTodaysVisits = new Label();
            label4 = new Label();
            button7 = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Transparent;
            pictureBox1.Cursor = Cursors.Hand;
            pictureBox1.Image = KBH_MS.Properties.Resources.computer_icons_avatar_male_user_profile_png_favpng_ycgruUsQBHhtGyGKfw7fWCtgN_removebg_preview;
            pictureBox1.Location = new Point(13, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(78, 78);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(192, 255, 255);
            button1.Cursor = Cursors.Hand;
            button1.Font = new Font("Corbel", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(101, 172);
            button1.Name = "button1";
            button1.Size = new Size(201, 87);
            button1.TabIndex = 1;
            button1.Text = "Add Visitor";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(192, 255, 255);
            button2.Cursor = Cursors.Hand;
            button2.Font = new Font("Corbel", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.Location = new Point(101, 284);
            button2.Name = "button2";
            button2.Size = new Size(201, 90);
            button2.TabIndex = 2;
            button2.Text = "View History";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Cursor = Cursors.Hand;
            label1.Font = new Font("Bahnschrift", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(99, 15);
            label1.Name = "label1";
            label1.Size = new Size(110, 22);
            label1.TabIndex = 3;
            label1.Text = "View Profile";
            label1.Click += label1_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.FromArgb(192, 255, 255);
            button3.Cursor = Cursors.Hand;
            button3.Font = new Font("Corbel", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button3.Location = new Point(101, 392);
            button3.Name = "button3";
            button3.Size = new Size(201, 93);
            button3.TabIndex = 4;
            button3.Text = "Post Notices";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.BackColor = Color.FromArgb(192, 255, 255);
            button4.Cursor = Cursors.Hand;
            button4.Font = new Font("Corbel", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button4.Location = new Point(101, 509);
            button4.Name = "button4";
            button4.Size = new Size(201, 88);
            button4.TabIndex = 5;
            button4.Text = "Previous Notices";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(577, 189);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.RowTemplate.Height = 24;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.Size = new Size(543, 432);
            dataGridView1.TabIndex = 6;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // button5
            // 
            button5.Font = new Font("Microsoft YaHei", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button5.Location = new Point(577, 34);
            button5.Name = "button5";
            button5.Size = new Size(173, 82);
            button5.TabIndex = 7;
            button5.Text = "Total Visits Today";
            button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            button6.Font = new Font("Microsoft YaHei", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button6.Location = new Point(882, 34);
            button6.Name = "button6";
            button6.Size = new Size(172, 80);
            button6.TabIndex = 8;
            button6.Text = "Monthly Visits";
            button6.UseVisualStyleBackColor = true;
            // 
            // lblMonthlyVisits
            // 
            lblMonthlyVisits.AutoSize = true;
            lblMonthlyVisits.BackColor = Color.Black;
            lblMonthlyVisits.Font = new Font("Microsoft YaHei UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblMonthlyVisits.ForeColor = Color.White;
            lblMonthlyVisits.Location = new Point(1069, 56);
            lblMonthlyVisits.Name = "lblMonthlyVisits";
            lblMonthlyVisits.Size = new Size(51, 37);
            lblMonthlyVisits.TabIndex = 9;
            lblMonthlyVisits.Text = "29";
            // 
            // lblTodaysVisits
            // 
            lblTodaysVisits.AutoSize = true;
            lblTodaysVisits.BackColor = Color.Black;
            lblTodaysVisits.Font = new Font("Microsoft YaHei UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTodaysVisits.ForeColor = Color.White;
            lblTodaysVisits.Location = new Point(773, 56);
            lblTodaysVisits.Name = "lblTodaysVisits";
            lblTodaysVisits.Size = new Size(51, 37);
            lblTodaysVisits.TabIndex = 10;
            lblTodaysVisits.Text = "05";
            lblTodaysVisits.Click += label3_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Microsoft Tai Le", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.White;
            label4.Location = new Point(750, 151);
            label4.Name = "label4";
            label4.Size = new Size(210, 35);
            label4.TabIndex = 11;
            label4.Text = "Recent Visitors";
            // 
            // button7
            // 
            button7.BackColor = Color.FromArgb(0, 0, 192);
            button7.Cursor = Cursors.Hand;
            button7.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold);
            button7.ForeColor = SystemColors.ButtonHighlight;
            button7.Location = new Point(97, 44);
            button7.Name = "button7";
            button7.Size = new Size(119, 44);
            button7.TabIndex = 12;
            button7.Text = "Logout";
            button7.UseVisualStyleBackColor = false;
            button7.Click += button7_Click;
            // 
            // Form2
            // 
            BackgroundImage = KBH_MS.Properties.Resources.forms_bg_image;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1219, 701);
            Controls.Add(button7);
            Controls.Add(label4);
            Controls.Add(lblTodaysVisits);
            Controls.Add(lblMonthlyVisits);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(dataGridView1);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(label1);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(pictureBox1);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            MaximizeBox = false;
            Name = "Form2";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Security-Dash";
            Load += Form2_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label lblMonthlyVisits;
        private System.Windows.Forms.Label lblTodaysVisits;
        private System.Windows.Forms.Label label4;
        private Button button7;
    }
}
