﻿using MySql.Data.MySqlClient;
using Org.BouncyCastle.Asn1.Cmp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace KBH_Owner
{
    public partial class FormS2 : System.Windows.Forms.Form
    {
        public FormS2()
        {
            InitializeComponent();
        }

        private void FormS2_Load(object sender, EventArgs e)
        {
            LoadUsersToGrid();

        }




        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
                errorProvider1.SetError(textBox1, "Enter 13 digit CNIC Number without dashes");
            }
            else
            {
                errorProvider1.SetError(textBox1, "");
            }
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
                errorProvider2.SetError(textBox4, "Enter phone number without any character/letter");
            }
            else
            {
                errorProvider2.SetError(textBox4, ""); // Clear error
            }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar) && e.KeyChar != ' ')
            {
                e.Handled = true; // Block invalid input
                errorProvider3.SetError(textBox2, "Only letters and spaces are allowed");
            }
        }

        private void dataGridView1_RowValidated(object sender, DataGridViewCellEventArgs e)
        {
            /* if (dataGridView1.CurrentRow != null && dataGridView1.IsCurrentRowDirty)
             {
                 DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                 string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";
                 string updateQuery = @"UPDATE users 
                                SET full_Name = @name, user_role = @role, 
                                    email = @email, phone_no = @phone 
                                WHERE user_cnic = @cnic";

                 try
                 {
                     using (MySqlConnection conn = new MySqlConnection(connectionString))
                     {
                         conn.Open();
                         using (MySqlCommand cmd = new MySqlCommand(updateQuery, conn))
                         {
                             cmd.Parameters.AddWithValue("@name", row.Cells["Name"].Value?.ToString());
                             cmd.Parameters.AddWithValue("@role", row.Cells["Role"].Value?.ToString());
                             cmd.Parameters.AddWithValue("@email", row.Cells["Email"].Value?.ToString());
                             cmd.Parameters.AddWithValue("@phone", row.Cells["Phone"].Value?.ToString());
                             cmd.Parameters.AddWithValue("@cnic", row.Cells["CNIC"].Value?.ToString());

                             cmd.ExecuteNonQuery();

                             LoadUsersToGrid();
                         }
                     }
                 }
                 catch (Exception ex)
                 {
                     MessageBox.Show("Error updating user: " + ex.Message);
                 }
             }*/
        }



        private void button2_Click(object sender, EventArgs e)
        {

            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow row = dataGridView1.SelectedRows[0];

                string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";
                string updateQuery = @"UPDATE users 
                               SET full_Name = @name, user_role = @role, 
                                   email = @email, phone_no = @phone 
                               WHERE user_cnic = @cnic";

                try
                {
                    using (MySqlConnection conn = new MySqlConnection(connectionString))
                    {
                        conn.Open();
                        using (MySqlCommand cmd = new MySqlCommand(updateQuery, conn))
                        {
                            cmd.Parameters.AddWithValue("@name", row.Cells["Name"].Value?.ToString());
                            cmd.Parameters.AddWithValue("@role", row.Cells["Role"].Value?.ToString());
                            cmd.Parameters.AddWithValue("@email", row.Cells["Email"].Value?.ToString());
                            cmd.Parameters.AddWithValue("@phone", row.Cells["Phone"].Value?.ToString());
                            cmd.Parameters.AddWithValue("@cnic", row.Cells["CNIC"].Value?.ToString());

                            int result = cmd.ExecuteNonQuery();
                            MessageBox.Show(result > 0 ? "User updated successfully!" : "Update failed.");
                            LoadUsersToGrid();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error updating user: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Please select a row to update.");
            }
        }



        private void button1_Click(object sender, EventArgs e)
        {
            // Validate inputs (simple example)
            if (string.IsNullOrWhiteSpace(textBox1.Text) || comboBox1.SelectedIndex == -1)
            {
                MessageBox.Show("Please fill all fields properly.");
                return;
            }

            string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";
            string insertQuery = @"INSERT INTO users 
        (user_cnic, full_Name, user_role, email, phone_no, password) 
        VALUES (@cnic, @name, @role, @email, @phone, @password)";

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    using (MySqlCommand cmd = new MySqlCommand(insertQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@cnic", Convert.ToInt64(textBox1.Text));
                        cmd.Parameters.AddWithValue("@name", textBox2.Text);
                        cmd.Parameters.AddWithValue("@role", comboBox1.SelectedItem.ToString());
                        cmd.Parameters.AddWithValue("@email", textBox5.Text);
                        cmd.Parameters.AddWithValue("@phone", textBox4.Text);
                        cmd.Parameters.AddWithValue("@password", textBox6.Text);

                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("User added successfully!");
                        }
                        else
                        {
                            MessageBox.Show("Failed to add user. Try again.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void LoadUsersToGrid()
        {
            string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";
            string selectQuery = "SELECT user_cnic AS 'CNIC', full_Name AS 'Name', user_role AS 'Role', email AS 'Email', phone_no AS 'Phone' FROM users";

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    using (MySqlDataAdapter adapter = new MySqlDataAdapter(selectQuery, conn))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        dataGridView1.DataSource = dt;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading users: " + ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {

            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
                string userCnic = selectedRow.Cells["CNIC"].Value?.ToString();
                

                DialogResult result = MessageBox.Show(
                    $"Are you sure you want to delete the user with CNIC: {userCnic}?",
                    "Confirm Deletion",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning
                );

                if (result == DialogResult.Yes)
                {
                    string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";
                    string deleteQuery = "DELETE FROM users WHERE user_cnic = @cnic";

                    try
                    {
                        using (MySqlConnection conn = new MySqlConnection(connectionString))
                        {
                            conn.Open();
                            using (MySqlCommand cmd = new MySqlCommand(deleteQuery, conn))
                            {
                                cmd.Parameters.AddWithValue("@cnic", userCnic);
                                int rowsDeleted = cmd.ExecuteNonQuery();

                                if (rowsDeleted > 0)
                                {
                                    MessageBox.Show("User deleted successfully.");
                                    // Optionally refresh the DataGridView
                                    dataGridView1.Rows.Remove(selectedRow);
                                    LoadUsersToGrid();
                                }
                                else
                                {
                                    MessageBox.Show("User could not be deleted.");
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error deleting user: " + ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a user to delete.");
            }
        
    }
}

}

