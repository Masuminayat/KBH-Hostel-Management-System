﻿namespace leavingcertificate
{
    partial class FormE5
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormE5));
            label1 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label11 = new Label();
            label13 = new Label();
            printDocument1 = new System.Drawing.Printing.PrintDocument();
            button1 = new Button();
            button2 = new Button();
            label16 = new Label();
            label17 = new Label();
            lblCurrentRent = new TextBox();
            lblName = new TextBox();
            lblFatherName = new TextBox();
            lblJoinDate = new TextBox();
            label8 = new Label();
            label10 = new Label();
            label9 = new Label();
            lblCurrentDate = new TextBox();
            label2 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(409, 9);
            label1.Name = "label1";
            label1.Size = new Size(429, 31);
            label1.TabIndex = 0;
            label1.Text = "Kamran Boys Hostel-Living Certificate ";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(38, 82);
            label3.Name = "label3";
            label3.Size = new Size(85, 23);
            label3.TabIndex = 3;
            label3.Text = "Address:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(38, 115);
            label4.Name = "label4";
            label4.Size = new Size(111, 23);
            label4.TabIndex = 4;
            label4.Text = "Ph Number:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Times New Roman", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.Location = new Point(25, 240);
            label5.Name = "label5";
            label5.Size = new Size(262, 52);
            label5.TabIndex = 5;
            label5.Text = "To Whom It May Concern,\n\n";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(25, 286);
            label6.Name = "label6";
            label6.Size = new Size(0, 20);
            label6.TabIndex = 6;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.Transparent;
            label7.Font = new Font("Segoe UI Historic", 13.8F);
            label7.Location = new Point(661, 346);
            label7.Name = "label7";
            label7.Size = new Size(467, 31);
            label7.TabIndex = 7;
            label7.Text = ". He is regularly paying monthly rent of PKR: ";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.BackColor = Color.Transparent;
            label11.Font = new Font("Segoe UI Historic", 13.8F);
            label11.Location = new Point(78, 288);
            label11.Name = "label11";
            label11.Size = new Size(1242, 31);
            label11.TabIndex = 11;
            label11.Text = "This is to certify that Mr.                                                           son of                                       has been residing in                     ";
            label11.Click += label11_Click;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.BackColor = Color.Transparent;
            label13.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label13.Location = new Point(25, 507);
            label13.Name = "label13";
            label13.Size = new Size(259, 23);
            label13.TabIndex = 13;
            label13.Text = "Warden, Kamran Boys Hostel";
            // 
            // button1
            // 
            button1.BackgroundImage = (Image)resources.GetObject("button1.BackgroundImage");
            button1.BackgroundImageLayout = ImageLayout.Stretch;
            button1.Cursor = Cursors.Hand;
            button1.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(1037, 629);
            button1.Name = "button1";
            button1.Size = new Size(175, 62);
            button1.TabIndex = 20;
            button1.Text = "Go to Dashboard";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.BackgroundImage = (Image)resources.GetObject("button2.BackgroundImage");
            button2.BackgroundImageLayout = ImageLayout.Stretch;
            button2.Cursor = Cursors.Hand;
            button2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.Location = new Point(865, 628);
            button2.Name = "button2";
            button2.Size = new Size(166, 62);
            button2.TabIndex = 21;
            button2.Text = "Print";
            button2.UseVisualStyleBackColor = true;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.BackColor = Color.Transparent;
            label16.Location = new Point(155, 85);
            label16.Name = "label16";
            label16.Size = new Size(200, 20);
            label16.TabIndex = 28;
            label16.Text = "Kamran Boys Hostel, F08, ISB";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.BackColor = Color.Transparent;
            label17.Location = new Point(155, 117);
            label17.Name = "label17";
            label17.Size = new Size(97, 20);
            label17.TabIndex = 29;
            label17.Text = "03428757342";
            // 
            // lblCurrentRent
            // 
            lblCurrentRent.BackColor = Color.FromArgb(64, 64, 64);
            lblCurrentRent.Font = new Font("Segoe UI", 12F);
            lblCurrentRent.ForeColor = Color.White;
            lblCurrentRent.Location = new Point(1118, 346);
            lblCurrentRent.Name = "lblCurrentRent";
            lblCurrentRent.ReadOnly = true;
            lblCurrentRent.Size = new Size(102, 34);
            lblCurrentRent.TabIndex = 62;
            lblCurrentRent.TextAlign = HorizontalAlignment.Center;
            lblCurrentRent.TextChanged += lblCurrentRent_TextChanged;
            // 
            // lblName
            // 
            lblName.BackColor = Color.FromArgb(64, 64, 64);
            lblName.Font = new Font("Segoe UI", 12F);
            lblName.ForeColor = Color.White;
            lblName.Location = new Point(341, 290);
            lblName.Name = "lblName";
            lblName.ReadOnly = true;
            lblName.Size = new Size(314, 34);
            lblName.TabIndex = 63;
            lblName.TextAlign = HorizontalAlignment.Center;
            // 
            // lblFatherName
            // 
            lblFatherName.BackColor = Color.FromArgb(64, 64, 64);
            lblFatherName.Font = new Font("Segoe UI", 12F);
            lblFatherName.ForeColor = Color.White;
            lblFatherName.Location = new Point(756, 290);
            lblFatherName.Name = "lblFatherName";
            lblFatherName.ReadOnly = true;
            lblFatherName.Size = new Size(215, 34);
            lblFatherName.TabIndex = 64;
            lblFatherName.TextAlign = HorizontalAlignment.Center;
            // 
            // lblJoinDate
            // 
            lblJoinDate.BackColor = Color.FromArgb(64, 64, 64);
            lblJoinDate.Font = new Font("Segoe UI", 12F);
            lblJoinDate.ForeColor = Color.White;
            lblJoinDate.Location = new Point(477, 346);
            lblJoinDate.Name = "lblJoinDate";
            lblJoinDate.ReadOnly = true;
            lblJoinDate.Size = new Size(178, 34);
            lblJoinDate.TabIndex = 65;
            lblJoinDate.TextAlign = HorizontalAlignment.Center;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.Transparent;
            label8.Font = new Font("Segoe UI Historic", 13.8F);
            label8.Location = new Point(25, 344);
            label8.Name = "label8";
            label8.Size = new Size(455, 31);
            label8.TabIndex = 66;
            label8.Text = "Kamraan Boys Hostel, F08, Islamabad since ";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.BackColor = Color.Transparent;
            label10.Font = new Font("Segoe UI Historic", 13.8F);
            label10.Location = new Point(25, 427);
            label10.Name = "label10";
            label10.Size = new Size(110, 62);
            label10.TabIndex = 10;
            label10.Text = "\nSincerely,";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.Transparent;
            label9.ForeColor = Color.White;
            label9.Location = new Point(5, 678);
            label9.Name = "label9";
            label9.Size = new Size(411, 20);
            label9.TabIndex = 67;
            label9.Text = "This is a system generated certificate - No signature required";
            // 
            // lblCurrentDate
            // 
            lblCurrentDate.BackColor = Color.FromArgb(64, 64, 64);
            lblCurrentDate.Font = new Font("Segoe UI", 12F);
            lblCurrentDate.ForeColor = Color.White;
            lblCurrentDate.Location = new Point(106, 545);
            lblCurrentDate.Name = "lblCurrentDate";
            lblCurrentDate.ReadOnly = true;
            lblCurrentDate.Size = new Size(178, 34);
            lblCurrentDate.TabIndex = 68;
            lblCurrentDate.TextAlign = HorizontalAlignment.Center;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(31, 550);
            label2.Name = "label2";
            label2.Size = new Size(58, 23);
            label2.TabIndex = 69;
            label2.Text = "Date:";
            // 
            // FormE5
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1232, 703);
            Controls.Add(label2);
            Controls.Add(lblCurrentDate);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(lblJoinDate);
            Controls.Add(lblFatherName);
            Controls.Add(lblName);
            Controls.Add(lblCurrentRent);
            Controls.Add(label17);
            Controls.Add(label16);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label13);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            MaximizeBox = false;
            Name = "FormE5";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Hostel Living Certificate ";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label11;
        private Label label13;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private Button button1;
        private Button button2;
        private Label label16;
        private Label label17;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private TextBox textBox4;
        private Label label8;
        private Label label10;
        private Label label9;
        private TextBox textBox5;
        private Label label2;
        private TextBox lblCurrentDate;
        private TextBox lblJoinDate;
        private TextBox lblFatherName;
        private TextBox lblName;
        private TextBox lblCurrentRent;
    }
}
