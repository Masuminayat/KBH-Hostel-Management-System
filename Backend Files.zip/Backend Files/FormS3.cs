﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KBH_Owner
{
    public partial class FormS3 : System.Windows.Forms.Form
    {
        public FormS3()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void FormS3_Load(object sender, EventArgs e)
        {
            // Replace with your actual connection string
            string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";

            // SQL query to fetch user details
            string query = "SELECT roomNumber, maxCapacity, monthlyCharge, roomDetails FROM rooms";

            // Create a DataTable to hold user data
            DataTable userTable = new DataTable();

            try
            {
                // Open a connection to the MySQL database
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();

                    // Use MySqlDataAdapter to fetch the data and fill it into the DataTable
                    using (MySqlDataAdapter da = new MySqlDataAdapter(query, conn))
                    {
                        da.Fill(userTable);
                    }
                }

                // Bind the DataTable to the DataGridView
                dataGridView1.DataSource = userTable;
            }
            catch (Exception ex)
            {
                // Handle any errors that occur during the database operation
                MessageBox.Show("Error fetching room details: " + ex.Message);
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {

            string roomNumber = textBox1.Text.Trim();
            int maxCapacity = Convert.ToInt32(textBox5.Text.Trim());
            int monthlyCharge = Convert.ToInt32(textBox4.Text.Trim());
            string roomDetails = textBox2.Text.Trim();

            if (string.IsNullOrEmpty(roomNumber) || string.IsNullOrEmpty(textBox4.Text))
            {
                MessageBox.Show("Please fill all required fields.");
                return;
            }

            string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";
            string insertQuery = "INSERT INTO rooms (roomNumber, maxCapacity, monthlyCharge, roomDetails) VALUES (@roomNumber, @maxCapacity, @monthlyCharge, @roomDetails)";

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    using (MySqlCommand cmd = new MySqlCommand(insertQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@roomNumber", roomNumber);
                        cmd.Parameters.AddWithValue("@maxCapacity", maxCapacity);
                        cmd.Parameters.AddWithValue("@monthlyCharge", monthlyCharge);
                        cmd.Parameters.AddWithValue("@roomDetails", roomDetails);

                        int rowsInserted = cmd.ExecuteNonQuery();
                        if (rowsInserted > 0)
                        {
                            MessageBox.Show("Room added successfully!");
                           
                        }
                        else
                        {
                            MessageBox.Show("Failed to add room.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

    }

}
