﻿namespace HostelDetails
{
    partial class FormE2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormE2));
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            label13 = new Label();
            label14 = new Label();
            label15 = new Label();
            label16 = new Label();
            label17 = new Label();
            label18 = new Label();
            label19 = new Label();
            label20 = new Label();
            label21 = new Label();
            label22 = new Label();
            textBox1 = new TextBox();
            button1 = new Button();
            button2 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Black;
            label1.Location = new Point(453, 44);
            label1.Name = "label1";
            label1.Size = new Size(302, 36);
            label1.TabIndex = 2;
            label1.Text = "Kamran Boys Hostel";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(232, 136);
            label2.Name = "label2";
            label2.Size = new Size(0, 20);
            label2.TabIndex = 3;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Microsoft YaHei", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(29, 174);
            label3.Name = "label3";
            label3.Size = new Size(339, 25);
            label3.TabIndex = 4;
            label3.Text = "Kamran Boys Hostel Near F8 Markaz";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Microsoft Sans Serif", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(27, 125);
            label4.Name = "label4";
            label4.Size = new Size(225, 29);
            label4.TabIndex = 5;
            label4.Text = "Hostel Information";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Microsoft Tai Le", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(29, 216);
            label5.Name = "label5";
            label5.Size = new Size(188, 23);
            label5.TabIndex = 6;
            label5.Text = "Contact Information:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Font = new Font("Microsoft Tai Le", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.Location = new Point(31, 245);
            label6.Name = "label6";
            label6.Size = new Size(68, 22);
            label6.TabIndex = 7;
            label6.Text = "Ph No#";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.Transparent;
            label7.Font = new Font("Microsoft Tai Le", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.Location = new Point(31, 272);
            label7.Name = "label7";
            label7.Size = new Size(116, 22);
            label7.TabIndex = 8;
            label7.Text = "Email Address";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.Transparent;
            label8.Font = new Font("Microsoft Tai Le", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.Location = new Point(32, 330);
            label8.Name = "label8";
            label8.Size = new Size(400, 29);
            label8.TabIndex = 9;
            label8.Text = "Accomodation Details And Facilities";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.Transparent;
            label9.Font = new Font("Microsoft Tai Le", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label9.Location = new Point(34, 366);
            label9.Name = "label9";
            label9.Size = new Size(848, 22);
            label9.TabIndex = 10;
            label9.Text = "Single seated, two seated , three seated , four seated and 5 seated rooms available with attached washrooms .";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.BackColor = Color.Transparent;
            label10.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label10.Location = new Point(35, 394);
            label10.Name = "label10";
            label10.Size = new Size(449, 20);
            label10.TabIndex = 11;
            label10.Text = "Daily room cleaning service and laundary service available.";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.BackColor = Color.Transparent;
            label11.Font = new Font("Microsoft Tai Le", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label11.Location = new Point(35, 430);
            label11.Name = "label11";
            label11.Size = new Size(234, 22);
            label11.TabIndex = 12;
            label11.Text = "24/7 fast internet  (4G to 5G) ";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.BackColor = Color.Transparent;
            label12.Font = new Font("Microsoft Tai Le", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label12.Location = new Point(34, 458);
            label12.Name = "label12";
            label12.Size = new Size(478, 22);
            label12.TabIndex = 13;
            label12.Text = "Shared Facilities include air conditioning, coolers and heaters.";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.BackColor = Color.Transparent;
            label13.Font = new Font("Microsoft Tai Le", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label13.Location = new Point(36, 515);
            label13.Name = "label13";
            label13.Size = new Size(235, 29);
            label13.TabIndex = 14;
            label13.Text = "Pricing and Payment";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.BackColor = Color.Transparent;
            label14.Font = new Font("Microsoft Tai Le", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label14.Location = new Point(35, 551);
            label14.Name = "label14";
            label14.Size = new Size(381, 22);
            label14.TabIndex = 15;
            label14.Text = "Room Rates( As per night, per week , per month)";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.BackColor = Color.Transparent;
            label15.Font = new Font("Microsoft Tai Le", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label15.ImageAlign = ContentAlignment.TopCenter;
            label15.Location = new Point(38, 579);
            label15.Name = "label15";
            label15.Size = new Size(889, 22);
            label15.TabIndex = 16;
            label15.Text = "Payment Methods include cash, credit card or online payment. And rent should be payed at the start of the month.";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.BackColor = Color.Transparent;
            label16.Font = new Font("Microsoft Tai Le", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label16.Location = new Point(38, 611);
            label16.Name = "label16";
            label16.Size = new Size(862, 22);
            label16.TabIndex = 17;
            label16.Text = "Security must be deposited for securing the seat and it would be returned on a notice before leaving the hostel.";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.BackColor = Color.Transparent;
            label17.Font = new Font("Microsoft Tai Le", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label17.Location = new Point(39, 678);
            label17.Name = "label17";
            label17.Size = new Size(215, 29);
            label17.TabIndex = 18;
            label17.Text = "Rules And Policies:";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.BackColor = Color.Transparent;
            label18.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label18.Location = new Point(41, 714);
            label18.Name = "label18";
            label18.Size = new Size(577, 20);
            label18.TabIndex = 19;
            label18.Text = "Check-in and check-out times are fixed.Gate shall be clsoed sharp at 10p.m.";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.BackColor = Color.Transparent;
            label19.Font = new Font("Microsoft Tai Le", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label19.Location = new Point(41, 746);
            label19.Name = "label19";
            label19.Size = new Size(610, 22);
            label19.TabIndex = 20;
            label19.Text = "Smoking is not allowed in hostel premises. In case strict action would be taken.";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.BackColor = Color.Transparent;
            label20.Font = new Font("Microsoft Tai Le", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label20.Location = new Point(39, 779);
            label20.Name = "label20";
            label20.Size = new Size(562, 22);
            label20.TabIndex = 21;
            label20.Text = "Guests are allowed to meet in hostel after the verification through CNIC.";
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.BackColor = Color.Transparent;
            label21.Font = new Font("Microsoft Tai Le", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label21.Location = new Point(38, 810);
            label21.Name = "label21";
            label21.Size = new Size(680, 22);
            label21.TabIndex = 22;
            label21.Text = "Breaching the policies for result in immediate cancellation of fee with no security return.";
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.BackColor = Color.Transparent;
            label22.Font = new Font("Microsoft Tai Le", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label22.Location = new Point(40, 861);
            label22.Name = "label22";
            label22.Size = new Size(345, 29);
            label22.TabIndex = 23;
            label22.Text = "Suggestion or Feedback(If any)";
            // 
            // textBox1
            // 
            textBox1.BackColor = SystemColors.InactiveCaptionText;
            textBox1.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox1.ForeColor = SystemColors.MenuBar;
            textBox1.Location = new Point(37, 912);
            textBox1.Margin = new Padding(3, 4, 3, 4);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(333, 27);
            textBox1.TabIndex = 27;
            textBox1.Text = "Add Suggestion If Any";
            // 
            // button1
            // 
            button1.BackgroundImage = (Image)resources.GetObject("button1.BackgroundImage");
            button1.BackgroundImageLayout = ImageLayout.Stretch;
            button1.Font = new Font("Microsoft Tai Le", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(856, 898);
            button1.Margin = new Padding(3, 4, 3, 4);
            button1.Name = "button1";
            button1.Size = new Size(157, 84);
            button1.TabIndex = 28;
            button1.Text = "Print Form";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.BackgroundImage = (Image)resources.GetObject("button2.BackgroundImage");
            button2.BackgroundImageLayout = ImageLayout.Stretch;
            button2.Cursor = Cursors.Hand;
            button2.Font = new Font("Microsoft Tai Le", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.Location = new Point(1030, 898);
            button2.Margin = new Padding(3, 4, 3, 4);
            button2.Name = "button2";
            button2.Size = new Size(143, 84);
            button2.TabIndex = 29;
            button2.Text = "Go To Dashboard";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // FormE2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1240, 996);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(textBox1);
            Controls.Add(label22);
            Controls.Add(label21);
            Controls.Add(label20);
            Controls.Add(label19);
            Controls.Add(label18);
            Controls.Add(label17);
            Controls.Add(label16);
            Controls.Add(label15);
            Controls.Add(label14);
            Controls.Add(label13);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            Margin = new Padding(3, 4, 3, 4);
            MaximizeBox = false;
            Name = "FormE2";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Hostel Details";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}

