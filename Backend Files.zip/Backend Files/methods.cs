﻿using System;
using MySql.Data.MySqlClient;  // For MySQL

public static class UserName
{
    // Method to fetch username by CNIC as string
    public static string GetUserNameByCNIC(string cnic)
    {
        string username = string.Empty;

        // Replace with your actual connection string
        string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";

        // SQL query to fetch name using CNIC (stored as BIGINT, but we can pass it as a string)
        string query = "SELECT full_Name FROM users WHERE user_cnic = CAST(@cnic AS CHAR)";

        using (MySqlConnection conn = new MySqlConnection(connectionString)) // MySQL connection
        {
            try
            {
                conn.Open();

                using (MySqlCommand cmd = new MySqlCommand(query, conn))
                {
                    // Add parameter to avoid SQL injection
                    cmd.Parameters.AddWithValue("@cnic", cnic);

                    // Execute the query and get the result
                    username = cmd.ExecuteScalar()?.ToString();
                }
            }
            catch (Exception ex)
            {
                // Handle any errors (e.g., connection issues)
                Console.WriteLine("Error fetching username: " + ex.Message);
            }
        }

        return username;
    }

    internal static string GetUserNameByCNIC(long parsedCnic)
    {
        throw new NotImplementedException();
    }


    public static string GetUserRoleByCnic(string cnic)
    {
        string role = string.Empty;
        string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";  // Use your actual connection string

        using (MySqlConnection conn = new MySqlConnection(connectionString))
        {
            try
            {
                conn.Open();

                // Query to get the role of the user based on CNIC
                string query = "SELECT user_role FROM users WHERE user_cnic = @cnic";

                using (MySqlCommand cmd = new MySqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@cnic", cnic);

                    object result = cmd.ExecuteScalar();

                    if (result != null)
                    {
                        role = result.ToString();  // Role found
                    }
                    else
                    {
                        MessageBox.Show("User with this CNIC does not exist.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error retrieving user role: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        return role;
    }

    public static bool VerifyUserPassword(string cnic, string enteredPassword)
    {
        string connStr = "server=localhost;user=root;password=root;database=kbh_ms;";
        using (MySqlConnection conn = new MySqlConnection(connStr))
        {
            conn.Open();
            string query = "SELECT password FROM users WHERE user_cnic = @cnic and user_role = 'Manager'";
            using (MySqlCommand cmd = new MySqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@cnic", cnic);
                object result = cmd.ExecuteScalar();

                if (result != null)
                {
                    string actualPassword = result.ToString();
                    return actualPassword == enteredPassword;
                }
            }
        }
        return false;
    }


}
