﻿using form_2;

namespace KBH_MS
{
    partial class FormE3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtPaymentStatus = new TextBox();
            txtDueDate = new TextBox();
            txtPendingRent = new TextBox();
            txtCurrentMonth = new TextBox();
            label7 = new Label();
            label3 = new Label();
            label4 = new Label();
            label2 = new Label();
            dataGridView1 = new DataGridView();
            label6 = new Label();
            label5 = new Label();
            button3 = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(411, 9);
            label1.Name = "label1";
            label1.Size = new Size(408, 31);
            label1.TabIndex = 66;
            label1.Text = "Kamran Boys Hostel - Monthly Rents";
            // 
            // txtPaymentStatus
            // 
            txtPaymentStatus.BackColor = Color.Black;
            txtPaymentStatus.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold);
            txtPaymentStatus.ForeColor = Color.White;
            txtPaymentStatus.Location = new Point(296, 375);
            txtPaymentStatus.Name = "txtPaymentStatus";
            txtPaymentStatus.ReadOnly = true;
            txtPaymentStatus.Size = new Size(224, 38);
            txtPaymentStatus.TabIndex = 74;
            txtPaymentStatus.TextAlign = HorizontalAlignment.Center;
            // 
            // txtDueDate
            // 
            txtDueDate.BackColor = Color.Black;
            txtDueDate.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold);
            txtDueDate.ForeColor = Color.White;
            txtDueDate.Location = new Point(296, 307);
            txtDueDate.Name = "txtDueDate";
            txtDueDate.ReadOnly = true;
            txtDueDate.Size = new Size(224, 38);
            txtDueDate.TabIndex = 73;
            txtDueDate.TextAlign = HorizontalAlignment.Center;
            // 
            // txtPendingRent
            // 
            txtPendingRent.BackColor = Color.Black;
            txtPendingRent.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold);
            txtPendingRent.ForeColor = Color.White;
            txtPendingRent.Location = new Point(296, 240);
            txtPendingRent.Name = "txtPendingRent";
            txtPendingRent.ReadOnly = true;
            txtPendingRent.Size = new Size(224, 38);
            txtPendingRent.TabIndex = 72;
            txtPendingRent.TextAlign = HorizontalAlignment.Center;
            // 
            // txtCurrentMonth
            // 
            txtCurrentMonth.BackColor = Color.Black;
            txtCurrentMonth.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold);
            txtCurrentMonth.ForeColor = Color.White;
            txtCurrentMonth.Location = new Point(296, 181);
            txtCurrentMonth.Name = "txtCurrentMonth";
            txtCurrentMonth.ReadOnly = true;
            txtCurrentMonth.Size = new Size(224, 38);
            txtCurrentMonth.TabIndex = 71;
            txtCurrentMonth.TextAlign = HorizontalAlignment.Center;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.Transparent;
            label7.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.Location = new Point(92, 375);
            label7.Margin = new Padding(4, 0, 4, 0);
            label7.Name = "label7";
            label7.Size = new Size(183, 32);
            label7.TabIndex = 70;
            label7.Text = "Payment Status";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(92, 304);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(117, 32);
            label3.TabIndex = 69;
            label3.Text = "Due Date";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(92, 180);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(177, 32);
            label4.TabIndex = 67;
            label4.Text = "Current Month";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(92, 237);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(159, 32);
            label2.TabIndex = 75;
            label2.Text = "Pending Rent";
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(628, 146);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(495, 375);
            dataGridView1.TabIndex = 76;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.White;
            label6.Location = new Point(728, 102);
            label6.Name = "label6";
            label6.Size = new Size(300, 41);
            label6.TabIndex = 77;
            label6.Text = "Previous Transactions";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.White;
            label5.Location = new Point(222, 102);
            label5.Name = "label5";
            label5.Size = new Size(168, 41);
            label5.TabIndex = 79;
            label5.Text = "This Month";
            // 
            // button3
            // 
            button3.BackColor = Color.LightSalmon;
            button3.Cursor = Cursors.Hand;
            button3.Location = new Point(91, 443);
            button3.Margin = new Padding(3, 4, 3, 4);
            button3.Name = "button3";
            button3.Size = new Size(429, 78);
            button3.TabIndex = 80;
            button3.Text = "Go to Dashboard";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // FormE3
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.blurred_blue_gradient_wallpaper_preview;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1232, 703);
            Controls.Add(button3);
            Controls.Add(label5);
            Controls.Add(label6);
            Controls.Add(dataGridView1);
            Controls.Add(label2);
            Controls.Add(txtPaymentStatus);
            Controls.Add(txtDueDate);
            Controls.Add(txtPendingRent);
            Controls.Add(txtCurrentMonth);
            Controls.Add(label7);
            Controls.Add(label3);
            Controls.Add(label4);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            Name = "FormE3";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "FormE3";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }



        #endregion

        private Label label1;
        private TextBox txtPaymentStatus;
        private TextBox txtDueDate;
        private TextBox txtPendingRent;
        private TextBox txtCurrentMonth;
        private Label label7;
        private Label label3;
        private Label label4;
        private Label label2;
        private DataGridView dataGridView1;
        private Label label6;
        private Label label5;
        private Button button3;

        public EventHandler FormE3_Load { get; private set; }
    }
}