using form_2;
using hostelsystem;
using MySql.Data.MySqlClient;

namespace leavingcertificate
{
    public partial class FormE5 : Form
    {
        public FormE5()
        {
            InitializeComponent();
            LoadHostelLivingCertificate();
        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormE1 formE1 = new FormE1();
            this.Hide();
            formE1.ShowDialog();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void LoadHostelLivingCertificate()
        {
            string cnic = UserSession.CNIC;
            string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();


                    using (MySqlCommand cmd = new MySqlCommand("SELECT fullName, fatherName, joinDate FROM residents WHERE cnic = @cnic", conn))
                    {
                        cmd.Parameters.AddWithValue("@cnic", cnic);
                        using (MySqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                lblName.Text = reader["fullName"].ToString();
                                lblFatherName.Text = reader["fatherName"].ToString();
                                lblJoinDate.Text = Convert.ToDateTime(reader["joinDate"]).ToString("dd MMMM yyyy");
                            }
                            else
                            {
                                lblName.Text = "N/A";
                                lblFatherName.Text = "N/A";
                                lblJoinDate.Text = "N/A";
                            }
                        }
                    }

                    lblCurrentDate.Text = DateTime.Now.ToString("dd MMM yyyy");


                    string rentQuery = @"SELECT r.monthlyCharge 
                                 FROM allocations a
                                 JOIN rooms r ON a.room_id = r.roomNumber
                                 WHERE a.resident_cnic = @cnic AND a.deallocation_date IS NULL
                                 LIMIT 1";

                    using (MySqlCommand cmd = new MySqlCommand(rentQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@cnic", cnic);
                        object rentObj = cmd.ExecuteScalar();
                        if (rentObj != null)
                        {
                            lblCurrentRent.Text = "Rs. " + Convert.ToInt32(rentObj).ToString("N0");
                        }
                        else
                        {
                            lblCurrentRent.Text = "N/A";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading certificate data: " + ex.Message);
            }
        }

        private void lblCurrentRent_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
