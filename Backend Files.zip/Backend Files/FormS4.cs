﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KBH_Owner
{
    public partial class FormS4 : System.Windows.Forms.Form
    {
        public FormS4()
        {
            InitializeComponent();
        }

        private void FormS4_Load(object sender, EventArgs e)
        {
            LoadRentAmounts();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text))
            {
                MessageBox.Show("Please enter the new rent amount.");
                return;
            }

            if (!decimal.TryParse(textBox1.Text, out decimal newRent) || newRent < 0)
            {
                MessageBox.Show("Invalid rent amount entered.");
                return;
            }

            DialogResult result = MessageBox.Show(
                $"Are you sure you want to update the rent for all rooms of this type to Rs. {newRent}?",
                "Confirm Rent Update",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (result == DialogResult.No)
                return;

            string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";
            string query = "UPDATE rooms SET monthlyCharge = @newRent where maxCapacity=1";

            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                using (MySqlCommand cmd = new MySqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@newRent", newRent);
                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Rent updated successfully for all rooms of maximum capacity 1");
                        LoadRentAmounts();
                    }
                    else
                    {
                        MessageBox.Show("No rooms found to update.");
                    }
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox2.Text))
            {
                MessageBox.Show("Please enter the new rent amount.");
                return;
            }

            if (!decimal.TryParse(textBox2.Text, out decimal newRent) || newRent < 0)
            {
                MessageBox.Show("Invalid rent amount entered.");
                return;
            }

            DialogResult result = MessageBox.Show(
                $"Are you sure you want to update the rent for all rooms of this type to Rs. {newRent}?",
                "Confirm Rent Update",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (result == DialogResult.No)
                return;

            string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";
            string query = "UPDATE rooms SET monthlyCharge = @newRent where maxCapacity=2";

            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                using (MySqlCommand cmd = new MySqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@newRent", newRent);
                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Rent updated successfully for all rooms of maximum capacity 2");
                        LoadRentAmounts();
                    }
                    else
                    {
                        MessageBox.Show("No rooms found to update.");
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox4.Text))
            {
                MessageBox.Show("Please enter the new rent amount.");
                return;
            }

            if (!decimal.TryParse(textBox4.Text, out decimal newRent) || newRent < 0)
            {
                MessageBox.Show("Invalid rent amount entered.");
                return;
            }

            DialogResult result = MessageBox.Show(
                $"Are you sure you want to update the rent for all rooms of this type to Rs. {newRent}?",
                "Confirm Rent Update",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (result == DialogResult.No)
                return;

            string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";
            string query = "UPDATE rooms SET monthlyCharge = @newRent where maxCapacity=3";

            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                using (MySqlCommand cmd = new MySqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@newRent", newRent);
                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Rent updated successfully for all rooms with maximum capacity 3");
                        LoadRentAmounts();
                    }
                    else
                    {
                        MessageBox.Show("No rooms found to update.");
                    }
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox3.Text))
            {
                MessageBox.Show("Please enter the new rent amount.");
                return;
            }

            if (!decimal.TryParse(textBox4.Text, out decimal newRent) || newRent < 0)
            {
                MessageBox.Show("Invalid rent amount entered.");
                return;
            }

            DialogResult result = MessageBox.Show(
                $"Are you sure you want to update the rent for all rooms of this type to Rs. {newRent}?",
                "Confirm Rent Update",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (result == DialogResult.No)
                return;

            string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";
            string query = "UPDATE rooms SET monthlyCharge = @newRent where maxCapacity=4";

            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                using (MySqlCommand cmd = new MySqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@newRent", newRent);
                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Rent updated successfully for all rooms of maximum capacity 4");
                        LoadRentAmounts();
                    }
                    else
                    {
                        MessageBox.Show("No rooms found to update.");
                    }
                }
            }

        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox5.Text))
            {
                MessageBox.Show("Please enter the new rent amount.");
                return;
            }

            if (!decimal.TryParse(textBox5.Text, out decimal newRent) || newRent < 0)
            {
                MessageBox.Show("Invalid rent amount entered.");
                return;
            }

            DialogResult result = MessageBox.Show(
                $"Are you sure you want to update the rent for all rooms of this type to Rs. {newRent}?",
                "Confirm Rent Update",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (result == DialogResult.No)
                return;

            string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";
            string query = "UPDATE rooms SET monthlyCharge = @newRent where maxCapacity=5";

            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                using (MySqlCommand cmd = new MySqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@newRent", newRent);
                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Rent updated successfully for all rooms of maximum capacity 5");
                        LoadRentAmounts();
                    }
                    else
                    {
                        MessageBox.Show("No rooms found to update.");
                    }
                }
            }
        
    }

        private void LoadRentAmounts()
        {
            string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";

            string query = "SELECT maxCapacity, MAX(monthlyCharge) as monthlyCharge FROM rooms GROUP BY maxCapacity";

            Dictionary<int, Label> rentLabels = new Dictionary<int, Label>()
    {
        { 1, label10 },
        { 2, label11 },
        { 3, label12 },
        { 4, label13 },
        { 5, label14 }
    };

            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                using (MySqlCommand cmd = new MySqlCommand(query, conn))
                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        int roomType = reader.GetInt32("maxCapacity");
                        int rent = reader.GetInt32("monthlyCharge");

                        if (rentLabels.ContainsKey(roomType))
                        {
                            rentLabels[roomType].Text = $"Rs. {rent}";
                        }
                    }
                }
            }
        }

    }
}

