﻿namespace KBH_MS
{
    partial class RoomAllocation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBox2 = new TextBox();
            label2 = new Label();
            textBox1 = new TextBox();
            label1 = new Label();
            label3 = new Label();
            dateTimePicker1 = new DateTimePicker();
            button1 = new Button();
            dataGridView1 = new DataGridView();
            label4 = new Label();
            label5 = new Label();
            dataGridView2 = new DataGridView();
            button2 = new Button();
            comboBoxFilter = new ComboBox();
            cmbRoomFilter = new ComboBox();
            txtSearch = new TextBox();
            btnSearch = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).BeginInit();
            SuspendLayout();
            // 
            // textBox2
            // 
            textBox2.Cursor = Cursors.IBeam;
            textBox2.Location = new Point(908, 134);
            textBox2.MaxLength = 50;
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(223, 27);
            textBox2.TabIndex = 8;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(733, 133);
            label2.Name = "label2";
            label2.Size = new Size(152, 28);
            label2.TabIndex = 7;
            label2.Text = "Room Number ";
            // 
            // textBox1
            // 
            textBox1.Cursor = Cursors.IBeam;
            textBox1.Location = new Point(908, 90);
            textBox1.MaxLength = 13;
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(223, 27);
            textBox1.TabIndex = 6;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(733, 86);
            label1.Name = "label1";
            label1.Size = new Size(141, 28);
            label1.TabIndex = 5;
            label1.Text = "Resident CNIC";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(733, 178);
            label3.Name = "label3";
            label3.Size = new Size(156, 28);
            label3.TabIndex = 9;
            label3.Text = "Allocation Date ";
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(908, 179);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(223, 27);
            dateTimePicker1.TabIndex = 10;
            // 
            // button1
            // 
            button1.BackgroundImage = Properties.Resources.button_bg;
            button1.BackgroundImageLayout = ImageLayout.Stretch;
            button1.Cursor = Cursors.Hand;
            button1.Font = new Font("Segoe UI", 13.8F);
            button1.Location = new Point(733, 226);
            button1.Name = "button1";
            button1.Size = new Size(398, 43);
            button1.TabIndex = 16;
            button1.Text = "Allocate ";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(733, 380);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.Size = new Size(398, 275);
            dataGridView1.TabIndex = 17;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.White;
            label4.Location = new Point(850, 338);
            label4.Name = "label4";
            label4.Size = new Size(161, 28);
            label4.TabIndex = 18;
            label4.Text = "Available Rooms";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.White;
            label5.Location = new Point(220, 23);
            label5.Name = "label5";
            label5.Size = new Size(170, 28);
            label5.TabIndex = 20;
            label5.Text = "Allocation Record";
            // 
            // dataGridView2
            // 
            dataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView2.Location = new Point(52, 106);
            dataGridView2.Name = "dataGridView2";
            dataGridView2.ReadOnly = true;
            dataGridView2.RowHeadersWidth = 51;
            dataGridView2.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView2.Size = new Size(532, 508);
            dataGridView2.TabIndex = 19;
            dataGridView2.CellContentClick += dataGridView2_CellContentClick;
            // 
            // button2
            // 
            button2.BackgroundImage = Properties.Resources.button_bg;
            button2.BackgroundImageLayout = ImageLayout.Stretch;
            button2.Cursor = Cursors.Hand;
            button2.Font = new Font("Segoe UI", 13.8F);
            button2.Location = new Point(52, 629);
            button2.Name = "button2";
            button2.Size = new Size(532, 43);
            button2.TabIndex = 21;
            button2.Text = "De-allocate Selected";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // comboBoxFilter
            // 
            comboBoxFilter.FormattingEnabled = true;
            comboBoxFilter.Items.AddRange(new object[] { "All Residents", "Allocated Residents", "Unallocated Residents" });
            comboBoxFilter.Location = new Point(52, 72);
            comboBoxFilter.Name = "comboBoxFilter";
            comboBoxFilter.Size = new Size(120, 28);
            comboBoxFilter.TabIndex = 22;
            comboBoxFilter.Text = "Filter by allocation";
            comboBoxFilter.SelectedIndexChanged += comboBoxFilter_SelectedIndexChanged;
            // 
            // cmbRoomFilter
            // 
            cmbRoomFilter.FormattingEnabled = true;
            cmbRoomFilter.Items.AddRange(new object[] { "All Residents", "Allocated Residents", "Unallocated Residents" });
            cmbRoomFilter.Location = new Point(178, 72);
            cmbRoomFilter.Name = "cmbRoomFilter";
            cmbRoomFilter.Size = new Size(120, 28);
            cmbRoomFilter.TabIndex = 23;
            cmbRoomFilter.Text = "Filter by Rooms";
            cmbRoomFilter.SelectedIndexChanged += cmbRoomFilter_SelectedIndexChanged;
            // 
            // txtSearch
            // 
            txtSearch.Cursor = Cursors.IBeam;
            txtSearch.Location = new Point(304, 72);
            txtSearch.MaxLength = 13;
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(141, 27);
            txtSearch.TabIndex = 24;
            // 
            // btnSearch
            // 
            btnSearch.BackgroundImage = Properties.Resources.button_bg;
            btnSearch.BackgroundImageLayout = ImageLayout.Stretch;
            btnSearch.Cursor = Cursors.Hand;
            btnSearch.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnSearch.Location = new Point(451, 70);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(133, 30);
            btnSearch.TabIndex = 25;
            btnSearch.Text = "Search";
            btnSearch.UseVisualStyleBackColor = true;
            btnSearch.Click += btnSearch_Click;
            btnSearch.KeyDown += btnSearch_KeyDown;
            btnSearch.KeyPress += btnSearch_KeyPress;
            // 
            // RoomAllocation
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.blurred_blue_gradient_wallpaper_preview;
            BackgroundImageLayout = ImageLayout.Zoom;
            ClientSize = new Size(1232, 703);
            Controls.Add(btnSearch);
            Controls.Add(txtSearch);
            Controls.Add(cmbRoomFilter);
            Controls.Add(comboBoxFilter);
            Controls.Add(button2);
            Controls.Add(label5);
            Controls.Add(dataGridView2);
            Controls.Add(label4);
            Controls.Add(dataGridView1);
            Controls.Add(button1);
            Controls.Add(dateTimePicker1);
            Controls.Add(label3);
            Controls.Add(textBox2);
            Controls.Add(label2);
            Controls.Add(textBox1);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            MaximizeBox = false;
            Name = "RoomAllocation";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Allocate Room";
            Load += RoomAllocation_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBox2;
        private Label label2;
        private TextBox textBox1;
        private Label label1;
        private Label label3;
        private DateTimePicker dateTimePicker1;
        private Button button1;
        private DataGridView dataGridView1;
        private Label label4;
        private Label label5;
        private DataGridView dataGridView2;
        private Button button2;
        private ComboBox comboBoxFilter;
        private ComboBox cmbRoomFilter;
        private TextBox textBox3;
        private Button button3;
        private Button btnSearch;
        private TextBox txtSearch;
    }
}