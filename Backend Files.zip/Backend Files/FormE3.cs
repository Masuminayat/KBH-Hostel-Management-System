﻿using form_2;
using hostelsystem;
using Kamraan_Boys_Hostel;
using Kamran_Boys_Hostel;
using KBH_MS;
using KBH_Owner;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KBH_MS
{
    public partial class FormE3 : Form
    {
        public FormE3()
        {
            InitializeComponent();
            LoadRentDetailsForResident();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

            FormE1 formE1 = new FormE1();
            this.Hide();
            formE1.ShowDialog();

        }

       
       

        private void LoadRentDetailsForResident()
        {
            string cnic = UserSession.CNIC;
            string currentMonth = DateTime.Now.ToString("MMMM"); // e.g., May
            int currentYear = DateTime.Now.Year;

            string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();

                    // Load current month bill info
                    using (MySqlCommand cmd = new MySqlCommand(
                        @"SELECT bAmount, isPaid, issueDate 
                  FROM bills 
                  WHERE rCnic = @cnic AND bMonth = @month AND bYear = @year", conn))
                    {
                        cmd.Parameters.AddWithValue("@cnic", cnic);
                        cmd.Parameters.AddWithValue("@month", currentMonth);
                        cmd.Parameters.AddWithValue("@year", currentYear);

                        using (MySqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                txtCurrentMonth.Text = currentMonth;
                                txtPendingRent.Text = Convert.ToDecimal(reader["bAmount"]).ToString("N0");

                                DateTime issueDate = Convert.ToDateTime(reader["issueDate"]);
                                txtDueDate.Text = issueDate.AddDays(5).ToString("dd MMMM yyyy"); // e.g., 06 May 2024

                                txtPaymentStatus.Text = Convert.ToBoolean(reader["isPaid"]) ? "Paid" : "Unpaid";
                            }
                            else
                            {
                                txtCurrentMonth.Text = currentMonth;
                                txtPendingRent.Text = "N/A";
                                txtDueDate.Text = "N/A";
                                txtPaymentStatus.Text = "Not Issued";
                            }
                        }
                    }

                    // Load previous bills
                    using (MySqlCommand cmd = new MySqlCommand(
                        @"SELECT bMonth AS 'Month', bYear AS 'Year', bAmount AS 'Amount', 
                         IF(isPaid = 1, 'Paid', 'Unpaid') AS 'Status', 
                         DATE_FORMAT(issueDate, '%d %M %Y') AS 'Issued On'
                  FROM bills 
                  WHERE rCnic = @cnic 
                  ORDER BY billID DESC", conn))
                    {
                        cmd.Parameters.AddWithValue("@cnic", cnic);
                        using (MySqlDataAdapter adapter = new MySqlDataAdapter(cmd))
                        {
                            DataTable dt = new DataTable();
                            adapter.Fill(dt);
                            dataGridView1.DataSource = dt;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading rent details: " + ex.Message);
            }
        }

    }
}
