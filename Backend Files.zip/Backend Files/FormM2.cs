﻿using Microsoft.VisualBasic.ApplicationServices;
using MySql.Data.MySqlClient;
using Org.BouncyCastle.Asn1.Cmp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.ComponentModel.Design.ObjectSelectorEditor;

namespace Kamran_Boys_Hostel
{
    public partial class FormM2 : Form
    {
        public FormM2()
        {
            InitializeComponent();
        }

        private void FormS2_Load(object sender, EventArgs e)
        {
            // Replace with your actual connection string
            string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";

            // SQL query to fetch user details
            string query = "SELECT * from residents";

            // Create a DataTable to hold user data
            DataTable userTable = new DataTable();

            try
            {
                // Open a connection to the MySQL database
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();

                    // Use MySqlDataAdapter to fetch the data and fill it into the DataTable
                    using (MySqlDataAdapter da = new MySqlDataAdapter(query, conn))
                    {
                        da.Fill(userTable);
                    }
                }

                // Bind the DataTable to the DataGridView
                dataGridView1.DataSource = userTable;
            }
            catch (Exception ex)
            {
                // Handle any errors that occur during the database operation
                MessageBox.Show("Error fetching users: " + ex.Message);
            }
        }
        

        private void label2_Click(object sender, EventArgs e)
        {
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {


        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
                errorProvider1.SetError(textBox1, "Enter 13 digit CNIC Number without dashes");
            }
            else
            {
                errorProvider1.SetError(textBox1, "");
            }
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
                errorProvider2.SetError(textBox4, "Enter phone number without any character/letter");
            }
            else
            {
                errorProvider2.SetError(textBox4, ""); // Clear error
            }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar) && e.KeyChar != ' ')
            {
                e.Handled = true; // Block invalid input
                errorProvider3.SetError(textBox2, "Only letters and spaces are allowed");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";
            string updateQuery = @"UPDATE residents SET 
                            fullName = @fullName,
                            fatherName = @fatherName,
                            region = @region,
                            email = @email,
                            phoneNo = @phoneNo,
                            fullAddress = @fullAddress,
                            rStatus = @rStatus,
                            joinDate = @joinDate
                        WHERE cnic = @cnic";

            // Ensure edits are committed to the DataTable
            dataGridView1.EndEdit();

            DataTable dt = (DataTable)dataGridView1.DataSource;

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();

                    foreach (DataRow row in dt.Rows)
                    {
                        if (row.RowState == DataRowState.Modified)
                        {
                            using (MySqlCommand cmd = new MySqlCommand(updateQuery, conn))
                            {
                                cmd.Parameters.AddWithValue("@fullName", row["fullName"]);
                                cmd.Parameters.AddWithValue("@fatherName", row["fatherName"]);
                                cmd.Parameters.AddWithValue("@region", row["region"]);
                                cmd.Parameters.AddWithValue("@email", row["email"]);
                                cmd.Parameters.AddWithValue("@phoneNo", row["phoneNo"]);
                                cmd.Parameters.AddWithValue("@fullAddress", row["fullAddress"]);
                                cmd.Parameters.AddWithValue("@rStatus", row["rStatus"]);
                                cmd.Parameters.AddWithValue("@joinDate", row["joinDate"]);
                                cmd.Parameters.AddWithValue("@cnic", row["cnic"]);
                                cmd.ExecuteNonQuery();
                            }
                        }
                    }

                    MessageBox.Show("Changes saved successfully!");
                    dt.AcceptChanges(); // Clear modified flags
                }


            }

            catch (Exception ex)
            {
                MessageBox.Show("Error saving changes: " + ex.Message);
            }


        }
        

        private void button1_Click(object sender, EventArgs e)
        {
            {
                // Connection string to your MySQL database
                string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";

                // SQL INSERT statement with parameters
                string insertQuery = @"INSERT INTO residents
                (cnic, fullName, fatherName, region, email, phoneNo, fullAddress, rStatus, joinDate) 
                VALUES 
                (@cnic, @fullName, @fatherName, @region, @email, @phone, @address, @status, @joinDate)";

                try
                {
                    using (MySqlConnection conn = new MySqlConnection(connectionString))
                    {
                        conn.Open();
                        using (MySqlCommand cmd = new MySqlCommand(insertQuery, conn))
                        {
                            // Assign values from form controls to parameters
                            cmd.Parameters.AddWithValue("@cnic", Convert.ToInt64(textBox1.Text));
                            cmd.Parameters.AddWithValue("@fullName", textBox2.Text);
                            cmd.Parameters.AddWithValue("@fatherName", textBox7.Text);
                            cmd.Parameters.AddWithValue("@region", comboBox3.SelectedItem?.ToString());
                            cmd.Parameters.AddWithValue("@email", textBox5.Text);
                            cmd.Parameters.AddWithValue("@phone", textBox4.Text);
                            cmd.Parameters.AddWithValue("@address", richTextBox1.Text);
                            cmd.Parameters.AddWithValue("@status", comboBox1.SelectedItem?.ToString());
                            cmd.Parameters.AddWithValue("@joinDate", dateTimePicker1.Value.Date);

                            // Execute the command
                            int rowsAffected = cmd.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("New Resident added successfully!");
                            }
                            else
                            {
                                MessageBox.Show("Insertion failed. Please check your input.");
                            }
                        }

                        // Insert into users table after successful resident insertion
                        string insertUserQuery = @"INSERT INTO users
                           (user_cnic, full_Name, user_role, email, phone_no, password)
                            VALUES (@cnic, @fullName, 'Staying Resident', @email, @phone, @password)";

                        using (MySqlCommand userCmd = new MySqlCommand(insertUserQuery, conn))
                        {
                            userCmd.Parameters.AddWithValue("@cnic", Convert.ToInt64(textBox1.Text));
                            userCmd.Parameters.AddWithValue("@fullName", textBox2.Text);
                            userCmd.Parameters.AddWithValue("@email", textBox5.Text);
                            userCmd.Parameters.AddWithValue("@phone", textBox4.Text);
                            userCmd.Parameters.AddWithValue("@password", textBox4.Text); // Phone number as default password

                            userCmd.ExecuteNonQuery();
                        }

                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error adding new resident: " + ex.Message);
                }
            }
        }
    }
    }

