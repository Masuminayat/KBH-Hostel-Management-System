﻿namespace KBH_Owner
{
    partial class FormS1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormS1));
            button7 = new Button();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            button4 = new Button();
            button5 = new Button();
            lblResidentsStaying = new Label();
            lblRentCollected = new Label();
            button8 = new Button();
            lblRentDue = new Label();
            button9 = new Button();
            lblExpenses = new Label();
            button10 = new Button();
            lblNetProfit = new Label();
            button11 = new Button();
            lblMonthlyVisits = new Label();
            button12 = new Button();
            button6 = new Button();
            label8 = new Label();
            label14 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // button7
            // 
            button7.BackColor = Color.FromArgb(0, 0, 192);
            button7.Cursor = Cursors.Hand;
            button7.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold);
            button7.ForeColor = SystemColors.ButtonHighlight;
            button7.Location = new Point(96, 44);
            button7.Name = "button7";
            button7.Size = new Size(119, 44);
            button7.TabIndex = 15;
            button7.Text = "Logout";
            button7.UseVisualStyleBackColor = false;
            button7.Click += button7_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Cursor = Cursors.Hand;
            label1.Font = new Font("Bahnschrift", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(98, 15);
            label1.Name = "label1";
            label1.Size = new Size(110, 22);
            label1.TabIndex = 14;
            label1.Text = "View Profile";
            label1.Click += label1_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Transparent;
            pictureBox1.Cursor = Cursors.Hand;
            pictureBox1.Image = KBH_MS.Properties.Resources.computer_icons_avatar_male_user_profile_png_favpng_ycgruUsQBHhtGyGKfw7fWCtgN_removebg_preview;
            pictureBox1.Location = new Point(12, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(78, 78);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 13;
            pictureBox1.TabStop = false;
            // 
            // button3
            // 
            button3.BackColor = Color.FromArgb(192, 255, 255);
            button3.Cursor = Cursors.Hand;
            button3.Font = new Font("Corbel", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button3.Location = new Point(98, 356);
            button3.Name = "button3";
            button3.Size = new Size(201, 93);
            button3.TabIndex = 18;
            button3.Text = "Adjust Rent";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(192, 255, 255);
            button2.Cursor = Cursors.Hand;
            button2.Font = new Font("Corbel", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.Location = new Point(96, 242);
            button2.Name = "button2";
            button2.Size = new Size(201, 90);
            button2.TabIndex = 17;
            button2.Text = "Rooms Management";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(192, 255, 255);
            button1.Cursor = Cursors.Hand;
            button1.Font = new Font("Corbel", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(98, 473);
            button1.Name = "button1";
            button1.Size = new Size(201, 87);
            button1.TabIndex = 16;
            button1.Text = "Reports";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button4
            // 
            button4.BackColor = Color.FromArgb(192, 255, 255);
            button4.Cursor = Cursors.Hand;
            button4.Font = new Font("Corbel", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button4.Location = new Point(96, 119);
            button4.Name = "button4";
            button4.Size = new Size(201, 93);
            button4.TabIndex = 19;
            button4.Text = "Users Management";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // button5
            // 
            button5.BackColor = Color.FromArgb(192, 255, 255);
            button5.Cursor = Cursors.Hand;
            button5.Font = new Font("Corbel", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button5.Location = new Point(98, 595);
            button5.Name = "button5";
            button5.Size = new Size(201, 87);
            button5.TabIndex = 20;
            button5.Text = "Warden Controls";
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            // 
            // lblResidentsStaying
            // 
            lblResidentsStaying.AutoSize = true;
            lblResidentsStaying.BackColor = Color.Gainsboro;
            lblResidentsStaying.Font = new Font("Microsoft YaHei UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblResidentsStaying.Location = new Point(622, 242);
            lblResidentsStaying.Name = "lblResidentsStaying";
            lblResidentsStaying.Size = new Size(51, 37);
            lblResidentsStaying.TabIndex = 22;
            lblResidentsStaying.Text = "05";
            lblResidentsStaying.Click += label3_Click;
            // 
            // lblRentCollected
            // 
            lblRentCollected.AutoSize = true;
            lblRentCollected.BackColor = Color.Gainsboro;
            lblRentCollected.Font = new Font("Microsoft YaHei UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblRentCollected.Location = new Point(622, 396);
            lblRentCollected.Name = "lblRentCollected";
            lblRentCollected.Size = new Size(150, 37);
            lblRentCollected.TabIndex = 24;
            lblRentCollected.Text = "5000 PKR";
            // 
            // button8
            // 
            button8.BackColor = Color.Black;
            button8.Font = new Font("Microsoft YaHei", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button8.ForeColor = Color.White;
            button8.Location = new Point(433, 366);
            button8.Name = "button8";
            button8.Size = new Size(183, 98);
            button8.TabIndex = 23;
            button8.Text = "Monthly Rent Collected";
            button8.UseVisualStyleBackColor = false;
            // 
            // lblRentDue
            // 
            lblRentDue.AutoSize = true;
            lblRentDue.BackColor = Color.Gainsboro;
            lblRentDue.Font = new Font("Microsoft YaHei UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblRentDue.Location = new Point(1047, 396);
            lblRentDue.Name = "lblRentDue";
            lblRentDue.Size = new Size(150, 37);
            lblRentDue.TabIndex = 26;
            lblRentDue.Text = "5000 PKR";
            // 
            // button9
            // 
            button9.BackColor = Color.Black;
            button9.Font = new Font("Microsoft YaHei", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button9.ForeColor = Color.White;
            button9.Location = new Point(858, 372);
            button9.Name = "button9";
            button9.Size = new Size(183, 95);
            button9.TabIndex = 25;
            button9.Text = "Due Rent";
            button9.UseVisualStyleBackColor = false;
            // 
            // lblExpenses
            // 
            lblExpenses.AutoSize = true;
            lblExpenses.BackColor = Color.Gainsboro;
            lblExpenses.Font = new Font("Microsoft YaHei UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblExpenses.Location = new Point(622, 559);
            lblExpenses.Name = "lblExpenses";
            lblExpenses.Size = new Size(150, 37);
            lblExpenses.TabIndex = 28;
            lblExpenses.Text = "5000 PKR";
            // 
            // button10
            // 
            button10.BackColor = Color.Black;
            button10.Font = new Font("Microsoft YaHei", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button10.ForeColor = Color.White;
            button10.Location = new Point(433, 527);
            button10.Name = "button10";
            button10.Size = new Size(183, 102);
            button10.TabIndex = 27;
            button10.Text = "Expenses this month";
            button10.UseVisualStyleBackColor = false;
            // 
            // lblNetProfit
            // 
            lblNetProfit.AutoSize = true;
            lblNetProfit.BackColor = Color.Gainsboro;
            lblNetProfit.Font = new Font("Microsoft YaHei UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblNetProfit.Location = new Point(1047, 559);
            lblNetProfit.Name = "lblNetProfit";
            lblNetProfit.Size = new Size(150, 37);
            lblNetProfit.TabIndex = 30;
            lblNetProfit.Text = "5000 PKR";
            // 
            // button11
            // 
            button11.BackColor = Color.Black;
            button11.Font = new Font("Microsoft YaHei", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button11.ForeColor = Color.White;
            button11.Location = new Point(858, 527);
            button11.Name = "button11";
            button11.Size = new Size(183, 102);
            button11.TabIndex = 29;
            button11.Text = "Net Profit";
            button11.UseVisualStyleBackColor = false;
            // 
            // lblMonthlyVisits
            // 
            lblMonthlyVisits.AutoSize = true;
            lblMonthlyVisits.BackColor = Color.Gainsboro;
            lblMonthlyVisits.Font = new Font("Microsoft YaHei UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblMonthlyVisits.Location = new Point(1051, 242);
            lblMonthlyVisits.Name = "lblMonthlyVisits";
            lblMonthlyVisits.Size = new Size(51, 37);
            lblMonthlyVisits.TabIndex = 32;
            lblMonthlyVisits.Text = "05";
            // 
            // button12
            // 
            button12.BackColor = Color.Black;
            button12.Font = new Font("Microsoft YaHei", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button12.ForeColor = Color.White;
            button12.Location = new Point(858, 220);
            button12.Name = "button12";
            button12.Size = new Size(183, 98);
            button12.TabIndex = 31;
            button12.Text = "Monthly Visits";
            button12.UseVisualStyleBackColor = false;
            // 
            // button6
            // 
            button6.BackColor = Color.Black;
            button6.Font = new Font("Microsoft YaHei", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button6.ForeColor = Color.White;
            button6.Location = new Point(433, 220);
            button6.Name = "button6";
            button6.Size = new Size(183, 98);
            button6.TabIndex = 33;
            button6.Text = "Residents Staying";
            button6.UseVisualStyleBackColor = false;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.Transparent;
            label8.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.Location = new Point(385, 15);
            label8.Name = "label8";
            label8.Size = new Size(544, 38);
            label8.TabIndex = 34;
            label8.Text = "Kamran Boys Hostel - Owner Dashboard";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.BackColor = Color.Transparent;
            label14.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label14.ForeColor = Color.White;
            label14.Location = new Point(651, 140);
            label14.Name = "label14";
            label14.Size = new Size(343, 41);
            label14.TabIndex = 56;
            label14.Text = "Quick Monthly Overview";
            // 
            // FormS1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1234, 703);
            Controls.Add(label14);
            Controls.Add(label8);
            Controls.Add(button6);
            Controls.Add(lblMonthlyVisits);
            Controls.Add(button12);
            Controls.Add(lblNetProfit);
            Controls.Add(button11);
            Controls.Add(lblExpenses);
            Controls.Add(button10);
            Controls.Add(lblRentDue);
            Controls.Add(button9);
            Controls.Add(lblRentCollected);
            Controls.Add(button8);
            Controls.Add(lblResidentsStaying);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(button7);
            Controls.Add(label1);
            Controls.Add(pictureBox1);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            MaximizeBox = false;
            Name = "FormS1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Admin-Dashboard";
            Load += FormS1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button7;
        private Label label1;
        private PictureBox pictureBox1;
        private Button button3;
        private Button button2;
        private Button button1;
        private Button button4;
        private Button button5;
        private Label lblResidentsStaying;
        private Label lblRentCollected;
        private Button button8;
        private Label lblRentDue;
        private Button button9;
        private Label lblExpenses;
        private Button button10;
        private Label lblNetProfit;
        private Button button11;
        private Label lblMonthlyVisits;
        private Button button12;
        private Button button6;
        private Label label8;
        private Label label14;
    }
}
