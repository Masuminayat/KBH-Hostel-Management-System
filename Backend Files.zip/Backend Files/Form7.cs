﻿using KBH_Owner;
using form_2;
using KBH_MS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kamran_Boys_Hostel
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            this.Hide();
            form2.ShowDialog();
            this.Show(); // Show Form2 again when Form3 closes
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormS1 formS1 = new FormS1();
            this.Hide();
            formS1.ShowDialog();
            this.Show(); // Show Form2 again when Form3 closes
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FormM1 formM1 = new FormM1();
            this.Hide();
            formM1.ShowDialog();
            this.Show(); // Show Form2 again when Form3 closes
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FormE1 formE1 = new FormE1();
            this.Hide();
            formE1.ShowDialog();
            this.Show(); // Show Form2 again when Form3 closes
        }
    }
}
