﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kamran_Boys_Hostel
{
    public partial class FormM6 : Form
    {
        public FormM6()
        {
            InitializeComponent();
            LoadAnnouncements();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string heading = textBox1.Text.Trim();
            string description = textBox5.Text.Trim();
            string date = dateTimePicker1.Value.ToString("MM-dd-yyyy"); // Formatting the date to match the MySQL format

            if (string.IsNullOrEmpty(heading) || string.IsNullOrEmpty(description))
            {
                MessageBox.Show("Please fill in both Heading and Description.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";

            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                try
                {
                    conn.Open();

                    // Get the user name from the session (you can use your method here)
                    string submittedBy = UserName.GetUserNameByCNIC(UserSession.CNIC) + " (" + UserName.GetUserRoleByCnic(UserSession.CNIC) + ") "; // Assuming UserSession contains the current user's name

                    // Insert announcement query
                    string insertQuery = @"
            INSERT INTO announcements (annBy, annHead, annDate, annDesc)
            VALUES (@annBy, @annHead, @annDate, @annDesc)";

                    using (MySqlCommand cmd = new MySqlCommand(insertQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@annBy", submittedBy);
                        cmd.Parameters.AddWithValue("@annHead", heading);
                        cmd.Parameters.AddWithValue("@annDate", date);
                        cmd.Parameters.AddWithValue("@annDesc", description);

                        cmd.ExecuteNonQuery();
                    }

                    MessageBox.Show("Announcement added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    // Clear form fields after successful submission
                    LoadAnnouncements();
                    textBox1.Clear();
                    textBox5.Clear();

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error adding announcement: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

       private void LoadAnnouncements()
        {
            string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";

            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string userName = UserName.GetUserNameByCNIC(UserSession.CNIC);
                    string selectQuery = " SELECT annID, annDate, annBy, annHead, annDesc FROM announcements ORDER BY annID DESC ";
                    MySqlDataAdapter dataAdapter = new MySqlDataAdapter(selectQuery, conn);
                    DataTable dataTable = new DataTable();
                    dataAdapter.Fill(dataTable);

                    // Bind the data to the DataGridView
                    dataGridView1.DataSource = dataTable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading announcements: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                DialogResult result = MessageBox.Show("Are you sure you want to delete this announcement?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (result == DialogResult.Yes)
                {
                    int selectedRowIndex = dataGridView1.SelectedRows[0].Index;
                    int annID = Convert.ToInt32(dataGridView1.Rows[selectedRowIndex].Cells["annID"].Value);

                    string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";

                    using (MySqlConnection conn = new MySqlConnection(connectionString))
                    {
                        try
                        {
                            conn.Open();

                            string deleteQuery = "DELETE FROM announcements WHERE annID = @annID";
                            using (MySqlCommand cmd = new MySqlCommand(deleteQuery, conn))
                            {
                                cmd.Parameters.AddWithValue("@annID", annID);
                                cmd.ExecuteNonQuery();
                            }

                            MessageBox.Show("Announcement deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            // Refresh DataGridView to reflect changes
                            LoadAnnouncements();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error deleting announcement: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select an announcement to delete.", "Selection Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

