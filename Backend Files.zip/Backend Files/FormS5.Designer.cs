﻿namespace KBH_Owner
{
    partial class FormS5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label3 = new Label();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            label1 = new Label();
            label2 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            label11 = new Label();
            label12 = new Label();
            label13 = new Label();
            button10 = new Button();
            button11 = new Button();
            dateTimePicker1 = new DateTimePicker();
            dateTimePicker2 = new DateTimePicker();
            button12 = new Button();
            label14 = new Label();
            label15 = new Label();
            button13 = new Button();
            SuspendLayout();
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(362, 9);
            label3.Name = "label3";
            label3.Size = new Size(514, 38);
            label3.TabIndex = 22;
            label3.Text = "Kamran Boys Hostel - Reports Section";
            // 
            // button1
            // 
            button1.BackColor = Color.Black;
            button1.Font = new Font("Microsoft YaHei", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.White;
            button1.Location = new Point(922, 115);
            button1.Name = "button1";
            button1.Size = new Size(183, 102);
            button1.TabIndex = 29;
            button1.Text = "Students Left";
            button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            button2.BackColor = Color.Black;
            button2.Font = new Font("Microsoft YaHei", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.ForeColor = Color.White;
            button2.Location = new Point(598, 115);
            button2.Name = "button2";
            button2.Size = new Size(183, 102);
            button2.TabIndex = 30;
            button2.Text = "Newly Joined";
            button2.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            button3.BackColor = Color.Black;
            button3.Font = new Font("Microsoft YaHei", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button3.ForeColor = Color.White;
            button3.Location = new Point(296, 115);
            button3.Name = "button3";
            button3.Size = new Size(183, 102);
            button3.TabIndex = 31;
            button3.Text = "Total Students";
            button3.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Microsoft YaHei UI", 12F, FontStyle.Bold);
            label1.ForeColor = Color.White;
            label1.Location = new Point(481, 151);
            label1.Name = "label1";
            label1.Size = new Size(36, 27);
            label1.TabIndex = 32;
            label1.Text = "05";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Microsoft YaHei UI", 12F, FontStyle.Bold);
            label2.ForeColor = Color.White;
            label2.Location = new Point(787, 155);
            label2.Name = "label2";
            label2.Size = new Size(36, 27);
            label2.TabIndex = 33;
            label2.Text = "05";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Microsoft YaHei UI", 12F, FontStyle.Bold);
            label4.ForeColor = Color.White;
            label4.Location = new Point(1111, 155);
            label4.Name = "label4";
            label4.Size = new Size(36, 27);
            label4.TabIndex = 34;
            label4.Text = "50";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Microsoft YaHei UI", 12F, FontStyle.Bold);
            label5.ForeColor = Color.White;
            label5.Location = new Point(1111, 441);
            label5.Name = "label5";
            label5.Size = new Size(36, 27);
            label5.TabIndex = 40;
            label5.Text = "50";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Font = new Font("Microsoft YaHei UI", 12F, FontStyle.Bold);
            label6.ForeColor = Color.White;
            label6.Location = new Point(787, 441);
            label6.Name = "label6";
            label6.Size = new Size(36, 27);
            label6.TabIndex = 39;
            label6.Text = "05";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.Transparent;
            label7.Font = new Font("Microsoft YaHei UI", 12F, FontStyle.Bold);
            label7.ForeColor = Color.White;
            label7.Location = new Point(482, 441);
            label7.Name = "label7";
            label7.Size = new Size(36, 27);
            label7.TabIndex = 38;
            label7.Text = "05";
            // 
            // button4
            // 
            button4.BackColor = Color.Black;
            button4.Font = new Font("Microsoft YaHei", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button4.ForeColor = Color.White;
            button4.Location = new Point(296, 401);
            button4.Name = "button4";
            button4.Size = new Size(183, 102);
            button4.TabIndex = 37;
            button4.Text = "Total Rent";
            button4.UseVisualStyleBackColor = false;
            // 
            // button5
            // 
            button5.BackColor = Color.Black;
            button5.Font = new Font("Microsoft YaHei", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button5.ForeColor = Color.White;
            button5.Location = new Point(598, 401);
            button5.Name = "button5";
            button5.Size = new Size(183, 102);
            button5.TabIndex = 36;
            button5.Text = "Collected Rent";
            button5.UseVisualStyleBackColor = false;
            // 
            // button6
            // 
            button6.BackColor = Color.Black;
            button6.Font = new Font("Microsoft YaHei", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button6.ForeColor = Color.White;
            button6.Location = new Point(922, 401);
            button6.Name = "button6";
            button6.Size = new Size(183, 102);
            button6.TabIndex = 35;
            button6.Text = "Pending Rent";
            button6.UseVisualStyleBackColor = false;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.Transparent;
            label8.Font = new Font("Microsoft YaHei UI", 12F, FontStyle.Bold);
            label8.ForeColor = Color.White;
            label8.Location = new Point(1111, 595);
            label8.Name = "label8";
            label8.Size = new Size(36, 27);
            label8.TabIndex = 46;
            label8.Text = "50";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.Transparent;
            label9.Font = new Font("Microsoft YaHei UI", 12F, FontStyle.Bold);
            label9.ForeColor = Color.White;
            label9.Location = new Point(787, 587);
            label9.Name = "label9";
            label9.Size = new Size(36, 27);
            label9.TabIndex = 45;
            label9.Text = "05";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.BackColor = Color.Transparent;
            label10.Font = new Font("Microsoft YaHei UI", 12F, FontStyle.Bold);
            label10.ForeColor = Color.White;
            label10.Location = new Point(482, 587);
            label10.Name = "label10";
            label10.Size = new Size(36, 27);
            label10.TabIndex = 44;
            label10.Text = "05";
            // 
            // button7
            // 
            button7.BackColor = Color.Black;
            button7.Font = new Font("Microsoft YaHei", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button7.ForeColor = Color.White;
            button7.Location = new Point(296, 555);
            button7.Name = "button7";
            button7.Size = new Size(183, 102);
            button7.TabIndex = 43;
            button7.Text = "Total Income";
            button7.UseVisualStyleBackColor = false;
            // 
            // button8
            // 
            button8.BackColor = Color.Black;
            button8.Font = new Font("Microsoft YaHei", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button8.ForeColor = Color.White;
            button8.Location = new Point(598, 555);
            button8.Name = "button8";
            button8.Size = new Size(183, 102);
            button8.TabIndex = 42;
            button8.Text = "Net Expenses";
            button8.UseVisualStyleBackColor = false;
            // 
            // button9
            // 
            button9.BackColor = Color.Black;
            button9.Font = new Font("Microsoft YaHei", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button9.ForeColor = Color.White;
            button9.Location = new Point(922, 555);
            button9.Name = "button9";
            button9.Size = new Size(183, 102);
            button9.TabIndex = 41;
            button9.Text = "Net Profit";
            button9.UseVisualStyleBackColor = false;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.BackColor = Color.Transparent;
            label11.Font = new Font("Microsoft YaHei UI", 13.8F);
            label11.ForeColor = Color.Yellow;
            label11.Location = new Point(296, 79);
            label11.Name = "label11";
            label11.Size = new Size(112, 30);
            label11.TabIndex = 47;
            label11.Text = "Analytics";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.BackColor = Color.Transparent;
            label12.Font = new Font("Microsoft YaHei UI", 13.8F);
            label12.ForeColor = Color.Yellow;
            label12.Location = new Point(296, 368);
            label12.Name = "label12";
            label12.Size = new Size(192, 30);
            label12.TabIndex = 48;
            label12.Text = "Rental Overview";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.BackColor = Color.Transparent;
            label13.Font = new Font("Microsoft YaHei UI", 13.8F);
            label13.ForeColor = Color.Yellow;
            label13.Location = new Point(296, 523);
            label13.Name = "label13";
            label13.Size = new Size(218, 30);
            label13.TabIndex = 49;
            label13.Text = "Financial Overview";
            // 
            // button10
            // 
            button10.BackColor = Color.FromArgb(192, 255, 255);
            button10.Cursor = Cursors.Hand;
            button10.Font = new Font("Corbel", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button10.Location = new Point(14, 579);
            button10.Name = "button10";
            button10.Size = new Size(237, 93);
            button10.TabIndex = 51;
            button10.Text = "This Year";
            button10.UseVisualStyleBackColor = false;
            // 
            // button11
            // 
            button11.BackColor = Color.FromArgb(192, 255, 255);
            button11.Cursor = Cursors.Hand;
            button11.Font = new Font("Corbel", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button11.Location = new Point(14, 463);
            button11.Name = "button11";
            button11.Size = new Size(237, 90);
            button11.TabIndex = 50;
            button11.Text = "This Month";
            button11.UseVisualStyleBackColor = false;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(12, 155);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(239, 27);
            dateTimePicker1.TabIndex = 52;
            // 
            // dateTimePicker2
            // 
            dateTimePicker2.Location = new Point(14, 218);
            dateTimePicker2.Name = "dateTimePicker2";
            dateTimePicker2.Size = new Size(238, 27);
            dateTimePicker2.TabIndex = 53;
            // 
            // button12
            // 
            button12.BackColor = Color.FromArgb(192, 255, 255);
            button12.Cursor = Cursors.Hand;
            button12.Font = new Font("Corbel", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button12.Location = new Point(12, 275);
            button12.Name = "button12";
            button12.Size = new Size(241, 41);
            button12.TabIndex = 54;
            button12.Text = "Filter";
            button12.UseVisualStyleBackColor = false;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.BackColor = Color.Transparent;
            label14.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label14.ForeColor = Color.White;
            label14.Location = new Point(62, 419);
            label14.Name = "label14";
            label14.Size = new Size(139, 31);
            label14.TabIndex = 55;
            label14.Text = "Quick Filters";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.BackColor = Color.Transparent;
            label15.Font = new Font("Microsoft YaHei UI", 12F, FontStyle.Bold);
            label15.ForeColor = Color.White;
            label15.Location = new Point(485, 282);
            label15.Name = "label15";
            label15.Size = new Size(36, 27);
            label15.TabIndex = 57;
            label15.Text = "50";
            // 
            // button13
            // 
            button13.BackColor = Color.Black;
            button13.Font = new Font("Microsoft YaHei", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button13.ForeColor = Color.White;
            button13.Location = new Point(296, 242);
            button13.Name = "button13";
            button13.Size = new Size(183, 102);
            button13.TabIndex = 56;
            button13.Text = "Visits";
            button13.UseVisualStyleBackColor = false;
            // 
            // FormS5
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = KBH_MS.Properties.Resources.blurred_blue_gradient_wallpaper_preview;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1232, 703);
            Controls.Add(label15);
            Controls.Add(button13);
            Controls.Add(label14);
            Controls.Add(button12);
            Controls.Add(dateTimePicker2);
            Controls.Add(dateTimePicker1);
            Controls.Add(button10);
            Controls.Add(button11);
            Controls.Add(label13);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(label8);
            Controls.Add(label9);
            Controls.Add(label10);
            Controls.Add(button7);
            Controls.Add(button8);
            Controls.Add(button9);
            Controls.Add(label5);
            Controls.Add(label6);
            Controls.Add(label7);
            Controls.Add(button4);
            Controls.Add(button5);
            Controls.Add(button6);
            Controls.Add(label4);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label3);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            MaximizeBox = false;
            Name = "FormS5";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Reports";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label3;
        private Button button1;
        private Button button2;
        private Button button3;
        private Label label1;
        private Label label2;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Button button4;
        private Button button5;
        private Button button6;
        private Label label8;
        private Label label9;
        private Label label10;
        private Button button7;
        private Button button8;
        private Button button9;
        private Label label11;
        private Label label12;
        private Label label13;
        private Button button10;
        private Button button11;
        private DateTimePicker dateTimePicker1;
        private DateTimePicker dateTimePicker2;
        private Button button12;
        private Label label14;
        private Label label15;
        private Button button13;
    }
}