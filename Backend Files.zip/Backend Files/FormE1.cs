using announcements;
using HostelDetails;
using hostelsystem;
using Kamraan_Boys_Hostel;
using KBH_MS;
using leavingcertificate;
using MySql.Data.MySqlClient;
using requestmaintenance;


namespace form_2
{
    public partial class FormE1 : Form
    {
        public FormE1()
        {
            InitializeComponent();
        }


        private void button5_Click(object sender, EventArgs e)
        {
            FormE5 formE5 = new FormE5();
            this.Hide();
            formE5.ShowDialog();

        }

        private void button6_Click(object sender, EventArgs e)
        {
            FormE6 formE6 = new FormE6();
            this.Hide();
            formE6.ShowDialog();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            LoadResidentDashboard();

           /* string cnic = UserSession.CNIC;
            string username = UserName.GetUserNameByCNIC(cnic);
            // Display the fetched username in the text box
            textBox1.Text = username ?? "Name not found";  // Handle the case if no name is found*/
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            this.Hide();
            form1.ShowDialog();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {
            FormJ7 formJ7 = new FormJ7();
            this.Hide();
            formJ7.ShowDialog();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            FormE2 formE2 = new FormE2();
            this.Hide();
            formE2.ShowDialog();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            FormE4 formE4 = new FormE4();
            this.Hide();
            formE4.ShowDialog();
            this.Show();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            FormE3 formE3 = new FormE3();
            this.Hide();
            formE3.ShowDialog();
            this.Show();

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }




        private void LoadResidentDashboard()
        {
            string cnic = UserSession.CNIC;
            string month = DateTime.Now.ToString("MMMM"); // e.g., May
            int year = DateTime.Now.Year;

            string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();

                    // 1. Full Name & Joining Date
                    using (MySqlCommand cmd = new MySqlCommand("SELECT fullName, joinDate FROM residents WHERE cnic = @cnic", conn))
                    {
                        cmd.Parameters.AddWithValue("@cnic", cnic);
                        using (MySqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                txtFullName.Text = reader["fullName"].ToString();
                                txtJoinDate.Text = Convert.ToDateTime(reader["joinDate"]).ToString("dd MMMM yyyy");
                            }
                            else
                            {
                                txtFullName.Text = "N/A";
                                txtJoinDate.Text = "N/A";
                            }
                        }
                    }

                    // 2. Current Allocated Room Number instead of Allocation Date
                    using (MySqlCommand cmd = new MySqlCommand("SELECT room_id FROM allocations WHERE resident_cnic = @cnic AND deallocation_date IS NULL", conn))
                    {
                        cmd.Parameters.AddWithValue("@cnic", cnic);
                        object roomID = cmd.ExecuteScalar();
                        txtAllocationDate.Text = roomID != null ? roomID.ToString() : "Not Allocated";
                    }

                    // 3. Current Month Bill Status
                    using (MySqlCommand cmd = new MySqlCommand("SELECT isPaid FROM bills WHERE rCnic = @cnic AND bMonth = @month AND bYear = @year", conn))
                    {
                        cmd.Parameters.AddWithValue("@cnic", cnic);
                        cmd.Parameters.AddWithValue("@month", month);
                        cmd.Parameters.AddWithValue("@year", year);
                        object isPaid = cmd.ExecuteScalar();
                        if (isPaid != null)
                            txtBillStatus.Text = Convert.ToBoolean(isPaid) ? "Paid" : "Unpaid";
                        else
                            txtBillStatus.Text = "Not Issued";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading resident data: " + ex.Message);
            }
        }


    }
}
