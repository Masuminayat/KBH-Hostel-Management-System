﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WinFormsApp1
{
    public partial class FormM4 : Form
    {
        public FormM4()
        {
            InitializeComponent();
            LoadExpenses();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
                errorProvider1.SetError(textBox3, "Enter amount in PKR - Numbers only");
            }
            else
            {
                errorProvider1.SetError(textBox3, "");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string category = comboBox1.SelectedItem.ToString();
            string date = dateTimePicker1.Value.ToString("MM-dd-yyyy"); // store in yyyy-MM-dd format
            string amountText = textBox3.Text.Trim();
            string description = textBox5.Text.Trim();

            if (string.IsNullOrWhiteSpace(category) || string.IsNullOrWhiteSpace(amountText))
            {
                MessageBox.Show("Please enter category and amount.");
                return;
            }

            if (!int.TryParse(amountText, out int amount) || amount <= 0)
            {
                MessageBox.Show("Please enter a valid positive amount.");
                return;
            }

            string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";
            string query = "INSERT INTO expenses (expCat, expDate, expAmount, expDesc) " +
                           "VALUES (@cat, @date, @amount, @desc)";

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@cat", category);
                        cmd.Parameters.AddWithValue("@date", date);
                        cmd.Parameters.AddWithValue("@amount", amount);
                        cmd.Parameters.AddWithValue("@desc", description);

                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Expense added successfully!");
                        LoadExpenses();

                        // Reset form
                        textBox3.Clear();
                        textBox5.Clear();
                        dateTimePicker1.Value = DateTime.Today;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding expense: " + ex.Message);
            }
        }

        private void LoadExpenses()
        {
            string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";
            string query = "SELECT expID, expCat, expDate, expAmount, expDesc FROM expenses ORDER BY expDate DESC";

            DataTable expensesTable = new DataTable();

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();

                    using (MySqlDataAdapter adapter = new MySqlDataAdapter(query, conn))
                    {
                        adapter.Fill(expensesTable);
                    }
                }

                dataGridView1.DataSource = expensesTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading expenses: " + ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                // Get the selected expense ID
                int selectedExpID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["expID"].Value);

                DialogResult result = MessageBox.Show("Are you sure you want to delete this expense?",
                                                      "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (result == DialogResult.Yes)
                {
                    string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";
                    string deleteQuery = "DELETE FROM expenses WHERE expID = @id";

                    try
                    {
                        using (MySqlConnection conn = new MySqlConnection(connectionString))
                        {
                            conn.Open();
                            using (MySqlCommand cmd = new MySqlCommand(deleteQuery, conn))
                            {
                                cmd.Parameters.AddWithValue("@id", selectedExpID);
                                cmd.ExecuteNonQuery();
                            }
                        }

                        MessageBox.Show("Expense deleted successfully.");
                        LoadExpenses(); // Refresh the DataGridView
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error deleting expense: " + ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select an expense to delete.");
            }


        }

        private void dataGridView1_RowValidated(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.CurrentRow != null && dataGridView1.CurrentRow.DataBoundItem is DataRowView rowView)
            {
                string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";
                string updateQuery = @"UPDATE expenses 
                               SET expCat = @cat, expDate = @date, expAmount = @amount, expDesc = @desc 
                               WHERE expID = @id";

                try
                {
                    using (MySqlConnection conn = new MySqlConnection(connectionString))
                    {
                        conn.Open();
                        using (MySqlCommand cmd = new MySqlCommand(updateQuery, conn))
                        {
                            cmd.Parameters.AddWithValue("@cat", rowView["expCat"]);
                            cmd.Parameters.AddWithValue("@date", rowView["expDate"]);
                            cmd.Parameters.AddWithValue("@amount", rowView["expAmount"]);
                            cmd.Parameters.AddWithValue("@desc", rowView["expDesc"]);
                            cmd.Parameters.AddWithValue("@id", rowView["expID"]);

                            cmd.ExecuteNonQuery();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Update failed: " + ex.Message);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";
            string updateQuery = @"UPDATE expenses 
                           SET expCat = @cat, expDate = @date, expAmount = @amount, expDesc = @desc 
                           WHERE expID = @id";

            // Commit DataGridView edits to DataTable
            dataGridView1.EndEdit();

            DataTable dt = (DataTable)dataGridView1.DataSource;

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();

                    foreach (DataRow row in dt.Rows)
                    {
                        if (row.RowState == DataRowState.Modified)
                        {
                            using (MySqlCommand cmd = new MySqlCommand(updateQuery, conn))
                            {
                                cmd.Parameters.AddWithValue("@cat", row["expCat"]);
                                cmd.Parameters.AddWithValue("@date", row["expDate"]);
                                cmd.Parameters.AddWithValue("@amount", row["expAmount"]);
                                cmd.Parameters.AddWithValue("@desc", row["expDesc"]);
                                cmd.Parameters.AddWithValue("@id", row["expID"]);
                                cmd.ExecuteNonQuery();
                            }
                        }
                    }

                    MessageBox.Show("Expense changes saved successfully!");
                    LoadExpenses();
                    dt.AcceptChanges(); // Clear modified flags
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error saving changes: " + ex.Message);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}


