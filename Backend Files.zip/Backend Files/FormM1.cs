using hostelsystem;
using Kamraan_Boys_Hostel;
using Kamran_Boys_Hostel;
using KBH_MS;
using KBH_Owner;
using MySql.Data.MySqlClient;
using System.Windows.Forms;
using WinFormsApp1;

namespace Kamran_Boys_Hostel
{
    public partial class FormM1 : Form
    {
        public FormM1()
        {
            InitializeComponent();
        }

        private void FormS1_Load(object sender, EventArgs e)
        {
            LoadWardenDashboard();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            FormM2 formM2 = new FormM2();
            this.Hide();
            formM2.ShowDialog();
            this.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FormM4 formM4 = new FormM4();
            this.Hide();
            formM4.ShowDialog();
            this.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FormM3 formM3 = new FormM3();
            this.Hide();
            formM3.ShowDialog();
            this.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormM5 formM5 = new FormM5();
            this.Hide();
            formM5.ShowDialog();
            this.Show();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            FormM6 formM6 = new FormM6();
            this.Hide();
            formM6.ShowDialog();
            this.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            this.Hide();
            form1.ShowDialog();

        }

        private void label1_Click(object sender, EventArgs e)
        {
            FormJ7 formJ7 = new FormJ7();
            this.Hide();
            formJ7.ShowDialog();
            this.Show();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            RoomAllocation form8 = new RoomAllocation();
            this.Hide();
            form8.ShowDialog();
            this.Show();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            string month = DateTime.Now.ToString("MMMM");
            int year = DateTime.Now.Year;

            DialogResult confirmResult = MessageBox.Show(
                $"This will generate bills for {month} {year}. Continue?",
                "Confirm Billing",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (confirmResult == DialogResult.Yes)
            {
                // Ask for password
                string password = Prompt.ShowDialog("Enter your password to continue:", "Admin Verification");

                if (!string.IsNullOrWhiteSpace(password))
                {
                    if (UserName.VerifyUserPassword(UserSession.CNIC, password))
                    {
                        GenerateMonthlyBills(); // method from earlier
                    }
                    else
                    {
                        MessageBox.Show("Invalid password. Operation cancelled.", "Access Denied", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void GenerateMonthlyBills()
        {
            string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";
            DateTime now = DateTime.Now;
            string currentMonth = now.ToString("MMMM"); // e.g., May
            int currentYear = now.Year;
            DateTime issueDate = now.Date;

            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                try
                {
                    conn.Open();

                    // Get current allocations (i.e., deallocation_date IS NULL)
                    string query = @"
                SELECT a.resident_cnic, a.room_id, r.monthlyCharge
                FROM allocations a
                JOIN rooms r ON a.room_id = r.roomNumber
                WHERE a.deallocation_date IS NULL";

                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        List<(string cnic, string roomId, decimal rent)> billsToInsert = new List<(string, string, decimal)>();

                        while (reader.Read())
                        {
                            string cnic = reader["resident_cnic"].ToString();
                            string roomId = reader["room_id"].ToString();
                            decimal rent = Convert.ToDecimal(reader["monthlyCharge"]);

                            billsToInsert.Add((cnic, roomId, rent));
                        }

                        reader.Close();

                        foreach (var bill in billsToInsert)
                        {
                            // Check if bill already exists for this month
                            string checkQuery = @"
                        SELECT COUNT(*) FROM bills 
                        WHERE rCnic = @cnic AND bMonth = @month AND bYear = @year";

                            using (MySqlCommand checkCmd = new MySqlCommand(checkQuery, conn))
                            {
                                checkCmd.Parameters.AddWithValue("@cnic", bill.cnic);
                                checkCmd.Parameters.AddWithValue("@month", currentMonth);
                                checkCmd.Parameters.AddWithValue("@year", currentYear);

                                int exists = Convert.ToInt32(checkCmd.ExecuteScalar());
                                if (exists > 0)
                                    continue; // Skip if bill already exists
                            }

                            // Insert new bill
                            string insertQuery = @"
                        INSERT INTO bills (rCnic, roomID, bMonth, bYear, bAmount, isPaid, issueDate)
                        VALUES (@cnic, @roomId, @month, @year, @amount, false, @issueDate)";

                            using (MySqlCommand insertCmd = new MySqlCommand(insertQuery, conn))
                            {
                                insertCmd.Parameters.AddWithValue("@cnic", bill.cnic);
                                insertCmd.Parameters.AddWithValue("@roomId", bill.roomId);
                                insertCmd.Parameters.AddWithValue("@month", currentMonth);
                                insertCmd.Parameters.AddWithValue("@year", currentYear);
                                insertCmd.Parameters.AddWithValue("@amount", bill.rent);
                                insertCmd.Parameters.AddWithValue("@issueDate", issueDate);

                                insertCmd.ExecuteNonQuery();
                            }
                        }
                    }

                    MessageBox.Show("Monthly bills generated successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error generating bills: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void LoadWardenDashboard()
        {
            string month = DateTime.Now.ToString("MMMM"); // e.g., "May"
            int year = DateTime.Now.Year;

            string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();

                    // 1. Residents Currently Staying
                    using (MySqlCommand cmd = new MySqlCommand("SELECT COUNT(*) FROM allocations WHERE deallocation_date IS NULL", conn))
                    {
                        lblResidentsStaying.Text = cmd.ExecuteScalar().ToString();
                    }

                    // 2. Monthly Visits
                    using (MySqlCommand cmd = new MySqlCommand("SELECT COUNT(*) FROM visits WHERE MONTH(STR_TO_DATE(vDate, '%m-%d-%Y')) = @month AND YEAR(STR_TO_DATE(vDate, '%m-%d-%Y')) = @year", conn))
                    {
                        cmd.Parameters.AddWithValue("@month", DateTime.Now.Month);
                        cmd.Parameters.AddWithValue("@year", year);
                        lblMonthlyVisits.Text = cmd.ExecuteScalar().ToString();
                    }

                    // 3. Monthly Paid Rent
                    using (MySqlCommand cmd = new MySqlCommand("SELECT IFNULL(ROUND(SUM(bAmount)), 0) FROM bills WHERE bMonth = MONTHNAME(CURDATE()) AND bYear = YEAR(CURDATE()) AND isPaid = 1", conn))
                    {
                        cmd.Parameters.AddWithValue("@month", month);
                        cmd.Parameters.AddWithValue("@year", year);
                        lblPaidRent.Text = cmd.ExecuteScalar().ToString() + " PKR";
                    }

                    // 4. Monthly Due Rent
                    using (MySqlCommand cmd = new MySqlCommand("SELECT IFNULL(ROUND(SUM(bAmount)), 0) FROM bills WHERE bMonth = MONTHNAME(CURDATE()) AND bYear = YEAR(CURDATE()) AND isPaid = 0", conn))
                    {
                        cmd.Parameters.AddWithValue("@month", month);
                        cmd.Parameters.AddWithValue("@year", year);
                        lblDueRent.Text = cmd.ExecuteScalar().ToString() + " PKR";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading dashboard data: " + ex.Message);
            }
        }



    }
}
