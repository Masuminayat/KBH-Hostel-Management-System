﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace KBH_MS
{
    public partial class RoomAllocation : Form
    {
        public RoomAllocation()
        {
            InitializeComponent();
            LoadAllocationDetails();
            LoadAvailableRooms();
            LoadRoomNumbersToComboBox();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string cnic = textBox1.Text.Trim();
            string roomId = textBox2.Text.Trim();
            DateTime allocationDate = dateTimePicker1.Value.Date;

            if (string.IsNullOrEmpty(cnic) || string.IsNullOrEmpty(roomId))
            {
                MessageBox.Show("Please fill in both CNIC and Room ID.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!long.TryParse(cnic, out long parsedCnic))
            {
                MessageBox.Show("CNIC must be numeric.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";

            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                try
                {
                    conn.Open();

                    // 1. Validate that the resident exists
                    string residentCheckQuery = "SELECT COUNT(*) FROM residents WHERE cnic = @cnic";
                    using (MySqlCommand cmdCheckResident = new MySqlCommand(residentCheckQuery, conn))
                    {
                        cmdCheckResident.Parameters.AddWithValue("@cnic", parsedCnic);
                        if (Convert.ToInt32(cmdCheckResident.ExecuteScalar()) == 0)
                        {
                            MessageBox.Show("Resident with this CNIC does not exist.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                    }

                    // 2. Validate that the room exists and has capacity
                    string capacityCheckQuery = @"
  SELECT r.maxCapacity - COUNT(a.allocation_id) AS available
  FROM rooms r
  LEFT JOIN allocations a ON r.roomNumber = a.room_id AND a.deallocation_date IS NULL
  WHERE r.roomNumber = @roomId
  GROUP BY r.maxCapacity";

                    using (MySqlCommand cmdCheckRoom = new MySqlCommand(capacityCheckQuery, conn))
                    {
                        cmdCheckRoom.Parameters.AddWithValue("@roomId", roomId);
                        object aResult = cmdCheckRoom.ExecuteScalar();

                        if (aResult == null)
                        {
                            MessageBox.Show("Room not found.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }

                        int available = Convert.ToInt32(aResult);
                        if (available <= 0)
                        {
                            MessageBox.Show("Room is full. Cannot allocate.", "Capacity Full", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                    }

                    // 3. Check if resident already has an active allocation
                    string activeAllocationCheck = "SELECT COUNT(*) FROM allocations WHERE resident_cnic = @cnic AND deallocation_date IS NULL";
                    using (MySqlCommand cmdActiveCheck = new MySqlCommand(activeAllocationCheck, conn))
                    {
                        cmdActiveCheck.Parameters.AddWithValue("@cnic", parsedCnic);
                        if (Convert.ToInt32(cmdActiveCheck.ExecuteScalar()) > 0)
                        {
                            MessageBox.Show("Resident is already allocated a room.", "Duplicate Allocation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                    }

                    // 4. Get Resident and Room details before allocation
                    string residentName = string.Empty;
                    string roomNumber = string.Empty;
                    int roomCapacity = 0;

                    string getResidentNameQuery = "SELECT fullName FROM residents WHERE cnic = @cnic";
                    using (MySqlCommand cmdGetName = new MySqlCommand(getResidentNameQuery, conn))
                    {
                        cmdGetName.Parameters.AddWithValue("@cnic", parsedCnic);
                        residentName = cmdGetName.ExecuteScalar().ToString();
                    }

                    string getRoomDetailsQuery = "SELECT roomNumber, maxCapacity FROM rooms WHERE roomNumber = @roomId";
                    using (MySqlCommand cmdGetRoomDetails = new MySqlCommand(getRoomDetailsQuery, conn))
                    {
                        cmdGetRoomDetails.Parameters.AddWithValue("@roomId", roomId);
                        using (MySqlDataReader reader = cmdGetRoomDetails.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                roomNumber = reader["roomNumber"].ToString();
                                roomCapacity = Convert.ToInt32(reader["maxCapacity"]);
                            }
                        }
                    }

                    // 5. Ask for confirmation before proceeding with the allocation
                    DialogResult result = MessageBox.Show(
                        $"You are about to allocate Room {roomNumber} (Capacity: {roomCapacity}) to {residentName}.\n" +
                        $"Allocation Date: {allocationDate.ToShortDateString()}\n\n" +
                        "Are you sure you want to proceed?",
                        "Confirm Allocation",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Question);

                    if (result == DialogResult.Yes)
                    {
                        // Proceed with allocation
                        string insertQuery = @"
  INSERT INTO allocations (resident_cnic, room_id, allocation_date)
  VALUES (@cnic, @roomId, @allocDate)";
                        using (MySqlCommand cmdInsert = new MySqlCommand(insertQuery, conn))
                        {
                            cmdInsert.Parameters.AddWithValue("@cnic", parsedCnic);
                            cmdInsert.Parameters.AddWithValue("@roomId", roomId);
                            cmdInsert.Parameters.AddWithValue("@allocDate", allocationDate);

                            cmdInsert.ExecuteNonQuery();

                            // Show success message with allocation details
                            MessageBox.Show($"Room {roomNumber} (Capacity: {roomCapacity}) has been successfully allocated to {residentName}.\n" +
                                            $"Allocation Date: {allocationDate.ToShortDateString()}",
                                "Allocation Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            LoadAllocationDetails();
                            LoadAvailableRooms();
                        }
                    }
                    else
                    {
                        // Allocation canceled
                        MessageBox.Show("Room allocation has been canceled.", "Allocation Canceled", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error allocating room: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        /*
        string cnic = textBox1.Text.Trim();
        string roomId = textBox2.Text.Trim();
        DateTime allocationDate = dateTimePicker1.Value.Date;

        if (string.IsNullOrEmpty(cnic) || string.IsNullOrEmpty(roomId))
        {
            MessageBox.Show("Please fill in both CNIC and Room ID.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        if (!long.TryParse(cnic, out long parsedCnic))
        {
            MessageBox.Show("CNIC must be numeric.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";

        using (MySqlConnection conn = new MySqlConnection(connectionString))
        {
            try
            {
                conn.Open();

                // 1. Validate that the resident exists
                string residentCheckQuery = "SELECT COUNT(*) FROM residents WHERE cnic = @cnic";
                using (MySqlCommand cmdCheckResident = new MySqlCommand(residentCheckQuery, conn))
                {
                    cmdCheckResident.Parameters.AddWithValue("@cnic", parsedCnic);
                    if (Convert.ToInt32(cmdCheckResident.ExecuteScalar()) == 0)
                    {
                        MessageBox.Show("Resident with this CNIC does not exist.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }

                // 2. Validate that the room exists and has capacity
                string capacityCheckQuery = @"
SELECT r.maxCapacity - COUNT(a.allocation_id) AS available
FROM rooms r
LEFT JOIN allocations a ON r.roomNumber = a.room_id AND a.deallocation_date IS NULL
WHERE r.roomNumber = @roomId
GROUP BY r.maxCapacity";

                using (MySqlCommand cmdCheckRoom = new MySqlCommand(capacityCheckQuery, conn))
                {
                    cmdCheckRoom.Parameters.AddWithValue("@roomId", roomId);
                    object result = cmdCheckRoom.ExecuteScalar();

                    if (result == null)
                    {
                        MessageBox.Show("Room not found.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    int available = Convert.ToInt32(result);
                    if (available <= 0)
                    {
                        MessageBox.Show("Room is full. Cannot allocate.", "Capacity Full", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                }

                // 3. Check if resident already has an active allocation
                string activeAllocationCheck = "SELECT COUNT(*) FROM allocations WHERE resident_cnic = @cnic AND deallocation_date IS NULL";
                using (MySqlCommand cmdActiveCheck = new MySqlCommand(activeAllocationCheck, conn))
                {
                    cmdActiveCheck.Parameters.AddWithValue("@cnic", parsedCnic);
                    if (Convert.ToInt32(cmdActiveCheck.ExecuteScalar()) > 0)
                    {
                        MessageBox.Show("Resident is already allocated a room.", "Duplicate Allocation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                }

                // 4. Insert allocation
                string insertQuery = @"
INSERT INTO allocations (resident_cnic, room_id, allocation_date)
VALUES (@cnic, @roomId, @allocDate)";
                using (MySqlCommand cmdInsert = new MySqlCommand(insertQuery, conn))
                {
                    cmdInsert.Parameters.AddWithValue("@cnic", parsedCnic);
                    cmdInsert.Parameters.AddWithValue("@roomId", roomId);
                    cmdInsert.Parameters.AddWithValue("@allocDate", allocationDate);

                    cmdInsert.ExecuteNonQuery();

                    // Get resident name
                    string getResidentNameQuery = "SELECT fullName FROM residents WHERE cnic = @cnic";
                    string residentName = string.Empty;
                    using (MySqlCommand cmdGetName = new MySqlCommand(getResidentNameQuery, conn))
                    {
                        cmdGetName.Parameters.AddWithValue("@cnic", parsedCnic);
                        residentName = cmdGetName.ExecuteScalar().ToString();
                    }

                    // Get room details
                    string getRoomDetailsQuery = "SELECT roomNumber, maxCapacity FROM rooms WHERE roomNumber = @roomId";
                    string roomNumber = string.Empty;
                    int roomCapacity = 0;
                    using (MySqlCommand cmdGetRoomDetails = new MySqlCommand(getRoomDetailsQuery, conn))
                    {
                        cmdGetRoomDetails.Parameters.AddWithValue("@roomId", roomId);
                        using (MySqlDataReader reader = cmdGetRoomDetails.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                roomNumber = reader["roomNumber"].ToString();
                                roomCapacity = Convert.ToInt32(reader["maxCapacity"]);
                            }
                        }
                    }

                    // Show confirmation message with allocation details
                    MessageBox.Show($"Room {roomNumber} (Capacity: {roomCapacity}) has been successfully allocated to {residentName}.\nAllocation Date: {allocationDate.ToShortDateString()}",
                        "Allocation Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error allocating room: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }*/


        /*  string cnic = textBox1.Text.Trim();
          string roomId = textBox2.Text.Trim();
          DateTime allocationDate = dateTimePicker1.Value.Date;

          if (string.IsNullOrEmpty(cnic) || string.IsNullOrEmpty(roomId))
          {
              MessageBox.Show("Please fill in both CNIC and Room ID.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
              return;
          }

          if (!long.TryParse(cnic, out long parsedCnic))
          {
              MessageBox.Show("CNIC must be numeric.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
              return;
          }

          string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";

          using (MySqlConnection conn = new MySqlConnection(connectionString))
          {
              try
              {
                  conn.Open();

                  // 1. Validate that the resident exists
                  string residentCheckQuery = "SELECT COUNT(*) FROM residents WHERE cnic = @cnic";
                  using (MySqlCommand cmdCheckResident = new MySqlCommand(residentCheckQuery, conn))
                  {
                      cmdCheckResident.Parameters.AddWithValue("@cnic", parsedCnic);
                      if (Convert.ToInt32(cmdCheckResident.ExecuteScalar()) == 0)
                      {
                          MessageBox.Show("Resident with this CNIC does not exist.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                          return;
                      }
                  }

                  // 2. Validate that the room exists and has capacity
                  string capacityCheckQuery = @"
       SELECT r.maxCapacity - COUNT(a.allocation_id) AS available
       FROM rooms r
       LEFT JOIN allocations a ON r.roomNumber = a.room_id AND a.deallocation_date IS NULL
       WHERE r.roomNumber = @roomId
       GROUP BY r.maxCapacity";

                  using (MySqlCommand cmdCheckRoom = new MySqlCommand(capacityCheckQuery, conn))
                  {
                      cmdCheckRoom.Parameters.AddWithValue("@roomId", roomId);
                      object result = cmdCheckRoom.ExecuteScalar();

                      if (result == null)
                      {
                          MessageBox.Show("Room not found.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                          return;
                      }

                      int available = Convert.ToInt32(result);
                      if (available <= 0)
                      {
                          MessageBox.Show("Room is full. Cannot allocate.", "Capacity Full", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                          return;
                      }
                  }

                  // 3. Check if resident already has an active allocation
                  string activeAllocationCheck = "SELECT COUNT(*) FROM allocations WHERE resident_cnic = @cnic AND deallocation_date IS NULL";
                  using (MySqlCommand cmdActiveCheck = new MySqlCommand(activeAllocationCheck, conn))
                  {
                      cmdActiveCheck.Parameters.AddWithValue("@cnic", parsedCnic);
                      if (Convert.ToInt32(cmdActiveCheck.ExecuteScalar()) > 0)
                      {
                          MessageBox.Show("Resident is already allocated a room.", "Duplicate Allocation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                          return;
                      }
                  }

                  // 4. Insert allocation
                  string insertQuery = @"
       INSERT INTO allocations (resident_cnic, room_id, allocation_date)
       VALUES (@cnic, @roomId, @allocDate)";
                  using (MySqlCommand cmdInsert = new MySqlCommand(insertQuery, conn))
                  {
                      cmdInsert.Parameters.AddWithValue("@cnic", parsedCnic);
                      cmdInsert.Parameters.AddWithValue("@roomId", roomId);
                      cmdInsert.Parameters.AddWithValue("@allocDate", allocationDate);

                      cmdInsert.ExecuteNonQuery();


                     MessageBox.Show("Room allocated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                  }
              }
              catch (Exception ex)
              {
                  MessageBox.Show("Error allocating room: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
              }
          }*/


        private void LoadAllocationDetails()
        {
            string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";
            string query = @"
       SELECT 
    allocations.allocation_id,
    allocations.resident_cnic,
    residents.fullName,
    allocations.room_id,
    rooms.maxCapacity,
    rooms.monthlyCharge,
    allocations.allocation_date,
    allocations.deallocation_date
FROM allocations
JOIN residents ON allocations.resident_cnic = residents.cnic
JOIN rooms ON allocations.room_id = rooms.roomNumber
order by allocation_id desc;
    ";

            DataTable dt = new DataTable();

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    using (MySqlDataAdapter da = new MySqlDataAdapter(query, conn))
                    {
                        da.Fill(dt);
                    }
                }

                dataGridView2.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading allocation details: " + ex.Message);
            }
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView2.CurrentRow != null)
            {
                // Optional: confirm which resident/room is being deallocated
                string roomId = dataGridView2.CurrentRow.Cells["room_id"].Value.ToString();
                string residentName = dataGridView2.CurrentRow.Cells["fullName"].Value.ToString();

                DialogResult result = MessageBox.Show(
                    $"Are you sure you want to deallocate Room {roomId} for Resident {residentName} ?",
                    "Confirm Deallocation",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning);

                if (result == DialogResult.Yes)
                {
                    // Proceed with your existing deallocation logic
                    try
                    {
                        // Example: update deallocation_date for the selected allocation
                        int allocationId = Convert.ToInt32(dataGridView2.CurrentRow.Cells["allocation_id"].Value);
                        string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";

                        using (MySqlConnection conn = new MySqlConnection(connectionString))
                        {
                            conn.Open();
                            // Update only the current allocation record if its deallocation_date is NULL
                            string query = "UPDATE allocations SET deallocation_date = CURDATE() WHERE allocation_id = @id AND deallocation_date IS NULL";
                            using (MySqlCommand cmd = new MySqlCommand(query, conn))
                            {
                                cmd.Parameters.AddWithValue("@id", allocationId);
                                int rowsAffected = cmd.ExecuteNonQuery();  // Execute once

                                // Check if any row was affected (i.e., deallocation was successful)
                                if (rowsAffected > 0)
                                {
                                    MessageBox.Show($"{residentName} has been successfully deallocated.");
                                    LoadAllocationDetails(); // Refresh DataGridView to reflect the deallocation
                                    LoadAvailableRooms();
                                }
                                else
                                {
                                    MessageBox.Show("This resident has already been deallocated for this allocation.");
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error during deallocation: {ex.Message}");
                    }

                }
            }
            else
            {
                MessageBox.Show("Please select an allocation to deallocate.");
            }
        }



        /*  if (dataGridView2.CurrentRow == null)
          {
              MessageBox.Show("Please select an allocation to deallocate.");
              return;
          }

          string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";

          // Extract CNIC and Room ID from the selected row
          var selectedRow = dataGridView2.CurrentRow;

          string cnic = selectedRow.Cells["resident_cnic"].Value?.ToString();
          string roomId = selectedRow.Cells["room_id"].Value?.ToString();
          string deallocationDate = selectedRow.Cells["deallocation_date"].Value?.ToString();

          if (string.IsNullOrEmpty(cnic) || string.IsNullOrEmpty(roomId))
          {
              MessageBox.Show("Invalid CNIC or Room ID in selected row.");
              return;
          }

          if (!string.IsNullOrEmpty(deallocationDate))
          {
              MessageBox.Show("This allocation is already deallocated.");
              return;
          }

          // SQL query to update only active allocations
          string query = @"UPDATE allocations 
                   SET deallocation_date = CURDATE() 
                   WHERE resident_cnic = @cnic 
                     AND room_id = @roomId 
                     AND deallocation_date IS NULL";

          try
          {
              using (MySqlConnection conn = new MySqlConnection(connectionString))
              {
                  conn.Open();
                  using (MySqlCommand cmd = new MySqlCommand(query, conn))
                  {
                      cmd.Parameters.AddWithValue("@cnic", cnic);
                      cmd.Parameters.AddWithValue("@roomId", roomId);

                      int rowsAffected = cmd.ExecuteNonQuery();
                      if (rowsAffected > 0)
                      {
                          MessageBox.Show("Room deallocated successfully.");
                      }
                      else
                      {
                          MessageBox.Show("No active allocation found or already deallocated.");
                      }
                  }
              }
          }
          catch (Exception ex)
          {
              MessageBox.Show("Error during deallocation: " + ex.Message);
          }
      }
      */

        private void LoadAvailableRooms()
        {
            string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";
            string query = @"
        SELECT 
            r.roomNumber AS 'Room',
            r.maxCapacity AS 'Capacity',
            r.monthlyCharge AS 'Rent',
            COUNT(a.allocation_id) AS AllocatedCount,
            (r.maxCapacity - COUNT(a.allocation_id)) AS AvailableSeats
        FROM rooms r
        LEFT JOIN allocations a 
            ON r.roomNumber = a.room_id 
            AND a.deallocation_date IS NULL
        GROUP BY r.roomNumber, r.maxCapacity, r.monthlyCharge
        HAVING availableSeats > 0;
    ";

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    using (MySqlDataAdapter adapter = new MySqlDataAdapter(query, conn))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        dataGridView1.DataSource = dt;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading available rooms: " + ex.Message);
            }
        }

        private void RoomAllocation_Load(object sender, EventArgs e)
        {

        }

        private void LoadAllocationsByFilter()
        {
            string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";
            string selectedFilter = comboBoxFilter.SelectedItem?.ToString();
            string query = "";

            if (selectedFilter == "Allocated Residents")
            {
                query = @"
            SELECT r.fullName, r.cnic, a.room_id, a.allocation_date
            FROM residents r
            INNER JOIN allocations a ON r.cnic = a.resident_cnic
            WHERE a.deallocation_date IS NULL";
            }
            else if (selectedFilter == "Unallocated Residents")
            {
                query = @"
            SELECT fullName, cnic, '' AS room_id, '' AS allocation_date
            FROM residents
            WHERE cnic NOT IN (
                SELECT resident_cnic FROM allocations WHERE deallocation_date IS NULL
            )";
            }
            else // All Residents
            {
                query = @"
            SELECT r.fullName, r.cnic, a.room_id, a.allocation_date, a.deallocation_date
            FROM residents r
            LEFT JOIN allocations a ON r.cnic = a.resident_cnic";
            }

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    MySqlDataAdapter adapter = new MySqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    dataGridView2.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading filtered allocations: " + ex.Message);
            }
        }

        private void comboBoxFilter_SelectedIndexChanged(object sender, EventArgs e)
        {

            LoadAllocationsByFilter();


        }

        private void cmbRoomFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedRoom = cmbRoomFilter.SelectedItem?.ToString();

            if (string.IsNullOrEmpty(selectedRoom))
                return;

            if (selectedRoom == "All")
            {
                LoadAllAllocations(); // Load everything
            }
            else
            {
                FilterBySelectedRoom(selectedRoom);
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string searchText = txtSearch.Text.Trim();

            if (string.IsNullOrEmpty(searchText))
            {
                LoadAllAllocations(); // Load all if nothing is entered
                return;
            }

            SearchAllocations(searchText);
        }

        private void LoadAllAllocations()
        {
            string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";
            string query = @"
        SELECT a.allocation_id, r.fullName, r.cnic, a.room_id, a.allocation_date
        FROM residents r
        INNER JOIN allocations a ON r.cnic = a.resident_cnic
        WHERE a.deallocation_date IS NULL";

            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                using (MySqlDataAdapter adapter = new MySqlDataAdapter(query, conn))
                {
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    dataGridView2.DataSource = dt;
                }
            }
        }


        private void LoadRoomNumbersToComboBox()
        {
            string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";
            string query = "SELECT roomNumber FROM rooms";

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        cmbRoomFilter.Items.Clear();
                        cmbRoomFilter.Items.Add("All"); // Optional "All" filter

                        while (reader.Read())
                        {
                            cmbRoomFilter.Items.Add(reader["roomNumber"].ToString());
                        }

                        cmbRoomFilter.SelectedIndex = 0;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading room numbers: " + ex.Message);
            }
        }

        private void FilterBySelectedRoom(string roomID)
        {
            string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";
            string query = @"
        SELECT a.allocation_id, r.fullName, r.cnic, a.room_id, a.allocation_date
        FROM residents r
        INNER JOIN allocations a ON r.cnic = a.resident_cnic
        WHERE a.room_id = @roomID AND a.deallocation_date IS NULL";

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@roomID", roomID);
                        using (MySqlDataAdapter adapter = new MySqlDataAdapter(cmd))
                        {
                            DataTable dt = new DataTable();
                            adapter.Fill(dt);
                            dataGridView2.DataSource = dt;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error applying room filter: " + ex.Message);
            }
        }

        private void SearchAllocations(string keyword)
        {
            string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";

            string query = @"SELECT a.allocation_id, a.resident_cnic, r.fullName, a.room_id, 
                            a.allocation_date, a.deallocation_date
                     FROM allocations a
                     JOIN residents r ON a.resident_cnic = r.cnic
                     WHERE r.fullName LIKE @keyword OR r.cnic LIKE @keyword";

            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                using (MySqlCommand cmd = new MySqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@keyword", "%" + keyword + "%");

                    MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    dataGridView2.DataSource = dt;
                }
            }
        }

        private void btnSearch_Click_1(object sender, EventArgs e)
        {
            string searchText = txtSearch.Text.Trim();

            if (string.IsNullOrEmpty(searchText))
            {
                LoadAllAllocations(); // Load all if nothing is entered
                return;
            }

            SearchAllocations(searchText);
        }

        private void btnSearch_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnSearch.PerformClick();
            }
        }

        private void btnSearch_KeyPress(object sender, KeyPressEventArgs e)
        {
        }
    }
}

