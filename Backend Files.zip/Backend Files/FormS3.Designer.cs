﻿namespace KBH_Owner
{
    partial class FormS3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label3 = new Label();
            button4 = new Button();
            comboBox2 = new ComboBox();
            textBox3 = new TextBox();
            dataGridView1 = new DataGridView();
            comboBox1 = new ComboBox();
            label4 = new Label();
            textBox1 = new TextBox();
            label1 = new Label();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            label5 = new Label();
            label6 = new Label();
            textBox2 = new TextBox();
            label2 = new Label();
            textBox4 = new TextBox();
            label7 = new Label();
            textBox5 = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(338, 9);
            label3.Name = "label3";
            label3.Size = new Size(580, 38);
            label3.TabIndex = 21;
            label3.Text = "Kamran Boys Hostel - Rooms Management";
            // 
            // button4
            // 
            button4.Cursor = Cursors.Hand;
            button4.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button4.Location = new Point(563, 129);
            button4.Name = "button4";
            button4.Size = new Size(113, 32);
            button4.TabIndex = 25;
            button4.Text = "Search";
            button4.UseVisualStyleBackColor = true;
            // 
            // comboBox2
            // 
            comboBox2.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            comboBox2.FormattingEnabled = true;
            comboBox2.Items.AddRange(new object[] { "1-Seater", "2-Seater", "3-Seater", "4-Seater", "5-Seater" });
            comboBox2.Location = new Point(47, 130);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(169, 33);
            comboBox2.TabIndex = 24;
            comboBox2.Text = "Filter by Seats";
            // 
            // textBox3
            // 
            textBox3.Cursor = Cursors.IBeam;
            textBox3.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            textBox3.Location = new Point(376, 130);
            textBox3.Name = "textBox3";
            textBox3.PlaceholderText = "Search by Room No";
            textBox3.Size = new Size(181, 31);
            textBox3.TabIndex = 23;
            textBox3.TextAlign = HorizontalAlignment.Center;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(47, 176);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(629, 488);
            dataGridView1.TabIndex = 22;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // comboBox1
            // 
            comboBox1.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Full", "Seats Available", "Unavailable for rent" });
            comboBox1.Location = new Point(222, 130);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(148, 33);
            comboBox1.TabIndex = 26;
            comboBox1.Text = "Filter by availability";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(800, 341);
            label4.Name = "label4";
            label4.Size = new Size(146, 28);
            label4.TabIndex = 32;
            label4.Text = "Room Capacity";
            // 
            // textBox1
            // 
            textBox1.Cursor = Cursors.IBeam;
            textBox1.Location = new Point(975, 294);
            textBox1.MaxLength = 6;
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(181, 27);
            textBox1.TabIndex = 28;
            textBox1.Tag = "";
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(800, 290);
            label1.Name = "label1";
            label1.Size = new Size(146, 28);
            label1.TabIndex = 27;
            label1.Text = "Room Number";
            // 
            // button3
            // 
            button3.BackgroundImage = KBH_MS.Properties.Resources.button_bg;
            button3.BackgroundImageLayout = ImageLayout.Stretch;
            button3.Cursor = Cursors.Hand;
            button3.Font = new Font("Segoe UI", 13.8F);
            button3.Location = new Point(812, 487);
            button3.Name = "button3";
            button3.Size = new Size(117, 43);
            button3.TabIndex = 37;
            button3.Text = "Remove ";
            button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.BackgroundImage = KBH_MS.Properties.Resources.button_bg;
            button2.BackgroundImageLayout = ImageLayout.Stretch;
            button2.Cursor = Cursors.Hand;
            button2.Font = new Font("Segoe UI", 13.8F);
            button2.Location = new Point(946, 487);
            button2.Name = "button2";
            button2.Size = new Size(100, 43);
            button2.TabIndex = 36;
            button2.Text = "Update";
            button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            button1.BackgroundImage = KBH_MS.Properties.Resources.button_bg;
            button1.BackgroundImageLayout = ImageLayout.Stretch;
            button1.Cursor = Cursors.Hand;
            button1.Font = new Font("Segoe UI", 13.8F);
            button1.Location = new Point(1065, 487);
            button1.Name = "button1";
            button1.Size = new Size(94, 43);
            button1.TabIndex = 35;
            button1.Text = "Add User";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold);
            label5.ForeColor = SystemColors.ButtonFace;
            label5.Location = new Point(739, 176);
            label5.Name = "label5";
            label5.Size = new Size(446, 31);
            label5.TabIndex = 38;
            label5.Text = "You can use below form to add new room";
            label5.TextAlign = ContentAlignment.TopCenter;
            label5.Click += label5_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold);
            label6.ForeColor = SystemColors.ButtonFace;
            label6.Location = new Point(727, 217);
            label6.Name = "label6";
            label6.Size = new Size(489, 31);
            label6.TabIndex = 39;
            label6.Text = "To edit existing one, first select from the table";
            label6.TextAlign = ContentAlignment.TopCenter;
            // 
            // textBox2
            // 
            textBox2.Cursor = Cursors.IBeam;
            textBox2.Location = new Point(975, 435);
            textBox2.MaxLength = 100;
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(181, 27);
            textBox2.TabIndex = 34;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(800, 434);
            label2.Name = "label2";
            label2.Size = new Size(168, 28);
            label2.TabIndex = 33;
            label2.Text = "Details (optional)";
            // 
            // textBox4
            // 
            textBox4.Cursor = Cursors.IBeam;
            textBox4.Location = new Point(975, 389);
            textBox4.MaxLength = 100;
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(181, 27);
            textBox4.TabIndex = 41;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.Transparent;
            label7.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.Location = new Point(800, 388);
            label7.Name = "label7";
            label7.Size = new Size(167, 28);
            label7.TabIndex = 40;
            label7.Text = "Monthly Charges";
            // 
            // textBox5
            // 
            textBox5.Cursor = Cursors.IBeam;
            textBox5.Location = new Point(975, 342);
            textBox5.MaxLength = 100;
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(181, 27);
            textBox5.TabIndex = 42;
            // 
            // FormS3
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = KBH_MS.Properties.Resources.blurred_blue_gradient_wallpaper_preview;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1233, 706);
            Controls.Add(textBox5);
            Controls.Add(textBox4);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(textBox2);
            Controls.Add(label2);
            Controls.Add(label4);
            Controls.Add(textBox1);
            Controls.Add(label1);
            Controls.Add(comboBox1);
            Controls.Add(button4);
            Controls.Add(comboBox2);
            Controls.Add(textBox3);
            Controls.Add(dataGridView1);
            Controls.Add(label3);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            Name = "FormS3";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Rooms-Management";
            Load += FormS3_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label3;
        private Button button4;
        private ComboBox comboBox2;
        private TextBox textBox3;
        private DataGridView dataGridView1;
        private ComboBox comboBox1;
        private Label label4;
        private TextBox textBox1;
        private Label label1;
        private Button button3;
        private Button button2;
        private Button button1;
        private Label label5;
        private Label label6;
        private TextBox textBox2;
        private Label label2;
        private TextBox textBox4;
        private Label label7;
        private TextBox textBox5;
    }
}