﻿namespace Kamran_Boys_Hostel
{
    partial class FormM2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            dataGridView1 = new DataGridView();
            label1 = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            label2 = new Label();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            label5 = new Label();
            textBox5 = new TextBox();
            label6 = new Label();
            label7 = new Label();
            button1 = new Button();
            button2 = new Button();
            backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            comboBox2 = new ComboBox();
            button4 = new Button();
            label3 = new Label();
            errorProvider1 = new ErrorProvider(components);
            errorProvider2 = new ErrorProvider(components);
            errorProvider3 = new ErrorProvider(components);
            textBox7 = new TextBox();
            label8 = new Label();
            label9 = new Label();
            comboBox3 = new ComboBox();
            label10 = new Label();
            richTextBox1 = new RichTextBox();
            label4 = new Label();
            comboBox1 = new ComboBox();
            label11 = new Label();
            dateTimePicker1 = new DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)errorProvider1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)errorProvider2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)errorProvider3).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(52, 134);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(629, 560);
            dataGridView1.TabIndex = 0;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(776, 85);
            label1.Name = "label1";
            label1.Size = new Size(138, 28);
            label1.TabIndex = 1;
            label1.Text = "CNIC Number";
            // 
            // textBox1
            // 
            textBox1.Cursor = Cursors.IBeam;
            textBox1.Location = new Point(951, 89);
            textBox1.MaxLength = 13;
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(223, 27);
            textBox1.TabIndex = 2;
            textBox1.TextChanged += textBox1_TextChanged;
            textBox1.KeyPress += textBox1_KeyPress;
            // 
            // textBox2
            // 
            textBox2.Cursor = Cursors.IBeam;
            textBox2.Location = new Point(951, 133);
            textBox2.MaxLength = 50;
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(223, 27);
            textBox2.TabIndex = 4;
            textBox2.KeyPress += textBox2_KeyPress;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(776, 132);
            label2.Name = "label2";
            label2.Size = new Size(104, 28);
            label2.TabIndex = 3;
            label2.Text = "Full Name";
            label2.Click += label2_Click;
            // 
            // textBox3
            // 
            textBox3.Cursor = Cursors.IBeam;
            textBox3.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            textBox3.Location = new Point(290, 89);
            textBox3.Name = "textBox3";
            textBox3.PlaceholderText = "Search by CNIC/Name";
            textBox3.Size = new Size(272, 31);
            textBox3.TabIndex = 6;
            textBox3.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox4
            // 
            textBox4.Cursor = Cursors.IBeam;
            textBox4.Location = new Point(951, 324);
            textBox4.MaxLength = 15;
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(223, 27);
            textBox4.TabIndex = 12;
            textBox4.KeyPress += textBox4_KeyPress;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(776, 322);
            label5.Name = "label5";
            label5.Size = new Size(152, 28);
            label5.TabIndex = 11;
            label5.Text = "Phone Number";
            // 
            // textBox5
            // 
            textBox5.Cursor = Cursors.IBeam;
            textBox5.Location = new Point(951, 280);
            textBox5.MaxLength = 45;
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(223, 27);
            textBox5.TabIndex = 10;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(776, 276);
            label6.Name = "label6";
            label6.Size = new Size(139, 28);
            label6.TabIndex = 9;
            label6.Text = "Email Address";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.Transparent;
            label7.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.Location = new Point(776, 369);
            label7.Name = "label7";
            label7.Size = new Size(0, 28);
            label7.TabIndex = 13;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(255, 192, 128);
            button1.BackgroundImageLayout = ImageLayout.Stretch;
            button1.Cursor = Cursors.Hand;
            button1.Font = new Font("Segoe UI", 13.8F);
            button1.Location = new Point(987, 635);
            button1.Name = "button1";
            button1.Size = new Size(187, 59);
            button1.TabIndex = 15;
            button1.Text = "Add Resident ";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(255, 192, 128);
            button2.BackgroundImageLayout = ImageLayout.Stretch;
            button2.Cursor = Cursors.Hand;
            button2.Font = new Font("Segoe UI", 13.8F);
            button2.Location = new Point(776, 635);
            button2.Name = "button2";
            button2.Size = new Size(205, 59);
            button2.TabIndex = 16;
            button2.Text = "Update Record";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // comboBox2
            // 
            comboBox2.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            comboBox2.FormattingEnabled = true;
            comboBox2.Items.AddRange(new object[] { "Staying Student", "Left Student", "Suspended" });
            comboBox2.Location = new Point(52, 88);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(221, 33);
            comboBox2.TabIndex = 18;
            comboBox2.Text = "Filter by student status";
            // 
            // button4
            // 
            button4.BackgroundImageLayout = ImageLayout.Stretch;
            button4.Cursor = Cursors.Hand;
            button4.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button4.Location = new Point(568, 89);
            button4.Name = "button4";
            button4.Size = new Size(113, 32);
            button4.TabIndex = 19;
            button4.Text = "Search";
            button4.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(386, 9);
            label3.Name = "label3";
            label3.Size = new Size(615, 38);
            label3.TabIndex = 20;
            label3.Text = "Kamran Boys Hostel - Residents Management";
            // 
            // errorProvider1
            // 
            errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            errorProvider2.ContainerControl = this;
            // 
            // errorProvider3
            // 
            errorProvider3.ContainerControl = this;
            // 
            // textBox7
            // 
            textBox7.Cursor = Cursors.IBeam;
            textBox7.Location = new Point(951, 182);
            textBox7.MaxLength = 50;
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(223, 27);
            textBox7.TabIndex = 22;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.Transparent;
            label8.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.Location = new Point(776, 181);
            label8.Name = "label8";
            label8.Size = new Size(128, 28);
            label8.TabIndex = 21;
            label8.Text = "Father Name";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.Transparent;
            label9.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.Location = new Point(776, 232);
            label9.Name = "label9";
            label9.Size = new Size(75, 28);
            label9.TabIndex = 24;
            label9.Text = "Region";
            // 
            // comboBox3
            // 
            comboBox3.FormattingEnabled = true;
            comboBox3.Items.AddRange(new object[] { "Islamabad Capital Teritory", "Punjab", "Sindh", "KPK", "Balochistan", "FATA", "Azad Kashmir", "Gilgit Baltistan" });
            comboBox3.Location = new Point(951, 233);
            comboBox3.Name = "comboBox3";
            comboBox3.Size = new Size(223, 28);
            comboBox3.TabIndex = 23;
            comboBox3.Text = "Select Region/Area";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.BackColor = Color.Transparent;
            label10.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label10.Location = new Point(776, 369);
            label10.Name = "label10";
            label10.Size = new Size(123, 28);
            label10.TabIndex = 25;
            label10.Text = "Full Address";
            // 
            // richTextBox1
            // 
            richTextBox1.Cursor = Cursors.IBeam;
            richTextBox1.Location = new Point(951, 373);
            richTextBox1.MaxLength = 200;
            richTextBox1.Name = "richTextBox1";
            richTextBox1.Size = new Size(223, 140);
            richTextBox1.TabIndex = 26;
            richTextBox1.Text = "";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(776, 536);
            label4.Name = "label4";
            label4.Size = new Size(67, 28);
            label4.TabIndex = 28;
            label4.Text = "Status";
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Staying Resident ", "Left Resident", "Suspended" });
            comboBox1.Location = new Point(951, 537);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(223, 28);
            comboBox1.TabIndex = 27;
            comboBox1.Text = "Select Status ";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.BackColor = Color.Transparent;
            label11.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label11.Location = new Point(776, 579);
            label11.Name = "label11";
            label11.Size = new Size(126, 28);
            label11.TabIndex = 29;
            label11.Text = "Joining Date";
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(950, 586);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(224, 27);
            dateTimePicker1.TabIndex = 30;
            // 
            // FormM2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = KBH_MS.Properties.Resources.blurred_blue_gradient_wallpaper_preview;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1235, 706);
            Controls.Add(dateTimePicker1);
            Controls.Add(label11);
            Controls.Add(label4);
            Controls.Add(comboBox1);
            Controls.Add(richTextBox1);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(comboBox3);
            Controls.Add(textBox7);
            Controls.Add(label8);
            Controls.Add(label3);
            Controls.Add(button4);
            Controls.Add(comboBox2);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label7);
            Controls.Add(textBox4);
            Controls.Add(label5);
            Controls.Add(textBox5);
            Controls.Add(label6);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(label2);
            Controls.Add(textBox1);
            Controls.Add(label1);
            Controls.Add(dataGridView1);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            MaximizeBox = false;
            Name = "FormM2";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "User Management";
            Load += FormS2_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)errorProvider1).EndInit();
            ((System.ComponentModel.ISupportInitialize)errorProvider2).EndInit();
            ((System.ComponentModel.ISupportInitialize)errorProvider3).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private Label label1;
        private TextBox textBox1;
        private TextBox textBox2;
        private Label label2;
        private TextBox textBox3;
        private TextBox textBox4;
        private Label label5;
        private TextBox textBox5;
        private Label label6;
        private Label label7;
        private Button button1;
        private Button button2;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private ComboBox comboBox2;
        private Button button4;
        private Label label3;
        private ErrorProvider errorProvider1;
        private ErrorProvider errorProvider2;
        private ErrorProvider errorProvider3;
        private TextBox textBox7;
        private Label label8;
        private Label label9;
        private ComboBox comboBox3;
        private RichTextBox richTextBox1;
        private Label label10;
        private Label label4;
        private ComboBox comboBox1;
        private DateTimePicker dateTimePicker1;
        private Label label11;
    }
}