﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hostelsystem
{
    public partial class FormJ8 : Form
    {
        public FormJ8()
        {
            InitializeComponent();
        }

        private void FormJ9_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
                errorProvider1.SetError(textBox1, "Enter 13 digit CNIC Number without dashes");
            }
            else
            {
                errorProvider1.SetError(textBox1, ""); // Clear error
            }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
                errorProvider2.SetError(textBox2, "Enter Phone Number without dashes");
            }
            else
            {
                errorProvider2.SetError(textBox2, ""); // Clear error
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string email = textBox5.Text.Trim();
            string cnic = textBox1.Text.Trim();
            string phone = textBox2.Text.Trim();
            string newPassword = textBox4.Text;
            string confirmPassword = textBox3.Text;

            // 1. Basic validations
            if (string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(cnic) ||
                string.IsNullOrWhiteSpace(phone) || string.IsNullOrWhiteSpace(newPassword) ||
                string.IsNullOrWhiteSpace(confirmPassword))
            {
                MessageBox.Show("Please fill all fields.");
                return;
            }

            if (newPassword != confirmPassword)
            {
                MessageBox.Show("Passwords do not match.");
                return;
            }

            // 2. Confirm user identity
            string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";
            string checkQuery = "SELECT COUNT(*) FROM users WHERE user_cnic = @cnic AND email = @mail AND phone_no = @phone";
            string updateQuery = "UPDATE users SET password = @password WHERE user_cnic = @cnic";

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();

                    // Validate identity
                    using (MySqlCommand checkCmd = new MySqlCommand(checkQuery, conn))
                    {
                        checkCmd.Parameters.AddWithValue("@cnic", cnic);
                        checkCmd.Parameters.AddWithValue("@mail", email);
                        checkCmd.Parameters.AddWithValue("@phone", phone);

                        int count = Convert.ToInt32(checkCmd.ExecuteScalar());
                        if (count == 0)
                        {
                            MessageBox.Show("User not found or details do not match.");
                            return;
                        }
                    }

                    // Update password
                    using (MySqlCommand updateCmd = new MySqlCommand(updateQuery, conn))
                    {
                        updateCmd.Parameters.AddWithValue("@password", newPassword);  // Optionally hash this
                        updateCmd.Parameters.AddWithValue("@cnic", cnic);

                        int rowsAffected = updateCmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Password updated successfully.");
                            ClearFields();
                        }
                        else
                        {
                            MessageBox.Show("Password update failed.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void ClearFields()
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();


        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
