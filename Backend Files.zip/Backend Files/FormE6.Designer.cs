﻿namespace announcements
{
    partial class FormE6
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormE6));
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            rtbDetails = new RichTextBox();
            txtTitle = new TextBox();
            txtAnnDate = new TextBox();
            txtAnnouncer = new TextBox();
            label5 = new Label();
            label1 = new Label();
            label6 = new Label();
            button3 = new Button();
            dgvAnnouncements = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dgvAnnouncements).BeginInit();
            SuspendLayout();
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Segoe UI Historic", 16.2F, FontStyle.Bold);
            label2.Location = new Point(58, 75);
            label2.Name = "label2";
            label2.Size = new Size(267, 38);
            label2.TabIndex = 4;
            label2.Text = "Announcement By:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Segoe UI Historic", 16.2F, FontStyle.Bold);
            label3.Location = new Point(58, 112);
            label3.Name = "label3";
            label3.Size = new Size(297, 38);
            label3.TabIndex = 5;
            label3.Text = "Announcement Date:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Segoe UI Historic", 16.2F, FontStyle.Bold);
            label4.Location = new Point(58, 149);
            label4.Name = "label4";
            label4.Size = new Size(293, 38);
            label4.TabIndex = 6;
            label4.Text = "Announcement Title:";
            // 
            // rtbDetails
            // 
            rtbDetails.Location = new Point(58, 245);
            rtbDetails.Name = "rtbDetails";
            rtbDetails.Size = new Size(523, 428);
            rtbDetails.TabIndex = 7;
            rtbDetails.Text = "";
            // 
            // txtTitle
            // 
            txtTitle.BackColor = Color.Black;
            txtTitle.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtTitle.ForeColor = Color.White;
            txtTitle.Location = new Point(357, 156);
            txtTitle.Name = "txtTitle";
            txtTitle.ReadOnly = true;
            txtTitle.Size = new Size(224, 31);
            txtTitle.TabIndex = 63;
            txtTitle.TextAlign = HorizontalAlignment.Center;
            // 
            // txtAnnDate
            // 
            txtAnnDate.BackColor = Color.Black;
            txtAnnDate.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtAnnDate.ForeColor = Color.White;
            txtAnnDate.Location = new Point(357, 119);
            txtAnnDate.Name = "txtAnnDate";
            txtAnnDate.ReadOnly = true;
            txtAnnDate.Size = new Size(224, 31);
            txtAnnDate.TabIndex = 62;
            txtAnnDate.TextAlign = HorizontalAlignment.Center;
            // 
            // txtAnnouncer
            // 
            txtAnnouncer.BackColor = Color.Black;
            txtAnnouncer.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtAnnouncer.ForeColor = Color.White;
            txtAnnouncer.Location = new Point(357, 82);
            txtAnnouncer.Name = "txtAnnouncer";
            txtAnnouncer.ReadOnly = true;
            txtAnnouncer.Size = new Size(224, 31);
            txtAnnouncer.TabIndex = 61;
            txtAnnouncer.TextAlign = HorizontalAlignment.Center;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.White;
            label5.Location = new Point(273, 201);
            label5.Name = "label5";
            label5.Size = new Size(107, 41);
            label5.TabIndex = 64;
            label5.Text = "Details";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(443, 9);
            label1.Name = "label1";
            label1.Size = new Size(322, 31);
            label1.TabIndex = 65;
            label1.Text = "Announcements and Notices";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.White;
            label6.Location = new Point(934, 201);
            label6.Name = "label6";
            label6.Size = new Size(112, 41);
            label6.TabIndex = 66;
            label6.Text = "History";
            // 
            // button3
            // 
            button3.BackColor = Color.LightSalmon;
            button3.Cursor = Cursors.Hand;
            button3.Location = new Point(765, 595);
            button3.Margin = new Padding(3, 4, 3, 4);
            button3.Name = "button3";
            button3.Size = new Size(429, 78);
            button3.TabIndex = 67;
            button3.Text = "Go to Dashboard";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // dgvAnnouncements
            // 
            dgvAnnouncements.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvAnnouncements.Location = new Point(765, 262);
            dgvAnnouncements.Name = "dgvAnnouncements";
            dgvAnnouncements.RowHeadersWidth = 51;
            dgvAnnouncements.Size = new Size(429, 298);
            dgvAnnouncements.TabIndex = 68;
            dgvAnnouncements.CellClick += dgvAnnouncements_CellClick_1;
            // 
            // FormE6
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1232, 703);
            Controls.Add(dgvAnnouncements);
            Controls.Add(button3);
            Controls.Add(label6);
            Controls.Add(label1);
            Controls.Add(label5);
            Controls.Add(txtTitle);
            Controls.Add(txtAnnDate);
            Controls.Add(txtAnnouncer);
            Controls.Add(rtbDetails);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            MaximizeBox = false;
            Name = "FormE6";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Announcements";
            Load += FormE6_Load;
            ((System.ComponentModel.ISupportInitialize)dgvAnnouncements).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private RichTextBox richTextBox1;
        private Label label2;
        private Label label3;
        private Label label4;
        private RichTextBox richTextBox2;
        private TextBox textBox3;
        private TextBox textBox2;
        private TextBox textBox1;
        private Label label5;
        private Label label1;
        private Label label6;
        private Button button3;
        private DataGridView dgvAnnouncements;
        private RichTextBox rtbDetails;
        private TextBox txtTitle;
        private TextBox txtAnnDate;
        private TextBox txtAnnouncer;
    }
}
