﻿using Kamraan_Boys_Hostel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using hostelsystem;
using MySql.Data.MySqlClient;

namespace Kamran_Boys_Hostel
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            LoadVisitors();
            LoadSecurityDashboard();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            FormJ7 formJ7 = new FormJ7();
            this.Hide();
            formJ7.ShowDialog();
            this.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FormM6 formM6 = new FormM6();
            this.Hide();
            formM6.ShowDialog();
            this.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form6 form6 = new Form6();
            this.Hide();
            form6.ShowDialog();
            this.Show();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            this.Hide();
            form3.ShowDialog();
            this.Show();

        }

        private void button7_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            this.Hide();
            form1.ShowDialog();
            this.Show();

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();
            this.Hide();
            form5.ShowDialog();
            this.Show();
        }

        private void LoadVisitors()
        {
            string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";
            string query = "SELECT vName AS 'Visitor Name', vCnic AS 'CNIC', vDate AS 'Date', vPurpose AS 'Purpose' FROM visits ORDER BY visitID DESC";

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();

                    using (MySqlDataAdapter adapter = new MySqlDataAdapter(query, conn))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        dataGridView1.DataSource = dt;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading visitor records: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void LoadSecurityDashboard()
        {
            string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();

                    // Total Monthly Visits
                    using (MySqlCommand cmd = new MySqlCommand(
                        "SELECT COUNT(*) FROM visits WHERE MONTH(STR_TO_DATE(vDate, '%m-%d-%Y')) = MONTH(CURRENT_DATE()) AND YEAR(STR_TO_DATE(vDate, '%m-%d-%Y')) = YEAR(CURRENT_DATE());", conn))
                    {
                        object result = cmd.ExecuteScalar();
                        lblMonthlyVisits.Text = result != null ? result.ToString() : "0";
                    }

                    // Total Visits Today
                    using (MySqlCommand cmd = new MySqlCommand(
                        "SELECT COUNT(*) FROM visits WHERE STR_TO_DATE(vDate, '%m-%d-%Y') = CURDATE();", conn))
                    {
                        object result = cmd.ExecuteScalar();
                        lblTodaysVisits.Text = result != null ? result.ToString() : "0";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading visit data: " + ex.Message);
            }
        }

    }
}
