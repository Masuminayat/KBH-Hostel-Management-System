﻿using Kamraan_Boys_Hostel;
using MySql.Data.MySqlClient;
using requestmaintenance;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hostelsystem
{
    public partial class FormJ7 : Form
    {
        public FormJ7()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormE4 formE4 = new FormE4();
            this.Hide();
            formE4.ShowDialog();
            this.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FormJ8 formJ8 = new FormJ8();
            this.Hide();
            formJ8.ShowDialog();
            this.Show();
        }

        private void FormJ7_Load(object sender, EventArgs e)
        {
            LoadUserProfile();
        }

        private void LoadUserProfile()
        {
            string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";
            string query = "SELECT full_Name, user_cnic, phone_no, email, user_role FROM users WHERE user_cnic = @cnic";

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@cnic", UserSession.CNIC);
                        using (MySqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                textBox1.Text = reader["full_Name"].ToString();
                                textBox2.Text = reader["user_cnic"].ToString();
                                textBox3.Text = reader["phone_no"].ToString();
                                textBox4.Text = reader["email"].ToString();
                                textBox5.Text = reader["user_role"].ToString();
                            }
                            else
                            {
                                MessageBox.Show("User not found.");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading profile: " + ex.Message);
            }
        }

    }
}
