﻿using hostelsystem;
using Kamran_Boys_Hostel;
using MySql.Data.MySqlClient;
using Org.BouncyCastle.Asn1.Cmp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KBH_MS
{
    public partial class FormM5 : Form
    {
        public FormM5()
        {
            InitializeComponent();
            LoadComplaints();
        }

        private void FormS4_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click_1(object sender, EventArgs e)
        {

        }


        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }


        private void LoadComplaints()
        {
            string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";
            string query = "SELECT comID, sCNIC, comDate, comType, comDesc, comStatus FROM complaints order by comID desc";

            using (MySqlConnection conn = new MySqlConnection(connectionString))
            using (MySqlDataAdapter adapter = new MySqlDataAdapter(query, conn))
            {
                DataTable table = new DataTable();
                adapter.Fill(table);
                dataGridView1.DataSource = table;

                // Optional: Rename columns for better headers
                dataGridView1.Columns["comID"].HeaderText = "Complaint ID";
                dataGridView1.Columns["sCNIC"].HeaderText = "CNIC";
                dataGridView1.Columns["comDate"].HeaderText = "Date";
                dataGridView1.Columns["comType"].HeaderText = "Type";
                dataGridView1.Columns["comDesc"].HeaderText = "Description";
                dataGridView1.Columns["comStatus"].HeaderText = "Status";
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                string cnic = row.Cells["sCNIC"].Value.ToString();
                string submittedBy = UserName.GetUserNameByCNIC(cnic); // from your methods.cs

                label9.Text = submittedBy;
                label8.Text = row.Cells["comDate"].Value.ToString();
                label11.Text = row.Cells["comType"].Value.ToString();
                richTextBox1.Text = row.Cells["comDesc"].Value.ToString();
                label10.Text = row.Cells["comStatus"].Value.ToString();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null)
            {
                int complaintId = Convert.ToInt32(dataGridView1.CurrentRow.Cells["comID"].Value);
                string complaintType = dataGridView1.CurrentRow.Cells["comType"].Value.ToString();
                string currentStatus = dataGridView1.CurrentRow.Cells["comStatus"].Value.ToString();

                // Optional: prevent re-resolving if already resolved
                if (currentStatus == "Resolved")
                {
                    MessageBox.Show("This complaint has already been resolved.", "Already Resolved", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                DialogResult confirm = MessageBox.Show(
                    $"Are you sure you want to mark the {complaintType} (ID: {complaintId}) as Resolved?",
                    "Confirm Resolution",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);

                if (confirm == DialogResult.Yes)
                {
                    string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";
                    string query = "UPDATE complaints SET comStatus = 'Resolved' WHERE comID = @id";

                    using (MySqlConnection conn = new MySqlConnection(connectionString))
                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        try
                        {
                            conn.Open();
                            cmd.Parameters.AddWithValue("@id", complaintId);
                            int rowsAffected = cmd.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Complaint marked as Resolved.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                LoadComplaints(); // Reload your DataGridView
                            }
                            else
                            {
                                MessageBox.Show("Unable to update status.", "Update Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a complaint first.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormM1 formM1 = new FormM1();
            this.Hide();
            formM1.ShowDialog();
        }
    }
}
