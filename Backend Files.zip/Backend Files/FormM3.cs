﻿using form_2;
using MySql.Data.MySqlClient;
using Org.BouncyCastle.Asn1.Cmp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kamran_Boys_Hostel
{
    public partial class FormM3 : Form
    {
        public FormM3()
        {
            InitializeComponent();
            LoadBillsIntoGrid();
        }

        private void splitContainer1_Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }



        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void FetchResidentDetailsByCNIC(string cnic)
        {
            string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";
            string query = "SELECT fullName, fatherName FROM residents WHERE cnic = @cnic";

            using (MySqlConnection con = new MySqlConnection(connectionString))
            {
                using (MySqlCommand cmd = new MySqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@cnic", cnic);
                    con.Open();

                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            lblName.Text = reader["fullName"].ToString();
                            lblFatherName.Text = reader["fatherName"].ToString();
                        }
                        else
                        {
                            lblName.Text = "N/A";
                            lblFatherName.Text = "N/A";
                        }
                    }
                }
            }
        }


        private void LoadBillsIntoGrid()
        {
            string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";
            string query = "SELECT billID, rCnic, roomID, bMonth, bYear, bAmount, isPaid, issueDate FROM bills ORDER BY issueDate DESC";

            using (MySqlConnection con = new MySqlConnection(connectionString))
            {
                using (MySqlCommand cmd = new MySqlCommand(query, con))
                {
                    MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    dataGridView1.DataSource = dt;
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {

            if (lblBillID.Text != "" && lblStatus.Text == "Unpaid")
            {
                DialogResult result = MessageBox.Show("Are you sure you want to mark this bill as PAID?",
                                                      "Confirm Payment",
                                                      MessageBoxButtons.YesNo,
                                                      MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";
                    string updateQuery = "UPDATE bills SET isPaid = TRUE WHERE billID = @billID";

                    using (MySqlConnection con = new MySqlConnection(connectionString))
                    {
                        con.Open();
                        using (MySqlCommand cmd = new MySqlCommand(updateQuery, con))
                        {
                            cmd.Parameters.AddWithValue("@billID", lblBillID.Text);
                            cmd.ExecuteNonQuery();
                        }
                    }

                    MessageBox.Show("Bill marked as PAID successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadBillsIntoGrid();
                }
            }
            else
            {
                MessageBox.Show("Please select an unpaid bill first.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                string cnic = row.Cells["rCnic"].Value.ToString();
                lblBillID.Text = row.Cells["billID"].Value.ToString();
                lblRoomID.Text = row.Cells["roomID"].Value.ToString();
                lblMonth.Text = row.Cells["bMonth"].Value.ToString() + " " + row.Cells["bYear"].Value.ToString();
                lblAmount.Text = row.Cells["bAmount"].Value.ToString() + " RS";
                lblStatus.Text = Convert.ToBoolean(row.Cells["isPaid"].Value) ? "Paid" : "Unpaid";
                DateTime issueDate = Convert.ToDateTime(row.Cells["issueDate"].Value);
                label8.Text = issueDate.AddDays(5).ToString("dd MMMM yyyy");


                // Fetch name and father name from users table using CNIC
                FetchResidentDetailsByCNIC(cnic);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            FormE1 formE1 = new FormE1();
            this.Hide();
            formE1.ShowDialog();
        }

        private void FormM3_Load(object sender, EventArgs e)
        {

        }
    }
}

