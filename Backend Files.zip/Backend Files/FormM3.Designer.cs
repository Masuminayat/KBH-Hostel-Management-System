﻿namespace Kamran_Boys_Hostel
{
    partial class FormM3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label3 = new Label();
            dataGridView1 = new DataGridView();
            comboBox3 = new ComboBox();
            comboBox2 = new ComboBox();
            button7 = new Button();
            textBox2 = new TextBox();
            lblAmount = new Label();
            label12 = new Label();
            lblName = new Label();
            label8 = new Label();
            label1 = new Label();
            label4 = new Label();
            lblFatherName = new Label();
            label5 = new Label();
            lblMonth = new Label();
            label7 = new Label();
            button3 = new Button();
            button1 = new Button();
            lblStatus = new Label();
            label13 = new Label();
            lblBillID = new Label();
            label9 = new Label();
            lblRoomID = new Label();
            label6 = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(362, 9);
            label3.Name = "label3";
            label3.Size = new Size(473, 38);
            label3.TabIndex = 22;
            label3.Text = "Kamran Boys Hostel - Rent Section";
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Cursor = Cursors.Hand;
            dataGridView1.Location = new Point(75, 221);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.Size = new Size(540, 425);
            dataGridView1.TabIndex = 23;
            dataGridView1.CellClick += dataGridView1_CellClick;
            // 
            // comboBox3
            // 
            comboBox3.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            comboBox3.FormattingEnabled = true;
            comboBox3.Items.AddRange(new object[] { "Paid", "Pending" });
            comboBox3.Location = new Point(75, 120);
            comboBox3.Name = "comboBox3";
            comboBox3.Size = new Size(540, 33);
            comboBox3.TabIndex = 64;
            comboBox3.Text = "Payment Status";
            // 
            // comboBox2
            // 
            comboBox2.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            comboBox2.FormattingEnabled = true;
            comboBox2.Items.AddRange(new object[] { "Ascending", "Descending" });
            comboBox2.Location = new Point(75, 162);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(143, 33);
            comboBox2.TabIndex = 62;
            comboBox2.Text = "Sort by Amount";
            // 
            // button7
            // 
            button7.BackgroundImageLayout = ImageLayout.Stretch;
            button7.Cursor = Cursors.Hand;
            button7.Location = new Point(529, 162);
            button7.Margin = new Padding(3, 4, 3, 4);
            button7.Name = "button7";
            button7.Size = new Size(86, 31);
            button7.TabIndex = 61;
            button7.Text = "Search";
            button7.UseVisualStyleBackColor = true;
            // 
            // textBox2
            // 
            textBox2.BackColor = Color.White;
            textBox2.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox2.Location = new Point(224, 163);
            textBox2.Margin = new Padding(3, 4, 3, 4);
            textBox2.Name = "textBox2";
            textBox2.PlaceholderText = "Search by CNIC/Name ";
            textBox2.Size = new Size(296, 31);
            textBox2.TabIndex = 60;
            textBox2.TextAlign = HorizontalAlignment.Center;
            // 
            // lblAmount
            // 
            lblAmount.AutoSize = true;
            lblAmount.BackColor = Color.DimGray;
            lblAmount.Font = new Font("Microsoft YaHei", 10.8F);
            lblAmount.ForeColor = Color.White;
            lblAmount.Location = new Point(943, 356);
            lblAmount.Name = "lblAmount";
            lblAmount.Size = new Size(46, 24);
            lblAmount.TabIndex = 70;
            lblAmount.Text = "N/A";
            lblAmount.TextAlign = ContentAlignment.TopCenter;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.BackColor = Color.Transparent;
            label12.Font = new Font("Segoe UI Historic", 13.8F, FontStyle.Bold);
            label12.ForeColor = Color.White;
            label12.Location = new Point(767, 353);
            label12.Name = "label12";
            label12.Size = new Size(170, 31);
            label12.TabIndex = 69;
            label12.Text = "Pending Rent:";
            // 
            // lblName
            // 
            lblName.AutoSize = true;
            lblName.BackColor = Color.DimGray;
            lblName.Font = new Font("Microsoft YaHei", 10.8F);
            lblName.ForeColor = Color.White;
            lblName.Location = new Point(944, 112);
            lblName.Name = "lblName";
            lblName.Size = new Size(46, 24);
            lblName.TabIndex = 68;
            lblName.Text = "N/A";
            lblName.TextAlign = ContentAlignment.TopCenter;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.DimGray;
            label8.Font = new Font("Microsoft YaHei", 10.8F);
            label8.ForeColor = Color.White;
            label8.Location = new Point(942, 404);
            label8.Name = "label8";
            label8.Size = new Size(46, 24);
            label8.TabIndex = 67;
            label8.Text = "N/A";
            label8.TextAlign = ContentAlignment.TopCenter;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI Historic", 13.8F, FontStyle.Bold);
            label1.ForeColor = Color.White;
            label1.Location = new Point(767, 401);
            label1.Name = "label1";
            label1.Size = new Size(123, 31);
            label1.TabIndex = 66;
            label1.Text = "Due Date:";
            label1.Click += label1_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Segoe UI Historic", 13.8F, FontStyle.Bold);
            label4.ForeColor = Color.White;
            label4.Location = new Point(767, 106);
            label4.Name = "label4";
            label4.Size = new Size(85, 31);
            label4.TabIndex = 65;
            label4.Text = "Name:";
            // 
            // lblFatherName
            // 
            lblFatherName.AutoSize = true;
            lblFatherName.BackColor = Color.DimGray;
            lblFatherName.Font = new Font("Microsoft YaHei", 10.8F);
            lblFatherName.ForeColor = Color.White;
            lblFatherName.Location = new Point(942, 164);
            lblFatherName.Name = "lblFatherName";
            lblFatherName.Size = new Size(46, 24);
            lblFatherName.TabIndex = 72;
            lblFatherName.Text = "N/A";
            lblFatherName.TextAlign = ContentAlignment.TopCenter;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Segoe UI Historic", 13.8F, FontStyle.Bold);
            label5.ForeColor = Color.White;
            label5.Location = new Point(766, 158);
            label5.Name = "label5";
            label5.Size = new Size(162, 31);
            label5.TabIndex = 71;
            label5.Text = "Father Name:";
            // 
            // lblMonth
            // 
            lblMonth.AutoSize = true;
            lblMonth.BackColor = Color.DimGray;
            lblMonth.Font = new Font("Microsoft YaHei", 10.8F);
            lblMonth.ForeColor = Color.White;
            lblMonth.Location = new Point(942, 260);
            lblMonth.Name = "lblMonth";
            lblMonth.Size = new Size(46, 24);
            lblMonth.TabIndex = 74;
            lblMonth.Text = "N/A";
            lblMonth.TextAlign = ContentAlignment.TopCenter;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.Transparent;
            label7.Font = new Font("Segoe UI Historic", 13.8F, FontStyle.Bold);
            label7.ForeColor = Color.White;
            label7.Location = new Point(767, 258);
            label7.Name = "label7";
            label7.Size = new Size(135, 31);
            label7.TabIndex = 73;
            label7.Text = "Bill Month:";
            // 
            // button3
            // 
            button3.BackColor = Color.Gold;
            button3.BackgroundImageLayout = ImageLayout.Stretch;
            button3.Cursor = Cursors.Hand;
            button3.Location = new Point(766, 505);
            button3.Margin = new Padding(3, 4, 3, 4);
            button3.Name = "button3";
            button3.Size = new Size(318, 67);
            button3.TabIndex = 75;
            button3.Text = "Set as paid";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.Gold;
            button1.BackgroundImageLayout = ImageLayout.Stretch;
            button1.Cursor = Cursors.Hand;
            button1.Location = new Point(766, 580);
            button1.Margin = new Padding(3, 4, 3, 4);
            button1.Name = "button1";
            button1.Size = new Size(318, 67);
            button1.TabIndex = 76;
            button1.Text = "Go to Dashboard";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // lblStatus
            // 
            lblStatus.AutoSize = true;
            lblStatus.BackColor = Color.DimGray;
            lblStatus.Font = new Font("Microsoft YaHei", 10.8F);
            lblStatus.ForeColor = Color.White;
            lblStatus.Location = new Point(944, 457);
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new Size(46, 24);
            lblStatus.TabIndex = 78;
            lblStatus.Text = "N/A";
            lblStatus.TextAlign = ContentAlignment.TopCenter;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.BackColor = Color.Transparent;
            label13.Font = new Font("Segoe UI Historic", 13.8F, FontStyle.Bold);
            label13.ForeColor = Color.White;
            label13.Location = new Point(767, 455);
            label13.Name = "label13";
            label13.Size = new Size(89, 31);
            label13.TabIndex = 77;
            label13.Text = "Status:";
            // 
            // lblBillID
            // 
            lblBillID.AutoSize = true;
            lblBillID.BackColor = Color.DimGray;
            lblBillID.Font = new Font("Microsoft YaHei", 10.8F);
            lblBillID.ForeColor = Color.White;
            lblBillID.Location = new Point(942, 210);
            lblBillID.Name = "lblBillID";
            lblBillID.Size = new Size(46, 24);
            lblBillID.TabIndex = 80;
            lblBillID.Text = "N/A";
            lblBillID.TextAlign = ContentAlignment.TopCenter;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.Transparent;
            label9.Font = new Font("Segoe UI Historic", 13.8F, FontStyle.Bold);
            label9.ForeColor = Color.White;
            label9.Location = new Point(767, 207);
            label9.Name = "label9";
            label9.Size = new Size(80, 31);
            label9.TabIndex = 79;
            label9.Text = "Bill ID";
            // 
            // lblRoomID
            // 
            lblRoomID.AutoSize = true;
            lblRoomID.BackColor = Color.DimGray;
            lblRoomID.Font = new Font("Microsoft YaHei", 10.8F);
            lblRoomID.ForeColor = Color.White;
            lblRoomID.Location = new Point(942, 309);
            lblRoomID.Name = "lblRoomID";
            lblRoomID.Size = new Size(46, 24);
            lblRoomID.TabIndex = 82;
            lblRoomID.Text = "N/A";
            lblRoomID.TextAlign = ContentAlignment.TopCenter;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Font = new Font("Segoe UI Historic", 13.8F, FontStyle.Bold);
            label6.ForeColor = Color.White;
            label6.Location = new Point(767, 306);
            label6.Name = "label6";
            label6.Size = new Size(175, 31);
            label6.TabIndex = 81;
            label6.Text = "Room Number";
            // 
            // FormM3
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = KBH_MS.Properties.Resources.blurred_blue_gradient_wallpaper_preview;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1232, 703);
            Controls.Add(lblRoomID);
            Controls.Add(label6);
            Controls.Add(lblBillID);
            Controls.Add(label9);
            Controls.Add(lblStatus);
            Controls.Add(label13);
            Controls.Add(button1);
            Controls.Add(button3);
            Controls.Add(lblMonth);
            Controls.Add(label7);
            Controls.Add(lblFatherName);
            Controls.Add(label5);
            Controls.Add(lblAmount);
            Controls.Add(label12);
            Controls.Add(lblName);
            Controls.Add(label8);
            Controls.Add(label1);
            Controls.Add(label4);
            Controls.Add(comboBox3);
            Controls.Add(comboBox2);
            Controls.Add(button7);
            Controls.Add(textBox2);
            Controls.Add(dataGridView1);
            Controls.Add(label3);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            MaximizeBox = false;
            Name = "FormM3";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Reports";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label3;
        private DataGridView dataGridView1;
        private ComboBox comboBox3;
        private ComboBox comboBox2;
        private Button button7;
        private TextBox textBox2;
        private Label lblAmount;
        private Label label12;
        private Label lblName;
        private Label label8;
        private Label label1;
        private Label label4;
        private Label lblFatherName;
        private Label label5;
        private Label lblMonth;
        private Label label7;
        private Button button3;
        private Button button1;
        private Label lblStatus;
        private Label label13;
        private Label lblBillID;
        private Label label9;
        private Label lblRoomID;
        private Label label6;
    }
}