using hostelsystem;
using Kamraan_Boys_Hostel;
using Kamran_Boys_Hostel;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KBH_Owner
{
    public partial class FormS1 : Form
    {
        public FormS1()
        {
            InitializeComponent();
            LoadOwnerDashboard();
            
        }

        private void FormS1_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            FormS2 formS2 = new FormS2();
            this.Hide();
            formS2.ShowDialog();
            this.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FormS4 formS4 = new FormS4();
            this.Hide();
            formS4.ShowDialog();
            this.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FormS3 formS3 = new FormS3();
            this.Hide();
            formS3.ShowDialog();
            this.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormS5 formS5 = new FormS5();
            this.Hide();
            formS5.ShowDialog();
            this.Show();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
            FormJ7 formJ7 = new FormJ7();
            this.Hide();
            formJ7.ShowDialog();
            this.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            this.Hide();
            form1.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            FormM1 formM1 = new FormM1();
            this.Hide();
            formM1.ShowDialog();
        }


        private void LoadOwnerDashboard()       //Monthly Overview
        {
            string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";
            string currentMonth = DateTime.Now.ToString("MMMM");
            int currentYear = DateTime.Now.Year;

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();

                    // 1. Residents Staying
                    using (MySqlCommand cmd = new MySqlCommand("SELECT COUNT(*) FROM allocations WHERE deallocation_date IS NULL;", conn))
                    {
                        lblResidentsStaying.Text = cmd.ExecuteScalar().ToString()+" Residents";
                    }

                    // 2. Monthly Rent Collected
                    decimal rentCollected = 0;
                    using (MySqlCommand cmd = new MySqlCommand(
                        "SELECT IFNULL(SUM(bAmount), 0) FROM bills WHERE isPaid = 1 AND bMonth = @month AND bYear = @year;", conn))
                    {
                        cmd.Parameters.AddWithValue("@month", currentMonth);
                        cmd.Parameters.AddWithValue("@year", currentYear);
                        rentCollected = Convert.ToDecimal(cmd.ExecuteScalar());
                        lblRentCollected.Text = ((int)rentCollected).ToString()+" RS";
                    }

                    // 3. Due Rent (Unpaid)
                    decimal rentDue = 0;
                    using (MySqlCommand cmd = new MySqlCommand(
                        "SELECT IFNULL(SUM(bAmount), 0) FROM bills WHERE isPaid = 0 AND bMonth = @month AND bYear = @year;", conn))
                    {
                        cmd.Parameters.AddWithValue("@month", currentMonth);
                        cmd.Parameters.AddWithValue("@year", currentYear);
                        rentDue = Convert.ToDecimal(cmd.ExecuteScalar());
                        lblRentDue.Text = ((int)rentDue).ToString()+" RS";
                    }

                    // 4. Monthly Expenses
                    decimal expenses = 0;
                    using (MySqlCommand cmd = new MySqlCommand(
                        "SELECT IFNULL(SUM(expAmount), 0) FROM expenses WHERE MONTH(STR_TO_DATE(expDate, '%m-%d-%Y')) = MONTH(CURDATE()) AND YEAR(STR_TO_DATE(expDate, '%m-%d-%Y')) = YEAR(CURDATE());", conn))
                    {
                        expenses = Convert.ToDecimal(cmd.ExecuteScalar());
                        lblExpenses.Text = ((int)expenses).ToString()+" RS";
                    }

                    // 5. Net Profit
                    decimal netProfit = rentCollected - expenses;
                    lblNetProfit.Text = ((int)netProfit).ToString()+" RS";

                    // 6. Monthly Visits
                    int monthlyVisits = 0;
                    using (MySqlCommand cmd = new MySqlCommand(
                        "SELECT COUNT(*) FROM visits WHERE MONTH(STR_TO_DATE(vDate, '%m-%d-%Y')) = MONTH(CURDATE()) AND YEAR(STR_TO_DATE(vDate, '%m-%d-%Y')) = YEAR(CURDATE());", conn))
                    {
                        monthlyVisits = Convert.ToInt32(cmd.ExecuteScalar());
                        lblMonthlyVisits.Text = monthlyVisits.ToString()+" Visits";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading dashboard: " + ex.Message);
            }
        }

    }
}
