using form_2;
using hostelsystem;
using Kamran_Boys_Hostel;
using KBH_Owner;
using MySql.Data.MySqlClient;


namespace Kamraan_Boys_Hostel
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }


        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
                errorProvider1.SetError(textBox1, "Enter 13 digit CNIC Number without dashes");
            }
            else
            {
                errorProvider1.SetError(textBox1, ""); // Clear error
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
    
            string cnic = textBox1.Text.Trim();
            string password = textBox2.Text.Trim();

            if (cnic == "" || password == "")
            {
                MessageBox.Show("Please enter both CNIC and Password.");
                return;
            }

            string connStr = "server=localhost;user=root;password=root;database=kbh_ms;";
            using (MySqlConnection conn = new MySqlConnection(connStr))
            {
                try
                {
                    conn.Open();

                    string query = "SELECT user_role FROM users WHERE user_cnic = @cnic AND password = @password";
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@cnic", cnic);
                    cmd.Parameters.AddWithValue("@password", password);

                    object result = cmd.ExecuteScalar();

                    if (result != null)
                    {
                        string role = result.ToString();
                        MessageBox.Show($"Login successful as {role}");

                      

                        // Save user details in session
                        UserSession.CNIC = cnic;
                        UserSession.Role = role;



                        // Redirect to appropriate dashboard
                        switch (role)
                        {
                            case "Admin":
                                new FormS1().Show(); break;
                            case "Staying Resident":
                                new FormE1().Show(); break;
                            case "Manager":
                                new FormM1().Show(); break;
                            case "Security":
                                new Form2().Show(); break;
                            default:
                                MessageBox.Show("Unknown role."); break;
                        }

                        this.Hide(); // Hide login form
                    }
                    else
                    {
                        MessageBox.Show("Invalid CNIC or Password.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        

        private void button2_Click(object sender, EventArgs e)
        {
            FormJ8 formJ8 = new FormJ8();
            this.Hide();
            formJ8.ShowDialog();
            this.Show();
        }
    }
}
