﻿using form_2;
using hostelsystem;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace requestmaintenance
{
    public partial class FormE4 : Form
    {
        public FormE4()
        {
            InitializeComponent();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            FormE1 formE1 = new FormE1();
            this.Hide();
            formE1.ShowDialog();

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(comboBox1.Text) || string.IsNullOrWhiteSpace(richTextBox1.Text))
            {
                MessageBox.Show("Please fill in both complaint type and description.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string cnic = UserSession.CNIC; // from existing session
            string comDate = DateTime.Now.ToString("MM-dd-yyyy");
            string comType = comboBox1.SelectedItem.ToString();
            string comDesc = richTextBox1.Text.Trim();
            string comStatus = "Pending"; // default status

            string connectionString = "server=localhost;user=root;password=root;database=kbh_ms;";
            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                try
                {
                    conn.Open();

                    string insertQuery = @"
                INSERT INTO complaints (sCNIC, comDate, comType, comDesc, comStatus)
                VALUES (@sCnic, @comDate, @comType, @comDesc, @comStatus)";

                    using (MySqlCommand cmd = new MySqlCommand(insertQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@sCnic", cnic);
                        cmd.Parameters.AddWithValue("@comDate", comDate);
                        cmd.Parameters.AddWithValue("@comType", comType);
                        cmd.Parameters.AddWithValue("@comDesc", comDesc);
                        cmd.Parameters.AddWithValue("@comStatus", comStatus);

                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Complaint submitted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        // Optionally clear fields
                        comboBox1.SelectedIndex = 0;
                        richTextBox1.Clear();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error submitting complaint: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            comboBox1.SelectedIndex = 0;
            richTextBox1.Clear();
        }
    }
}
