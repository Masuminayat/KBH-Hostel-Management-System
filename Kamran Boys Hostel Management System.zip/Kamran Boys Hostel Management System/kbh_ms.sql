-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: kbh_ms
-- ------------------------------------------------------
-- Server version	9.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `allocations`
--

DROP TABLE IF EXISTS `allocations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `allocations` (
  `allocation_id` int NOT NULL AUTO_INCREMENT,
  `resident_cnic` bigint NOT NULL,
  `room_id` varchar(100) NOT NULL,
  `allocation_date` date NOT NULL,
  `deallocation_date` date DEFAULT NULL,
  PRIMARY KEY (`allocation_id`),
  KEY `resident_cnic` (`resident_cnic`),
  KEY `room_id` (`room_id`),
  CONSTRAINT `allocations_ibfk_1` FOREIGN KEY (`resident_cnic`) REFERENCES `residents` (`cnic`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `allocations_ibfk_2` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`roomNumber`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `allocations`
--

LOCK TABLES `allocations` WRITE;
/*!40000 ALTER TABLE `allocations` DISABLE KEYS */;
INSERT INTO `allocations` VALUES (31,2756748234783,'B-03','2025-05-29',NULL),(32,8313748234783,'B-01','2025-05-29',NULL),(33,3413748234783,'B-01','2025-05-30',NULL),(34,1752748234783,'B-02','2025-05-30',NULL),(35,8756748234783,'B-04','2025-05-30','2025-05-30');
/*!40000 ALTER TABLE `allocations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcements` (
  `annID` int NOT NULL AUTO_INCREMENT,
  `annBy` varchar(255) DEFAULT NULL,
  `annHead` varchar(255) DEFAULT NULL,
  `annDate` varchar(50) DEFAULT NULL,
  `annDesc` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`annID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
INSERT INTO `announcements` VALUES (1,'Imran Hamed (Manager) ','New','05-30-2025','Mess Timing changed for lunch, new timings: 2-4 pm');
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bills`
--

DROP TABLE IF EXISTS `bills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bills` (
  `billID` int NOT NULL AUTO_INCREMENT,
  `rCnic` varchar(13) DEFAULT NULL,
  `roomID` varchar(10) DEFAULT NULL,
  `bMonth` varchar(10) DEFAULT NULL,
  `bYear` int DEFAULT NULL,
  `bAmount` decimal(10,2) DEFAULT NULL,
  `isPaid` tinyint(1) DEFAULT '0',
  `issueDate` date DEFAULT NULL,
  PRIMARY KEY (`billID`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bills`
--

LOCK TABLES `bills` WRITE;
/*!40000 ALTER TABLE `bills` DISABLE KEYS */;
INSERT INTO `bills` VALUES (1,'2756748234783','B-03','May',2025,22000.00,0,'2025-05-30'),(2,'8313748234783','B-01','May',2025,28000.00,1,'2025-05-30'),(3,'3413748234783','B-01','May',2025,28000.00,1,'2025-05-30'),(4,'1752748234783','B-02','May',2025,24000.00,0,'2025-05-30'),(5,'8756748234783','B-04','May',2025,19000.00,1,'2025-05-30'),(6,'2756748234783','B-03','June',2025,22000.00,0,'2025-06-03'),(7,'8313748234783','B-01','June',2025,28500.00,1,'2025-06-03'),(8,'3413748234783','B-01','June',2025,28500.00,0,'2025-06-03'),(9,'1752748234783','B-02','June',2025,24000.00,0,'2025-06-03');
/*!40000 ALTER TABLE `bills` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `complaints`
--

DROP TABLE IF EXISTS `complaints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `complaints` (
  `comID` int NOT NULL AUTO_INCREMENT,
  `sCNIC` varchar(13) DEFAULT NULL,
  `comDate` varchar(50) DEFAULT NULL,
  `comType` varchar(50) DEFAULT NULL,
  `comDesc` varchar(1000) DEFAULT NULL,
  `comStatus` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`comID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `complaints`
--

LOCK TABLES `complaints` WRITE;
/*!40000 ALTER TABLE `complaints` DISABLE KEYS */;
INSERT INTO `complaints` VALUES (1,'2756748234783','05-30-2025','Query','Fan not working properly','Pending');
/*!40000 ALTER TABLE `complaints` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expenses`
--

DROP TABLE IF EXISTS `expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `expenses` (
  `expID` int NOT NULL AUTO_INCREMENT,
  `expCat` varchar(50) DEFAULT NULL,
  `expDate` varchar(50) DEFAULT NULL,
  `expAmount` int DEFAULT NULL,
  `expDesc` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`expID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expenses`
--

LOCK TABLES `expenses` WRITE;
/*!40000 ALTER TABLE `expenses` DISABLE KEYS */;
INSERT INTO `expenses` VALUES (1,'Electricity Bill ','05-28-2025',5000,'IESCO Electricity Bill Payment'),(2,'Salary','05-30-2025',14000,'Monthly Salary to Security');
/*!40000 ALTER TABLE `expenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `residents`
--

DROP TABLE IF EXISTS `residents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `residents` (
  `cnic` bigint NOT NULL,
  `fullName` varchar(100) DEFAULT NULL,
  `fatherName` varchar(100) DEFAULT NULL,
  `region` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phoneNo` varchar(15) DEFAULT NULL,
  `fullAddress` varchar(255) DEFAULT NULL,
  `rStatus` varchar(50) DEFAULT NULL,
  `joinDate` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`cnic`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `residents`
--

LOCK TABLES `residents` WRITE;
/*!40000 ALTER TABLE `residents` DISABLE KEYS */;
INSERT INTO `residents` VALUES (12345654,'tanvir','taimor','KPK','mehmood@','12345','kashmir','Staying Resident ','2025-05-30 00:00:00'),(123456547654,'tanvir','taimor','KPK','mehmood@','12345','kashmir','Staying Resident ','2025-05-30 00:00:00'),(1752748234783,'Sibas Ahmad','Zubair ','isb','sibas.zubair@gmail.com','033587973827','House number 504, Street 07, Housing Scheme Rawalakot','Staying Resident ','2025-05-30 00:00:00'),(2756748234783,'Ibad Naeem','Muhammad Naeem ','Gilgit Baltistan','ibadnaeem@yahoo.com','03178765654','Khomar Chowk, Gilgit','Staying Resident ','2025-05-30 00:00:00'),(3413748234783,'Samar','Bazir','Punjab','samarbazir@gmail.com','03318473827','House Number 75, Street 03, Satellite Town, Rawalpindi','Staying Resident ','2025-05-29 00:00:00'),(8313748234783,'Adil','Muneer','KPK','adil.muneer@icloud.com','03358473827','House Number 32, Street 17, Hayatabad ','Staying Resident ','2025-05-28 00:00:00'),(8756748234783,'Dilawar Khan','Sajid','KPK','dilawarkhan@gmail.com','03127676842','North Waziristan','Staying Resident ','2025-05-30 00:00:00');
/*!40000 ALTER TABLE `residents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rooms`
--

DROP TABLE IF EXISTS `rooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rooms` (
  `roomNumber` varchar(100) NOT NULL,
  `maxCapacity` int DEFAULT NULL,
  `monthlyCharge` int DEFAULT NULL,
  `roomDetails` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`roomNumber`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rooms`
--

LOCK TABLES `rooms` WRITE;
/*!40000 ALTER TABLE `rooms` DISABLE KEYS */;
INSERT INTO `rooms` VALUES ('B-01',2,28500,'AC, heater and room cooler available inside'),('B-02',3,23500,'AC Available only'),('B-03',4,22000,'4 Seater room'),('B-04',5,19000,'5 Seater room'),('B-05',4,26000,'');
/*!40000 ALTER TABLE `rooms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `user_cnic` bigint NOT NULL,
  `full_Name` varchar(100) DEFAULT NULL,
  `user_role` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone_no` varchar(15) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`user_cnic`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (12345654,'tanvir','Staying Resident','mehmood@','12345','12345'),(123456547654,'tanvir','Staying Resident','mehmood@','12345','12345'),(1234567890123,'Kamran Hameed','Admin','admin@kbh.com','03456576433','owner'),(1234567890234,'Imran Hamed','Manager','imran.hameed@gmail.com','03345789301','manager'),(1234567890345,'Ehsaan ','Security','ehsaan321@gmail.com','03105672801','security'),(2756748234783,'Ibad Naeem','Staying Resident','ibadnaeem@yahoo.com','03178765654','03178765654'),(3413748234783,'Samar','Staying Resident','samarbazir@gmail.com','03318473827','03318473827'),(8313748234783,'Adil','Staying Resident','adil.muneer@icloud.com','03358473827','03358473827'),(8756748234783,'Dilawar Khan','Staying Resident','dilawarkhan@gmail.com','03127676842','03127676842');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `visits`
--

DROP TABLE IF EXISTS `visits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `visits` (
  `visitID` int NOT NULL AUTO_INCREMENT,
  `vName` varchar(100) DEFAULT NULL,
  `vCnic` bigint DEFAULT NULL,
  `vDate` varchar(50) DEFAULT NULL,
  `vPurpose` varchar(100) DEFAULT NULL,
  `vDetails` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`visitID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `visits`
--

LOCK TABLES `visits` WRITE;
/*!40000 ALTER TABLE `visits` DISABLE KEYS */;
INSERT INTO `visits` VALUES (1,'Sajid Ahmad',8217438234645,'05-30-2025','Query About Registration','No specific details');
/*!40000 ALTER TABLE `visits` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-19  9:43:33
